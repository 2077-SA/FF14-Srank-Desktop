'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { SUPPORTED_WORLD_GROUPS } = require('../bridge/src/data-centers');
const { buildSyncPlan } = require('../bridge/src/sync-plan');

const WORLD_TO_DC = {
  '水晶塔':'豆豆柴','银泪湖':'豆豆柴','太阳海岸':'豆豆柴','伊修加德':'豆豆柴','红茶川':'豆豆柴',
  '红玉海':'陆行鸟','神意之地':'陆行鸟','拉诺西亚':'陆行鸟','幻影群岛':'陆行鸟','萌芽池':'陆行鸟','宇宙和音':'陆行鸟','沃仙曦染':'陆行鸟','晨曦王座':'陆行鸟',
  '白银乡':'莫古力','白金幻象':'莫古力','神拳痕':'莫古力','潮风亭':'莫古力','旅人栈桥':'莫古力','拂晓之间':'莫古力','龙巢神殿':'莫古力','梦羽宝境':'莫古力',
  '紫水栈桥':'猫小胖','延夏':'猫小胖','静语庄园':'猫小胖','摩杜纳':'猫小胖','海猫茶屋':'猫小胖','柔风海湾':'猫小胖','琥珀原':'猫小胖'
};

test('renderer, bridge and overview share the same four data-center world ownership mapping', () => {
  const expected = Object.fromEntries(Object.entries(SUPPORTED_WORLD_GROUPS).flatMap(([dc, worlds]) => worlds.map(world => [world, dc])));
  assert.deepEqual(WORLD_TO_DC, expected);
  const renderer = fs.readFileSync(path.join(__dirname, '..', 'app', 'bear-sync-adapter.js'), 'utf8');
  for (const [world, dc] of Object.entries(expected)) assert.match(renderer, new RegExp(`['\"]${world}['\"]\\s*:\\s*['\"]${dc}['\"]`));
});

test('selecting a data center defaults to every child world and progress denominator is server count, not S monsters x worlds', () => {
  const plan = buildSyncPlan(['豆豆柴'], {}, null, {});
  assert.deepEqual(plan.groups, [{ dataCenter: '豆豆柴', worlds: [...SUPPORTED_WORLD_GROUPS['豆豆柴']] }]);
  assert.equal(plan.targetRequests, 1);
  assert.equal(plan.targetServers, 5);
  assert.notEqual(plan.targetServers, 5 * 18);
});

test('manual world choices remain scoped to their selected data center', () => {
  const plan = buildSyncPlan(['莫古力', '猫小胖'], {
    '莫古力': ['白银乡', '梦羽宝境'],
    '猫小胖': ['延夏', '琥珀原'],
    '豆豆柴': ['水晶塔']
  });
  assert.deepEqual(plan.worldSelections, { '莫古力': ['白银乡', '梦羽宝境'], '猫小胖': ['延夏', '琥珀原'] });
  assert.equal(plan.targetServers, 4);
  assert.ok(plan.groups.every(group => group.worlds.every(world => WORLD_TO_DC[world] === group.dataCenter)));
});

test('adding another data center auto-selects all of its child worlds without dropping existing choices', () => {
  const plan = buildSyncPlan(['陆行鸟', '豆豆柴'], { '陆行鸟': ['红玉海'] });
  assert.deepEqual(plan.worldSelections['陆行鸟'], ['红玉海']);
  assert.deepEqual(plan.worldSelections['豆豆柴'], [...SUPPORTED_WORLD_GROUPS['豆豆柴']]);
  assert.equal(plan.targetServers, 6);
});
