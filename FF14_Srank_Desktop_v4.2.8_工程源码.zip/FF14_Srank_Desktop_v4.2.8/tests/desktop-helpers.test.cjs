'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const {
  isAppStorageKey, isSensitiveStorageKey, sanitizeEntries,
  validateLegacyBackup, buildBridgeConfig, resolveInside, isCompatibleBridgeHealth, migrateBridgeCacheDirectory, BRIDGE_VERSION, BRIDGE_PORT
} = require('../desktop-helpers');

test('only FF14-owned localStorage key prefixes are eligible for migration', () => {
  assert.equal(isAppStorageKey('ff14_all_kill_records'), true);
  assert.equal(isAppStorageKey('triggerMonitor.state'), true);
  assert.equal(isAppStorageKey('google_user_data'), false);
});

test('credentials and privilege markers are excluded from migration', () => {
  for (const key of ['ff14_password', 'ff14_apiToken', 'ff14_developer_mode', 'ff14_master_verified', 'ff14_csrf']) {
    assert.equal(isSensitiveStorageKey(key), true, key);
  }
  const safe = sanitizeEntries({
    ff14_all_kill_records: '[]',
    ff14_apiToken: 'do-not-copy',
    browser_other_site: 'do-not-copy',
    ff14_preferences: '{"theme":"dark"}'
  });
  assert.deepEqual(Object.keys(safe.entries).sort(), ['ff14_all_kill_records', 'ff14_preferences']);
  assert.equal(safe.skipped, 2);
});

test('legacy backup validator accepts schema v1 and strips unsafe entries', () => {
  const payload = validateLegacyBackup({
    schema: 'ff14-toolbox-local-backup', schemaVersion: 1, appVersion: '3.3.8',
    entries: { ff14_all_kill_records: '[]', ff14_developer_mode: 'true' }
  });
  assert.equal(payload.count, 1);
  assert.equal(payload.skipped, 1);
  assert.equal(payload.entries.ff14_all_kill_records, '[]');
});

test('legacy backup validator rejects unsupported schemas', () => {
  assert.throws(() => validateLegacyBackup({ schema: 'other', schemaVersion: 1, entries: {} }), /受支持/);
});

test('desktop bridge config is anonymous, read-only, and uses an app-specific data folder', () => {
  const cfg = buildBridgeConfig('C:/Users/Test/AppData/Roaming/ff14-srank-desktop');
  assert.equal(cfg.local.port, 8790);
  assert.equal(BRIDGE_PORT, 8790);
  assert.equal(BRIDGE_VERSION, '1.4.8');
  assert.equal(require('../bridge/package.json').version, BRIDGE_VERSION);
  assert.deepEqual(cfg.watch.dataCenters, ['陆行鸟']);
  assert.equal(cfg.watch.selectionConfirmed, false);
  assert.deepEqual(cfg.local.allowedOrigins, ['app://bundle']);
  assert.equal(cfg.sync.allowUpstreamReports, false);
  assert.match(cfg.paths.dataDir, /bear-bridge-data-v2$/);
  assert.equal(cfg.auth, undefined);
});

test('resource resolver blocks path traversal', () => {
  const root = path.resolve('/tmp/ff14-app');
  assert.equal(resolveInside(root, 'index.html'), path.join(root, 'index.html'));
  assert.throws(() => resolveInside(root, '../secret.txt'), /越界/);
});


test('desktop only reuses a bridge when health reports the exact expected bridge version', () => {
  const good = { ok: true, mode: 'anonymous-srank', bridgeVersion: '1.4.8' };
  assert.equal(isCompatibleBridgeHealth(good), true);
  assert.equal(isCompatibleBridgeHealth({ ...good, bridgeVersion: '1.4.7' }), false);
  assert.equal(isCompatibleBridgeHealth({ ...good, bridgeVersion: undefined }), false);
  assert.equal(isCompatibleBridgeHealth({ ...good, mode: 'authenticated' }), false);
});


test('bridge cache migration copies legacy data without deleting or sharing the old directory', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ff14-bridge-cache-migration-'));
  const legacy = path.join(root, 'bear-bridge-data');
  const target = path.join(root, 'bear-bridge-data-v2');
  fs.mkdirSync(legacy, { recursive: true });
  fs.writeFileSync(path.join(legacy, 'chocobo.json'), '{"safe":true}');
  const result = migrateBridgeCacheDirectory(legacy, target);
  assert.equal(result.migrated, true);
  assert.equal(fs.readFileSync(path.join(target, 'chocobo.json'), 'utf8'), '{"safe":true}');
  assert.equal(fs.readFileSync(path.join(legacy, 'chocobo.json'), 'utf8'), '{"safe":true}');
  fs.writeFileSync(path.join(legacy, 'later.json'), 'legacy-only');
  const second = migrateBridgeCacheDirectory(legacy, target);
  assert.equal(second.alreadyPresent, true);
  assert.equal(fs.existsSync(path.join(target, 'later.json')), false);
  fs.rmSync(root, { recursive: true, force: true });
});
