'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const helpers = require('../desktop-helpers');
const root = path.join(__dirname, '..');

test('desktop shell, preload and bridge package versions are aligned', () => {
  const desktop = require(path.join(root, 'package.json'));
  const bridge = require(path.join(root, 'bridge', 'package.json'));
  const preload = fs.readFileSync(path.join(root, 'preload.js'), 'utf8');
  assert.equal(desktop.version, helpers.VERSION);
  assert.equal(bridge.version, helpers.BRIDGE_VERSION);
  assert.match(preload, new RegExp(`version: '${desktop.version.replaceAll('.', '\\.')}''`.replace("''", "'")));
  assert.match(preload, new RegExp(`bridgeVersion: '${bridge.version.replaceAll('.', '\\.')}''`.replace("''", "'")));
});

test('Windows release workflow consumes this exact source archive and release version', () => {
  const desktop = require(path.join(root, 'package.json'));
  const workflow = fs.readFileSync(path.join(root, '.github', 'workflows', 'release-windows.yml'), 'utf8');
  assert.ok(workflow.includes(`FF14_Srank_Desktop_v${desktop.version}_工程源码.zip`));
  assert.ok(workflow.includes(`FF14_Srank_Desktop_v${desktop.version}`));
  assert.ok(workflow.includes(`tag_name: v${desktop.version}`));
  assert.ok(!workflow.includes('v4.2.7'));
});

test('Electron main process and renderer point to the same isolated bridge port and storage namespace', () => {
  const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
  const runtime = fs.readFileSync(path.join(root, 'desktop-runtime.js'), 'utf8');
  const adapter = fs.readFileSync(path.join(root, 'app', 'bear-sync-adapter.js'), 'utf8');
  assert.match(main, /BRIDGE_PORT, BRIDGE_VERSION/);
  assert.match(main, /bear-bridge-data-v2/);
  assert.match(main, /isCompatibleBridgeHealth\(existing, BRIDGE_VERSION\)/);
  assert.match(runtime, /127\.0\.0\.1:8790/);
  assert.match(adapter, /baseUrl: 'http:\/\/127\.0\.0\.1:8790'/);
  assert.match(adapter, /bridge-version-mismatch/);
});
