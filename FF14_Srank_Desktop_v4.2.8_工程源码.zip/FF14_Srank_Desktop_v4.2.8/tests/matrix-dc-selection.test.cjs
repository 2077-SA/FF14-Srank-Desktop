'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DATA_CENTERS, normalizeSelectedDataCenters, filterServersByDataCenters, filterServerPreferenceMap, toggleDataCenter } = require('../app/matrix-dc-selection.js');

const groups = {
  '陆行鸟': ['红玉海', '神意之地'],
  '莫古力': ['白银乡', '白金幻象'],
  '猫小胖': ['紫水栈桥'],
  '豆豆柴': ['水晶塔', '银泪湖']
};
const all = Object.values(groups).flat();

test('server overview exposes the four canonical DC options in fixed order', () => {
  assert.deepEqual(DATA_CENTERS, ['陆行鸟', '莫古力', '猫小胖', '豆豆柴']);
});

test('DC filter only returns worlds belonging to checked data centers', () => {
  assert.deepEqual(filterServersByDataCenters(all, ['莫古力', '豆豆柴'], groups), ['白银乡', '白金幻象', '水晶塔', '银泪湖']);
});

test('unchecking a DC removes all of its visible worlds and preserves allowed selections', () => {
  const result = toggleDataCenter({
    selectedDataCenters: ['陆行鸟', '莫古力', '豆豆柴'], dataCenter: '莫古力', checked: false,
    serverNames: all, worldGroups: groups, visibleServers: ['红玉海', '白银乡', '水晶塔'], limit: 8
  });
  assert.equal(result.changed, true);
  assert.deepEqual(result.selectedDataCenters, ['陆行鸟', '豆豆柴']);
  assert.deepEqual(result.visibleServers, ['红玉海', '水晶塔']);
  assert.deepEqual(result.removedServers, ['白银乡']);
});

test('selecting a new DC adds its worlds to the allowed pool without leaking other unchecked DCs', () => {
  const result = toggleDataCenter({
    selectedDataCenters: ['陆行鸟'], dataCenter: '豆豆柴', checked: true,
    serverNames: all, worldGroups: groups, visibleServers: ['红玉海'], limit: 8
  });
  assert.deepEqual(result.selectedDataCenters, ['陆行鸟', '豆豆柴']);
  assert.deepEqual(result.allowedServers, ['红玉海', '神意之地', '水晶塔', '银泪湖']);
  assert.ok(result.visibleServers.every(world => result.allowedServers.includes(world)));
});

test('device limit caps visible servers but does not erase selected data centers', () => {
  const result = toggleDataCenter({
    selectedDataCenters: ['陆行鸟'], dataCenter: '莫古力', checked: true,
    serverNames: all, worldGroups: groups, visibleServers: ['红玉海'], limit: 2
  });
  assert.equal(result.selectedDataCenters.length, 2);
  assert.equal(result.visibleServers.length, 2);
  assert.equal(result.truncated, true);
});

test('can turn off the final selected DC and keep the server overview empty', () => {
  const result = toggleDataCenter({
    selectedDataCenters: ['猫小胖'], dataCenter: '猫小胖', checked: false,
    serverNames: all, worldGroups: groups, visibleServers: ['紫水栈桥'], limit: 8
  });
  assert.equal(result.changed, true);
  assert.deepEqual(result.selectedDataCenters, []);
  assert.deepEqual(result.allowedServers, []);
  assert.deepEqual(result.visibleServers, []);
  assert.deepEqual(result.removedServers, ['紫水栈桥']);
});

test('empty DC selection returns no allowed servers and can be re-enabled by selecting a DC', () => {
  assert.deepEqual(normalizeSelectedDataCenters([], { allowEmpty: true }), []);
  assert.deepEqual(filterServersByDataCenters(all, [], groups), []);
  const result = toggleDataCenter({ selectedDataCenters: [], dataCenter: '豆豆柴', checked: true,
    serverNames: all, worldGroups: groups, visibleServers: [], limit: 8 });
  assert.deepEqual(result.selectedDataCenters, ['豆豆柴']);
  assert.deepEqual(result.visibleServers, ['水晶塔', '银泪湖']);
});


test('unchecking a DC purges its worlds from desktop, tablet and mobile saved preferences', () => {
  const preferences = {
    desktop: ['红玉海', '白银乡', '水晶塔'],
    tablet: ['白金幻象', '银泪湖'],
    mobile: ['水晶塔', '紫水栈桥']
  };
  assert.deepEqual(filterServerPreferenceMap(preferences, ['红玉海', '水晶塔', '银泪湖']), {
    desktop: ['红玉海', '水晶塔'], tablet: ['银泪湖'], mobile: ['水晶塔']
  });
});


test('an explicitly empty saved overview filter remains empty instead of silently reselecting 陆行鸟', () => {
  assert.deepEqual(normalizeSelectedDataCenters([], { allowEmpty: true }), []);
  assert.deepEqual(filterServersByDataCenters(all, [], groups), []);
});
