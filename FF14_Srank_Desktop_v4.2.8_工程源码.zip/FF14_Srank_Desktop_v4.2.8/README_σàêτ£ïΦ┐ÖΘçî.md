# FF14 Srank Desktop v4.2.5 当前版本补充

本文件后续保留 v4.2.3 及更早版本的历史说明；当前工程请以根目录 `README.md` 和 `docs/CHANGELOG_v4.2.5.md` 为准。

## v4.2.5 Bear CD 准确性与桥接稳定性

- 将 Bear 每只 S 怪的 `RespawnTimer` / `MaintTimer` 和击杀锚点从桥接缓存贯穿到计算器、新版监控室和旧版监控室。
- 维护状态必须由接口明确给出 true / false；缺失、未知或同一时间戳冲突时，不默认当成正常状态，不计算 / 展示已核验 CD。
- Bear 时间资源每 6 小时重新核验；每条记录携带 `timerResourcesFetchedAt`。过期、无时间戳或无法刷新资源时，旧窗口不再作为可信 CD 显示。
- 进闸时间 = 击杀锚点 + Bear 最小窗口；强制时间 = 击杀锚点 + Bear 最大窗口。维护窗与正常窗分别使用对应定义。
- 50–80 小时维护窗切换到 84–132 小时正常窗、同锚点更新、新击杀锚点更新、重复快照去重和跨服务器手动数据保留均通过 Chromium 模拟桥接联测。
- 桌面端 26/26、桥接端 32/32 自动化测试通过。测试使用模拟 Bear / 本机桥接响应，不代表 Bear 官网线上逐只实时对照或 Windows EXE 实机验证。
- 活动窗口内上游核对计划约每 2 分钟一次，仍会受 Bear 服务响应、网络和 429 限流影响，不承诺秒级实时。

---

## v4.2.3 监控室同步修复

- 每次确认同步快照后都会向新旧监控室重新发送最新绑定数据；即使本地记录已存在、没有新增记录，也不会漏刷新。
- Bear 怪名匹配忽略空格、标点及全半角差异，例如“先驱勇士阿提卡斯”和“先驱勇士 阿提卡斯”视为同一名称。
- 同名行仅在同一服务器、同一版本分组内合并，优先保留有效击杀时间和 CD 状态；不同大区、服务器及版本的数据继续隔离。
- 保留原有手动记录、手动 CD 覆盖和本地设置。

## v4.2.3 监控室同步与重复行修复

- 四大区分别使用独立缓存和同步状态文件，不共享击杀时间 / CD 锚点。
- 每条数据写入前核对数据中心、子服务器和 S 怪；不匹配的数据进入拒绝计数，不会改变任何分区。
- 旧版共享缓存按子服务器归属迁移；无法识别的记录隔离保留，不参与计算。
- 计算器和工具箱记录带有数据中心字段，按所选服务器只读取对应大区记录。

# FF14 Srank Desktop v4.2.5

这是 FF14 Srank Desktop v4.2.5 工程。桌面版保留 v3.3.8 核心工具箱，并升级 Bear S 怪批量同步与按需大区调度。它不是把 HTML 简单改名为 EXE：Electron 主进程负责窗口、菜单、数据迁移与文件对话框；Bear S 怪同步服务在独立 Utility Process 中运行；原工具箱继续作为隔离的 renderer 页面显示。

## 本版本目标

- 保留 v3.3.8 原有计算器、监控室、OCR、排车、ET、工具箱菜单和统一浮窗。
- Bear Tracker 保持匿名只读 S 怪同步：只查询 Rank=5；不登录、不向 Bear Tracker 写入、不处理 A/B/B+/FATE。
- Bear 查询运行在单独后台进程；启动主窗口不等待 Bear 的远端网络请求。
- 桥接使用独立端口 `127.0.0.1:8790`，避免与旧一键包的 `8787` 冲突。
- 桌面数据、映射、同步缓存、日志和备份统一保存在 Electron userData 目录。
- 主窗口使用自定义 `app://bundle` 安全协议；renderer 禁用 Node 集成，启用 context isolation、sandbox 和 webSecurity。
- 通过原版工具箱的 `ff14-toolbox-local-backup` JSON v1 迁移历史数据，不直接读写 Edge/Chrome 浏览器配置文件。

## v4.2.3 同步专项优化

- 新增独立「同步数据」控制中心：四大区可多选、陆行鸟默认选中，展示同步阶段、真实进度、服务器级结果、错误、队列、最近同步时间，并支持暂停、恢复和手动同步。
- 监控室内置四大区切换；四大区共 28 个子服务器使用内置映射，避免上游资源暂时缺少 DataCenters 字段时只显示莫古力或单一区域。
- Bear 同步仅导入正式 S 怪数据；对同一服务器/怪物只替换旧的 Bear 来源记录，保留玩家手工记录。替换会同时更新 localStorage 和工具箱内存记录数组，确保新版/旧版监控室与计算器共享最新数据。
- 计算器根据当前服务器与 S 怪的最近击杀锚点实时显示 CD 冷却、剩余时间、进闸与强制消失时间；击杀锚点只有在玩家主动点击后才会填入表单，不会后台覆盖正在编辑的输入框。
- 本地同步快照每 30 秒刷新到监控室和计算器；远端 Bear 请求仍按 S 怪 CD 窗口调度，不会每 30 秒请求远端。
- 首次使用提供同步说明和 Bear Tracker 官方计时器入口；同步面板名称统一为「同步数据」。
- 排车与 OCR 合并为默认折叠的左侧菜单组；自动保存改为有变更时每 15 秒静默保存，不再占用右下角区域。
- 修复桌面桥接端口和渲染器面板地址不一致的问题；健康检查复用进程内状态快照，降低重复磁盘读取。

## v4.2.3 紧急修复与稳定性更新

- 修复 v4.1.0 / v4.1.1 的 `ff14TriggerMonitorEmbeddedPayload` JSON 被重复插入桌面更新公告脚本、导致监控室内嵌页面解析失败的问题。
- 首次启动默认预选「陆行鸟」，但仍须由玩家点击保存确认后才会启动监控扫描。
- Bear 远端词库加载期间即可显示、选择并保存四个国服数据中心；远端资源就绪后再继续加载 S 怪名称映射。
- 身份权限继续遵循原有邀请码规则。未验证身份时会引导打开验证窗口，不会自动提升权限。
- 增加嵌入页面 JSON 完整性自动化测试，避免后续公告或脚本插入再次破坏载入。

## v4.1.1 自动更新（历史功能，v4.2.5 继续保留）

- Windows 安装版启动后会延迟检查 GitHub Releases 正式版本，不会阻塞主窗口或 Bear 同步后台。
- 菜单「帮助 → 检查更新」可手动检查。
- 使用 electron-updater 与 GitHub Releases 的 latest.yml / SHA-512 元数据下载并校验安装包。
- 下载完成后由用户选择立即重启安装或稍后处理，不会在用户未确认时强制退出。
- 安装版支持自动下载和安装；Portable 版只检查版本并打开 Releases 下载页面，避免覆盖正在运行的单文件程序。
- 本地数据继续保存在 Electron userData 目录，与安装目录分离；升级不主动删除或重置本地数据库、CD 记录、服务器设置及缓存。
- 发布工作流执行语法检查、自动化测试、Windows 安装版/Portable 构建，并将 EXE、latest.yml 与 blockmap 上传到 GitHub Release。

注意：自动更新必须在 GitHub 发布正式 Release 并包含 latest.yml 后才可使用。仅提交源码或上传 Actions Artifact 不会触发客户端更新。


- 监控大区改为首次由玩家选择；旧版本默认陆行鸟配置不会在升级后自动触发全量扫描。
- 陆行鸟、莫古力、猫小胖以 `/api/lastDeathTimers` 作为整区批量读取接口；豆豆柴走独立公开 live 快照源。
- 按 Rank=5、所选服务器和时间戳范围严格校验，按批持久化。
- 本地词库 24 小时内优先复用；按 S 怪 CD 窗口安排各大区下一次批量核对。
- 保留旧版本工具箱文件和迁移逻辑；首次启动显示 v4.2.5 更新公告。
- 内置 Bear 页面捕获、自动中文映射推断和 Sonar/Dalamud 插件仍未启用，见更新日志。

## 目录

```text
FF14_Srank_Desktop_v4.2.5/
├─ app/index.html                 原 v3.3.8 完整工具箱页面
├─ bridge/                        免登录 S 怪本地同步服务完整源码
├─ main.js                        Electron 主进程和 Utility Process 管理
├─ preload.js                     最小 IPC 安全桥
├─ desktop-runtime.js              桌面数据迁移 / 导出 / 本地桥接地址
├─ desktop-helpers.js              配置、路径和备份校验
├─ tests/                          桌面辅助逻辑测试
├─ 01_一键生成Windows安装包.cmd   安装构建依赖、检查、测试、生成安装程序+单文件 EXE
├─ 02_生成EXE加资源文件夹.cmd     生成 EXE + resources 的文件夹分发版
└─ 03_打开数据文件夹.cmd          打开桌面版持久化数据目录
```

## 一次性构建 Windows EXE

构建电脑需要 Windows 10/11 x64、Node.js 22.12 或更高版本，以及首次安装依赖时可访问 npm/Electron 下载站点的网络。

1. 完整解压本工程文件夹，不要只取 `app/index.html`。
2. 双击 `01_一键生成Windows安装包.cmd`。
3. 脚本会执行 `npm install`、源码语法检查、桌面 + Bear 桥接自动化测试，然后调用 electron-builder。
4. 构建产物在 `release`：
   - `FF14-Srank-Desktop-4.2.4-x64.exe`：NSIS 安装程序。
   - `FF14-Srank-Desktop-4.2.4-Portable-x64.exe`：单文件免安装程序。
5. 安装后或运行 Portable 后，日常使用只需打开 **FF14 Srank Desktop.exe**。不需要另外启动 CMD、Node 服务、浏览器或 Tampermonkey。

### EXE + resources 文件夹分发版

如果更喜欢“一个主 EXE + 一个 resources 文件夹”的结构，双击 `02_生成EXE加资源文件夹.cmd`。输出在 `release/win-unpacked/`：

```text
release/win-unpacked/
├─ FF14 Srank Desktop.exe      ← 双击唯一主程序
├─ resources/                  ← 程序资源，必须保留
└─ 其他 Electron 运行库文件    ← 必须与 EXE 放在一起
```

不要单独移动 EXE，也不要删除 resources 或其他运行库文件。

## 第一次迁移旧版数据

桌面版不会擅自读取 Edge/Chrome 的浏览器数据库。请通过原 v3.3.8 浏览器版的正式备份格式迁移：

1. 在 Edge/Chrome 打开旧版 v3.3.8 HTML。
2. 进入「智能工具中心」→「数据安全中心」→「立即导出备份」，保存 JSON。
3. 打开 FF14 Srank Desktop。
4. 从窗口顶部菜单「文件」→「导入旧版工具箱备份 JSON…」选择刚才的 JSON。
5. 桌面版会先对当前桌面数据创建回滚备份，再合并恢复相同键；原来备份未包含的数据不会被清空。

为避免把浏览器权限状态移植到另一运行环境，迁移过程会跳过密码、Cookie、Token、CSRF、会话、邀请码、权限标记、开发者模式和 master verified 标记。业务击杀记录、常规设置和工具箱数据会迁移。

桌面版后续备份从「文件」→「导出桌面版数据备份 JSON…」执行。

## 数据与日志位置

通过菜单「文件」→「打开数据文件夹」进入。实际目录由 Electron userData 决定，最稳妥的打开方式是桌面软件菜单「文件 → 打开数据文件夹」。默认通常位于 Windows 用户的 Roaming 应用数据目录。目录包含：

```text
%APPDATA%\\FF14 Srank Desktop\\（具体位置可从“文件 → 打开数据文件夹”进入）
├─ bridge-config.json             数据中心及 S 怪名称映射配置（本地桥接端口 8790）
├─ bear-bridge-data/               Bear 匿名查询缓存与状态
├─ logs/                           Bear 后台运行日志
└─ backups/                        迁移前自动备份与导出记录
```

桌面浏览器存储（localStorage / IndexedDB）由 Electron 持久化在同一 userData 配置目录中。

## Bear S 怪 CD 同步方式

- 仅处理 `DatabaseHunt` 中 `Rank=5` 的正式 S 怪。
- 匿名查询 `syncSession` + `huntInfo`；不使用 Bear 登录账号。
- 中文怪名通过本地 S 怪词库与 `aliases` 映射到 Bear 英文 HuntName。未确认的名字不会导入中文历史记录。
- 服务器按选择的数据中心展开。
- 后台默认每 15 分钟刷新；工具箱面板可手动立即同步。
- Bear 远端响应缺失或权限受限时显示暂无数据，不伪造击杀时间。
- 这是单向读取（Bear Tracker → 工具箱）；匿名模式不具备向 Bear 上报权限。

## 性能与边界说明

本阶段已经把 Bear 网络请求和本地 HTTP/SSE 服务隔离在 Electron Utility Process，主 UI 不再执行大批量远端请求；文件读写、导入对话框和主窗口由 Electron 主进程管理。OCR 识别仍由工具箱现有 Worker 运行；首次使用 OCR 仍需访问原页面指定的 Tesseract CDN/语言资源。Electron 封装不会自动让旧版所有同步 DOM 逻辑变成多线程，后续如果真实运行还存在 UI 卡顿，应继续把 OCR 解析、历史统计和大型数据转换拆进 Worker/Utility Process，而不是盲目改写业务逻辑。

## 重要安全说明

- Bear 模式为匿名只读，不要求 Bear 密码，也不保存 Bear 凭据。
- 本地桥接仅监听 `127.0.0.1`，不绑定局域网网卡；CORS 只允许 `app://bundle`。
- Electron renderer 的 Node 集成关闭，使用隔离 preload；不要自行给远程网页开启 Node 集成。
- 不要将 `bridge-config.json`、缓存、Cookie jar（本模式不应产生登录 Cookie）或日志上传到公开位置。
- 未签名的 EXE 可能触发 Windows SmartScreen 提示。正式对外发布应使用组织代码签名证书。

## 当前验证状态

本工程包含自动化测试；构建机上运行 `npm run check` 与 `npm test`。本次 ChatGPT 工作环境没有预装 Electron，也无法访问 npm registry 完成 Electron runtime 下载，因此没有在此处生成或声称已生成 Windows EXE。请在 Windows 电脑运行上面的构建脚本实际生成 EXE。真实 Bear 线上匿名接口结果仍取决于 Bear 当前服务状态与返回数据。


## v4.2.3 同步与稳定性专项

- Bear 同步控制中心支持四大区多选，首次默认陆行鸟；显示真实同步阶段、服务器队列与结果，支持暂停、恢复和手动同步。
- 每 30 秒检查本地缓存版本并将变化投影到新版 / 旧版监控室及计算器；远端扫描由 S 怪 CD 窗口调度，不按 30 秒重复请求 Bear。
- 计算器根据当前世界 / S 怪最近击杀锚点实时显示 CD 阶段、剩余冷却、进闸 / 强制时间；手动确认后才填入表单，计算器结果自动同步覆盖四大区正式服务器。
- 相同世界 / S 怪的旧 Bear 同步锚点会被新数据替换，手动记录不会被同步流程删除。首次使用可对照 [Bear Tracker 公开计时页](https://tracker.beartoolkit.com/timer)，无需登录。
- 自动保存每 15 秒写入一次，不再显示右下角自动保存悬浮控件；排车与 OCR 合并为默认折叠的左侧菜单组。
