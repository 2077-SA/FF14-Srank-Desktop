'use strict';

function timerWorld(timer) {
  const value = timer && (timer.worldName ?? timer.WorldName ?? timer.World);
  return typeof value === 'string' ? value.trim() : '';
}

function summarizeBulkWorlds(worlds, sourceTimers, parsedRows, distinctRows, acceptedRows) {
  const stats = new Map(worlds.map(world => [world, {
    world, rawRecords: 0, parsedRecords: 0, distinctRecords: 0, records: 0,
    rejectedRecords: 0, duplicateRecords: 0, isolatedRecords: 0, status: 'empty'
  }]));
  for (const timer of Array.isArray(sourceTimers) ? sourceTimers : []) {
    const stat = stats.get(timerWorld(timer));
    if (stat) stat.rawRecords++;
  }
  for (const row of Array.isArray(parsedRows) ? parsedRows : []) {
    const stat = stats.get(String(row?.worldName || ''));
    if (stat) stat.parsedRecords++;
  }
  for (const row of Array.isArray(distinctRows) ? distinctRows : []) {
    const stat = stats.get(String(row?.worldName || ''));
    if (stat) stat.distinctRecords++;
  }
  for (const row of Array.isArray(acceptedRows) ? acceptedRows : []) {
    const stat = stats.get(String(row?.worldName || ''));
    if (stat) stat.records++;
  }
  for (const stat of stats.values()) {
    stat.rejectedRecords = Math.max(0, stat.rawRecords - stat.parsedRecords);
    stat.duplicateRecords = Math.max(0, stat.parsedRecords - stat.distinctRecords);
    stat.isolatedRecords = Math.max(0, stat.distinctRecords - stat.records);
    stat.status = stat.rawRecords === 0 ? 'empty'
      : stat.parsedRecords === 0 ? 'error'
      : stat.records === 0 ? 'isolated'
      : (stat.rejectedRecords || stat.isolatedRecords) ? 'partial' : 'saved';
    if (stat.status === 'error') stat.error = 'Bear 返回了原始记录，但没有任何一条通过 S 怪 / 时间 / CD 校验';
    else if (stat.status === 'isolated') stat.error = '本轮记录全部因来源冲突或一致性检查被隔离，未写入 CD';
    else if (stat.status === 'empty') stat.note = '本轮接口没有返回该服务器的计时记录；不代表已获取到 CD 数据';
  }
  return [...stats.values()];
}

function assertBulkNormalization(sourceTimers, parsedRows, dataCenter) {
  const rawCount = Array.isArray(sourceTimers) ? sourceTimers.length : 0;
  const parsedCount = Array.isArray(parsedRows) ? parsedRows.length : 0;
  if (rawCount > 0 && parsedCount === 0) {
    throw new Error(`${dataCenter} Bear 批量接口返回 ${rawCount} 条原始记录，但有效 S 怪记录为 0；已阻止将 0 条误报为同步成功。请检查接口字段、维护标记与词库映射。`);
  }
  return { rawCount, parsedCount, rejectedCount: Math.max(0, rawCount - parsedCount),
    status: rawCount === 0 ? 'empty' : parsedCount < rawCount ? 'partial' : 'completed' };
}

module.exports = { summarizeBulkWorlds, assertBulkNormalization };
