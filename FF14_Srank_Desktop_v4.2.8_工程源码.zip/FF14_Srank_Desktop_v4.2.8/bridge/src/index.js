#!/usr/bin/env node
'use strict';
/**
 * Anonymous S-rank-only Bear Tracker bridge.
 * - No Bear account, password, API token, Socket.IO, or upstream writes are used.
 * - Prefers the public /api/lastDeathTimers bulk endpoint for Rank=5 S monsters only.
 * - Persists validated results in batches and keeps the local HTTP server responsive.
 */
const path = require('node:path');
const config = require('./config');
const { TrackerRest } = require('./tracker-rest');
const { Store } = require('./store');
const { LocalServer, keyOf } = require('./server');
const { normalizeBulkTimer, normalizeBulkTimerDetailed, normalizeMainSiteLiveDetailed, normalizeHuntInfo, computeRecordWindow } = require('./normalize');
const { filterSRankResources } = require('./resources');
const { SUPPORTED_DATA_CENTERS, validateDataCenters, worldsForDataCenter, dataCenterForWorld, normalizeWorldSelections } = require('./data-centers');
const { runWithConcurrency, compareTimestampEvidence } = require('./multi-route');
const { summarizeBulkWorlds, assertBulkNormalization } = require('./sync-report');
const { readBatchWithWorldFallback } = require('./bulk-read');
const { buildSyncPlan } = require('./sync-plan');
const BRIDGE_VERSION = require('../package.json').version;

const cfg = config.load();
// Force the anonymous, read-only mode even when upgrading from an older login-capable config.
cfg.auth = { username: '', password: '', cookie: '', csrfToken: '', apiToken: '' };
cfg.sync = { ...(cfg.sync || {}), allowUpstreamReports: false, queueTransientFailures: false, maxOutboxAttempts: 0 };
const stamp = () => new Date().toLocaleTimeString('zh-CN', { hour12: false });
const log = message => console.log(`${stamp()} ${message}`);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const DC_CONCURRENCY = 2;
const TARGET_VERIFY_LIMIT_PER_DC = 5;
const TARGET_VERIFY_INTERVAL_MS = 650;
// Timer definitions are revalidated at least every six hours; old resource snapshots
// must not silently continue authorizing CD calculations after a resource change.
const MAX_TIMER_RESOURCE_AGE_HOURS = 6;

function worldsFor(resources) {
  if (Array.isArray(cfg.watch.worlds) && cfg.watch.worlds.length) return [...new Set(cfg.watch.worlds)];
  const worlds = [];
  for (const dc of cfg.watch.dataCenters || []) {
    worlds.push(...worldsForDataCenter(dc, resources));
  }
  return [...new Set(worlds)];
}

function mapToLocalName(name) {
  for (const [localName, trackerName] of Object.entries(cfg.aliases || {})) {
    if (trackerName === name) return localName;
  }
  return name;
}

async function getResources(rest, store) {
  const response = await rest.syncSession();
  const resources = response.json?.resources;
  if (response.status >= 400) {
    throw new Error(`匿名 syncSession 失败（HTTP ${response.status}）：${String(response.text || '').slice(0, 160)}`);
  }
  // Hard-filter the cache itself: this bridge intentionally discards every non-S dataset.
  const sOnlyResources = filterSRankResources(resources);
  store.saveResources(sOnlyResources);
  const sCount = Object.keys(sOnlyResources.DatabaseHunt).length;
  log(`[resources] 匿名 S 怪词库已就绪：仅保留 S 怪 ${sCount} 只；数据中心 ${Object.keys(sOnlyResources.DataCenters).length} 个`);
  return sOnlyResources;
}

function publicSyncState() {
  return {
    mode: 'anonymous-srank',
    status: 'starting',
    running: false,
    dataCenters: cfg.watch.dataCenters || [],
    worldSelections: cfg.watch.worldSelections || {},
    rank: 's',
    totalTargets: 0,
    completed: 0,
    recordsFound: 0,
    unchangedRecords: 0, staleRecords: 0,
    validatedRecords: 0,
    rejectedRecords: 0,
    emptyDataCenters: 0,
    partialDataCenters: 0,
    noRecord: 0,
    errors: 0,
    lastSyncAt: null,
    startedAt: null,
    finishedAt: null,
    durationMs: 0,
    lastError: null,
    resourcesReady: false,
    progressPercent: 0, phase: 'idle', phaseLabel: '等待同步', requestQueue: 0,
    validatedTargets: 0, persistedTargets: 0, quarantinedRecords: 0, corroboratedRecords: 0, singleSourceRecords: 0, activeDataCenters: [], worldResults: [], paused: false, pauseRequested: false,
    lastSuccessAt: null, currentDataCenter: null,
    byDataCenter: Object.fromEntries(SUPPORTED_DATA_CENTERS.map(dc => [dc, { dataCenter: dc, status: 'idle', phase: 'idle', lastSyncAt: null, lastSuccessAt: null, lastError: null, nextPollAt: null }]))
  };
}

async function runServe() {
  // Discard any stale authenticated session from an earlier bridge release. A fresh anonymous
  // CSRF session is created by GET / and managed by TrackerRest.
  try { require('node:fs').rmSync(path.join(cfg.dataDir, 'auth-session.json'), { force: true }); } catch {}
  try { require('node:fs').rmSync(path.join(cfg.dataDir, 'cookies.json'), { force: true }); } catch {}
  const rest = new TrackerRest(cfg, log);
  const store = new Store(cfg);
  let resources = null;
  let resourcesFetchedAt = null;
  // If upgrading from an older all-rank bridge, sanitize its resource cache immediately.
  try {
    const cached = store.loadResources();
    if (cached) { resources = filterSRankResources(cached); resourcesFetchedAt = cached.fetchedAt || null; store.saveResources({ ...resources, fetchedAt: resourcesFetchedAt }); }
  } catch (error) { log(`[resources] 已忽略旧版非 S 资源缓存：${error.message}`); }
  const syncState = publicSyncState();
  for (const dc of SUPPORTED_DATA_CENTERS) syncState.byDataCenter[dc] = { ...syncState.byDataCenter[dc], ...store.loadDataCenterMeta(dc) };
  let syncPromise = null;
  let resourcesPromise = null;
  let remoteReady = false;
  let syncPauseRequested = false;
  let syncPaused = false;
  let remoteCooldownUntil = 0;
  async function waitForRemoteSlot() {
    await waitIfSyncPaused();
    const waitMs = Math.max(0, remoteCooldownUntil - Date.now());
    if (waitMs) await sleep(Math.min(waitMs, 15 * 60 * 1000));
    await waitIfSyncPaused();
  }
  const dcNextPollAt = new Map();
  for (const dc of SUPPORTED_DATA_CENTERS) {
    const next = Date.parse(syncState.byDataCenter?.[dc]?.nextPollAt || '');
    if (Number.isFinite(next) && next > Date.now()) dcNextPollAt.set(dc, next);
  }

  function pauseSync() {
    syncPauseRequested = true;
    syncState.pauseRequested = true;
    if (!syncState.running) { syncPaused = true; syncState.paused = true; syncState.phase = 'paused'; syncState.phaseLabel = '已暂停'; }
    return { paused: syncPaused, pauseRequested: syncPauseRequested, note: syncState.running ? '当前网络请求结束后暂停' : '同步已暂停' };
  }
  function resumeSync() {
    syncPauseRequested = false; syncPaused = false;
    syncState.paused = false; syncState.pauseRequested = false;
    if (syncState.running && syncState.phase === 'paused') { syncState.phase = 'resuming'; syncState.phaseLabel = '正在恢复'; }
    return { paused: false, resumed: true };
  }
  async function waitIfSyncPaused() {
    if (!syncPauseRequested && !syncPaused) return;
    syncPaused = true; syncState.paused = true; syncState.phase = 'paused'; syncState.phaseLabel = '已暂停；等待恢复';
    while (syncPauseRequested) await sleep(250);
    syncPaused = false; syncState.paused = false; syncState.pauseRequested = false;
    syncState.phase = 'resuming'; syncState.phaseLabel = '已恢复，继续同步';
  }
  function recalcSyncProgress() {
    // Progress is the count of selected-world query targets whose request has
    // returned and been classified. It is never inflated by a failed request.
    // Whether that response contained usable rows is a separate sync status.
    const total = Math.max(1, Number(syncState.totalTargets) || 1);
    const completed = Math.max(0, Number(syncState.completed) || 0);
    syncState.progressPercent = Math.max(0, Math.min(100, Math.round(completed / total * 1000) / 10));
  }
  function updateWorldState(dc, world, status, extra = {}) {
    const rows = Array.isArray(syncState.worldResults) ? syncState.worldResults : [];
    const row = rows.find(item => item.dataCenter === dc && item.world === world);
    if (row) Object.assign(row, { status, updatedAt: new Date().toISOString(), ...extra });
  }
  function updateDataCenterSyncState(dc, patch = {}) {
    const current = syncState.byDataCenter?.[dc] || {
      dataCenter: dc, status: 'idle', phase: 'idle', lastSyncAt: null,
      lastSuccessAt: null, lastError: null, nextPollAt: null
    };
    const next = { ...current, ...patch, dataCenter: dc, updatedAt: new Date().toISOString() };
    syncState.byDataCenter = { ...(syncState.byDataCenter || {}), [dc]: next };
    store.saveDataCenterMeta(dc, next);
  }

  function timerResourcesAreFresh() {
    const fetchedMs = Date.parse(resourcesFetchedAt || '');
    const configuredHours = Math.max(1, Number(cfg.watch.cacheMaxAgeHours) || MAX_TIMER_RESOURCE_AGE_HOURS);
    const maxAgeMs = Math.min(MAX_TIMER_RESOURCE_AGE_HOURS, configuredHours) * 3600000;
    const ageMs = Date.now() - fetchedMs;
    return !!resources && Number.isFinite(fetchedMs) && ageMs >= -5 * 60 * 1000 && ageMs <= maxAgeMs;
  }

  async function ensureResources() {
    if (remoteReady && timerResourcesAreFresh()) return resources;
    if (resourcesPromise) return resourcesPromise;
    resourcesPromise = (async () => {
      if (!rest.csrfToken) {
        const bootstrap = await rest.bootstrap();
        log(`[rest] 匿名会话已建立：csrf=${bootstrap.csrf ? 'ok' : 'missing'}，session=${bootstrap.hasSession ? 'ok' : 'missing'}`);
      }
      const cacheAge = resourcesFetchedAt ? Date.now() - Date.parse(resourcesFetchedAt) : Infinity;
      if (!timerResourcesAreFresh()) {
        log(`[resources] Bear S 怪时间资源缓存过期或无效（年龄 ${(cacheAge / 3600000).toFixed(1)} 小时），重新读取 syncSession`);
        resources = await getResources(rest, store);
        resourcesFetchedAt = store.loadResources()?.fetchedAt || new Date().toISOString();
      } else {
        log(`[resources] 使用本地 S 怪词库缓存，年龄 ${(cacheAge / 3600000).toFixed(1)} 小时；跳过重复 syncSession`);
      }
      remoteReady = true;
      syncState.resourcesReady = true;
      syncState.status = 'ready';
      return resources;
    })().catch(error => {
      syncState.status = 'error';
      syncState.resourcesReady = false;
      syncState.running = false;
      syncState.lastError = error.message;
      log(`[init] Bear Tracker 匿名资源初始化失败：${error.message}`);
      throw error;
    }).finally(() => { resourcesPromise = null; });
    return resourcesPromise;
  }

  const sRankDefinitions = () => Object.entries(resources?.DatabaseHunt || {})
    .filter(([, definition]) => Number(definition?.Rank) === 5)
    .map(([name, definition]) => ({ name, definition }));

  function scheduleNextDataCenterPoll(dc, worlds, definitions) {
    const state = store.loadDataCenterState(dc);
    const nowSec = Math.floor(Date.now() / 1000);
    let nextSec = nowSec + 6 * 3600;
    let hasUnknown = false;
    for (const worldName of worlds) {
      for (const item of definitions) {
        const localName = mapToLocalName(item.name);
        const row = state.hunts?.[keyOf(worldName, localName)];
        const death = Number(row?.lastDeathTime) || 0;
        if (!death) { hasUnknown = true; continue; }
        // Never turn an absent/unknown maintenance flag into normal CD.
        const window = computeRecordWindow(row, item.definition, death);
        if (!window) { hasUnknown = true; continue; }
        let candidate;
        if (nowSec < window.startTs - 900) candidate = window.startTs - 900;
        else if (nowSec <= window.endTs) candidate = nowSec + 2 * 60;
        else candidate = nowSec + 5 * 60;
        nextSec = Math.min(nextSec, candidate);
      }
    }
    if (hasUnknown) nextSec = Math.min(nextSec, nowSec + 10 * 60);
    const delayMs = Math.max(60 * 1000, Math.min(6 * 3600 * 1000, (nextSec - nowSec) * 1000));
    dcNextPollAt.set(dc, Date.now() + delayMs);
    updateDataCenterSyncState(dc, { nextPollAt: new Date(Date.now() + delayMs).toISOString() });
    log(`[schedule] ${dc} 下次批量核对约 ${Math.round(delayMs/60000)} 分钟后`);
  }

  async function verifySuspiciousRows(dataCenter, rows, definitions) {
    if (dataCenter === '豆豆柴') {
      syncState.singleSourceRecords = (syncState.singleSourceRecords || 0) + rows.length;
      return rows.map(row => ({ ...row, trustLevel: 'validated-single-source', verifiedRoutes: ['public-live'] }));
    }
    const state = store.loadDataCenterState(dataCenter);
    const definitionByName = new Map(definitions.map(item => [mapToLocalName(item.name), item.definition]));
    const presentKeys = new Set(rows.map(row => keyOf(row.worldName, row.huntName)));
    const conflictCandidates = rows.filter(row => {
      const old = state.hunts?.[keyOf(row.worldName, row.huntName)];
      const oldTs = Number(old?.lastDeathTime) || 0;
      const newTs = Number(row.lastDeathTime) || 0;
      const conflict = oldTs > 0 && Math.abs(newTs - oldTs) > 120;
      const def = definitionByName.get(row.huntName);
      const window = computeRecordWindow(row, def, newTs);
      const nearWindow = window && Date.now() / 1000 >= window.startTs - 15 * 60 && Date.now() / 1000 <= window.endTs;
      return conflict || nearWindow;
    }).sort((a, b) => {
      const oldA = Number(state.hunts?.[keyOf(a.worldName, a.huntName)]?.lastDeathTime) || 0;
      const oldB = Number(state.hunts?.[keyOf(b.worldName, b.huntName)]?.lastDeathTime) || 0;
      const conflictA = oldA && Math.abs(Number(a.lastDeathTime) - oldA) > 120 ? 1 : 0;
      const conflictB = oldB && Math.abs(Number(b.lastDeathTime) - oldB) > 120 ? 1 : 0;
      return conflictB - conflictA;
    });
    const missingActiveCandidates = [];
    for (const [key, old] of Object.entries(state.hunts || {})) {
      if (!old?.worldName || !old?.huntName || presentKeys.has(key)) continue;
      if (dataCenterForWorld(old.worldName, resources) !== dataCenter) continue;
      const definition = definitionByName.get(old.huntName);
      const oldTs = Number(old.lastDeathTime) || 0;
      // Old cache rows without an explicit maintenance bit are not a valid CD window.
      const window = computeRecordWindow(old, definition, oldTs);
      if (window && Date.now() / 1000 >= window.startTs - 15 * 60 && Date.now() / 1000 <= window.endTs) {
        missingActiveCandidates.push({ worldName: old.worldName, huntName: old.huntName, lastDeathTime: oldTs, definition, supplement: true });
      }
    }
    const candidates = [...conflictCandidates, ...missingActiveCandidates].slice(0, TARGET_VERIFY_LIMIT_PER_DC);
    if (!candidates.length) {
      syncState.singleSourceRecords = (syncState.singleSourceRecords || 0) + rows.length;
      return rows.map(row => ({ ...row, trustLevel: 'validated-single-source', verifiedRoutes: ['bear-lastDeathTimers'] }));
    }
    const verified = new Map();
    let nextAllowedAt = 0;
    for (const row of candidates) {
      const wait = Math.max(0, nextAllowedAt - Date.now());
      if (wait) await sleep(wait);
      nextAllowedAt = Date.now() + TARGET_VERIFY_INTERVAL_MS;
      await waitForRemoteSlot();
      try {
        const result = await rest.huntInfo(row.huntName, row.worldName);
        const definition = row.definition || definitionByName.get(row.huntName);
        const secondary = normalizeHuntInfo(row.huntName, row.worldName, result.json, definition, { maint: row.maint });
        if (!secondary) continue;
        secondary.timerResourcesFetchedAt = resourcesFetchedAt;
        const comparison = row.supplement ? null : compareTimestampEvidence(row.lastDeathTime, secondary.lastDeathTime, 120);
        verified.set(keyOf(row.worldName, row.huntName), { secondary, comparison, supplement: !!row.supplement });
      } catch (error) {
        if (Number(error.status) === 429) remoteCooldownUntil = Math.max(remoteCooldownUntil, Date.now() + Math.max(60000, Number(error.retryAfterMs) || 60000));
        log(`[verify] ${dataCenter} ${row.worldName}/${row.huntName} 次线路暂不可用：${error.message}`);
      }
    }
    const accepted = [];
    for (const row of rows) {
      const key = keyOf(row.worldName, row.huntName);
      const check = verified.get(key);
      if (!check) {
        accepted.push({ ...row, trustLevel: 'validated-single-source', verifiedRoutes: ['bear-lastDeathTimers'] });
        syncState.singleSourceRecords = (syncState.singleSourceRecords || 0) + 1;
        continue;
      }
      if (check.supplement) {
        accepted.push({ ...check.secondary, dataCenter, trustLevel: 'supplemental-single-source', verifiedRoutes: ['bear-huntInfo'] });
        syncState.singleSourceRecords = (syncState.singleSourceRecords || 0) + 1;
        continue;
      }
      if (check.comparison?.matches) {
        accepted.push({ ...row, trustLevel: 'corroborated', verifiedRoutes: ['bear-lastDeathTimers', 'bear-huntInfo'], corroboratedAt: new Date().toISOString() });
        syncState.corroboratedRecords = (syncState.corroboratedRecords || 0) + 1;
        continue;
      }
      const old = state.hunts?.[key];
      const oldTs = Number(old?.lastDeathTime) || 0;
      const secondaryTs = Number(check.secondary.lastDeathTime) || 0;
      const reason = oldTs && Math.abs(secondaryTs - oldTs) <= 120
        ? '第二线路与本地可信锚点一致，但批量接口返回值冲突'
        : '批量接口与定向查询的击杀时间不一致';
      store.appendQuarantine(dataCenter, { row, secondary: check.secondary, old: old || null, reason, checkedAt: new Date().toISOString() });
      syncState.quarantinedRecords = (syncState.quarantinedRecords || 0) + 1;
      log(`[guard] ${dataCenter} ${row.worldName}/${row.huntName} 多路线时间冲突，已隔离且不参与 CD 更新`);
    }
    for (const candidate of candidates.filter(item => item.supplement)) {
      const key = keyOf(candidate.worldName, candidate.huntName);
      const check = verified.get(key);
      if (check?.supplement && !accepted.some(row => keyOf(row.worldName, row.huntName) === key)) {
        accepted.push({ ...check.secondary, dataCenter, trustLevel: 'supplemental-single-source', verifiedRoutes: ['bear-huntInfo'] });
        syncState.singleSourceRecords = (syncState.singleSourceRecords || 0) + 1;
      }
    }
    return accepted;
  }

  async function runAnonymousSRankSync(reason = 'manual', dataCenterOverride = null) {
    if (syncPromise) return syncPromise;
    syncPromise = (async () => {
      await ensureResources();
      const definitions = sRankDefinitions();
      if (!definitions.length) throw new Error('本地 S 怪词库中没有找到 Rank=5 定义。');
      const syncPlan = buildSyncPlan(
        dataCenterOverride || cfg.watch.dataCenters || [],
        cfg.watch.worldSelections || {},
        resources,
        cfg.watch.worldSelections || {}
      );
      const selectedDcs = syncPlan.dataCenters;
      const selectedWorlds = syncPlan.worldSelections;
      const dcWorlds = syncPlan.groups.map(group => ({ dc: group.dataCenter, worlds: group.worlds }));

      // One progress target equals one actual selected world. S-rank definition
      // count is reported separately and never multiplies the progress total.
      const totalTargets = syncPlan.targetServers;
      const started = Date.now();
      Object.assign(syncState, {
        mode: 'anonymous-srank', status: 'running', running: true,
        dataCenters: selectedDcs, rank: 's', totalTargets, completed: 0,
        recordsFound: 0, unchangedRecords: 0, staleRecords: 0, validatedRecords: 0, rejectedRecords: 0, emptyDataCenters: 0, partialDataCenters: 0,
        noRecord: 0, errors: 0, quarantinedRecords: 0, corroboratedRecords: 0, singleSourceRecords: 0,
        startedAt: new Date(started).toISOString(), finishedAt: null,
        durationMs: 0, lastError: null, resourcesReady: true, reason,
        strategy: 'bulk-plus-targeted-verification', currentDataCenter: null, activeDataCenters: [], targetRequestBatches: syncPlan.targetRequests,
        phase: 'preparing', phaseLabel: '准备同步任务', progressPercent: 0,
        validatedTargets: 0, persistedTargets: 0, paused: false, pauseRequested: false, worldSelections: selectedWorlds,
        lastSuccessAt: syncState.lastSuccessAt || null,
        requestQueue: dcWorlds.reduce((sum, group) => sum + group.worlds.length, 0),
        worldResults: dcWorlds.flatMap(group => group.worlds.map(world => ({ dataCenter: group.dc, world, status: 'queued', records: 0, error: null }))),
        byDataCenter: {
          ...(syncState.byDataCenter || {}),
          ...Object.fromEntries(selectedDcs.map(dc => [dc, {
            ...(syncState.byDataCenter?.[dc] || {}), dataCenter: dc, status: 'queued', phase: 'queued',
            queuedAt: new Date(started).toISOString(), lastError: null
          }]))
        }
      });
      recalcSyncProgress();
      log(`[sync] 批量读取启动：${selectedDcs.join('、')}；${dcWorlds.length} 个大区请求批次、${totalTargets} 个已选服务器；进度分母不乘以 S 怪数量；大区服务器：${dcWorlds.map(item => `${item.dc}[${item.worlds.join('、')}]`).join('；')}`);

      const flushRows = (dataCenter, rows) => {
        if (!rows.length) return;
        const previous = store.loadDataCenterState(dataCenter);
        const events = [];
        for (const row of rows) {
          if (row.dataCenter !== dataCenter || dataCenterForWorld(row.worldName, resources) !== dataCenter) continue;
          const key = keyOf(row.worldName, row.huntName);
          const old = previous.hunts?.[key];
          const oldTs = Number(old?.lastDeathTime) || 0;
          if (Number(row.lastDeathTime) > oldTs) {
            events.push({
              source: row.source, event: 'bulk-timer', type: 'death', rank: 's', dataCenter,
              huntName: row.huntName, worldName: row.worldName,
              time: row.lastDeathTime, lastDeathTime: row.lastDeathTime,
              at: row.lastDeathAt, region: row.region, patch: row.patch,
              maint: row.maint, receivedAt: new Date().toISOString()
            });
          }
        }
        const applied = store.applyTimers(rows, keyOf, dataCenter);
        syncState.unchangedRecords = (Number(syncState.unchangedRecords) || 0) + (Number(applied.unchanged) || 0);
        syncState.staleRecords = (Number(syncState.staleRecords) || 0) + (Number(applied.stale) || 0);
        if (applied.rejected) {
          syncState.rejectedRecords = (Number(syncState.rejectedRecords) || 0) + applied.rejected;
          log(`[guard] ${dataCenter} 拒绝 ${applied.rejected} 条归属不匹配的数据，未写入任何大区缓存`);
        }
        for (const event of events) store.appendEvent(event);
        return applied;
      };

      const processDataCenter = async (group, groupIndex) => {

        await waitIfSyncPaused();
        syncState.requestQueue = Math.max(0, syncState.requestQueue);
        syncState.currentDataCenter = group.dc;
        syncState.activeDataCenters = [...new Set([...(syncState.activeDataCenters || []), group.dc])];
        updateDataCenterSyncState(group.dc, { status: 'running', phase: 'request', startedAt: new Date().toISOString(), lastError: null });
        syncState.phase = 'request'; syncState.phaseLabel = `正在读取 ${group.dc}：等待整区接口响应`;
        for (const world of group.worlds) updateWorldState(group.dc, world, 'requesting');
        log(`[sync] ${group.dc}: 批量查询 ${group.worlds.length} 个服务器`);
        try {
          let response;
          if (group.dc === '豆豆柴') {
            let liveResponse = null;
            let liveFailureError = null;
            let liveDetail;
            const allowedWorlds = new Set(group.worlds);
            try {
              await waitForRemoteSlot();
              liveResponse = await rest.liveDataCenter(group.dc);
              await waitIfSyncPaused();
              syncState.phase = 'validation'; syncState.phaseLabel = `正在校验 ${group.dc} Live 快照`;
              for (const world of group.worlds) updateWorldState(group.dc, world, 'validating');
              liveDetail = normalizeMainSiteLiveDetailed(liveResponse.json, resources, allowedWorlds);
            } catch (error) {
              liveFailureError = error;
              liveDetail = normalizeMainSiteLiveDetailed({ live: {} }, resources, allowedWorlds);
              log(`[sync] 豆豆柴 Live 读取失败：${error.message}；将尝试 Bear 批量备用接口`);
            }
            let rows = liveDetail.rows.map(row => ({ ...row, dataCenter: group.dc,
              huntName: mapToLocalName(row.huntName), timerResourcesFetchedAt: resourcesFetchedAt }));
            let rawRecords = liveDetail.rawCount;
            let parsedRecords = liveDetail.parsedCount;
            let rejectedRecords = liveDetail.rejectedCount;
            let sourceUsed = liveResponse ? 'main-site-live' : 'main-site-live-unavailable';
            const rawCounts = new Map(liveDetail.stats.map(item => [item.world, item.rawRecords]));
            const parsedCounts = new Map(liveDetail.stats.map(item => [item.world, item.parsedRecords]));
            const rejectedCounts = new Map(liveDetail.stats.map(item => [item.world, item.rejectedRecords]));
            const ignoredLiveCounts = new Map(liveDetail.stats.map(item => [item.world, item.ignoredNonSRank]));
            let bulkFallbackError = null;
            let bulkFallbackDiagnostics = null;

            // Live is the preferred 豆豆柴 route. If it fails, is structurally
            // invalid, or produces no validated S rows, perform exactly one
            // controlled batch fallback and retain diagnostics from both routes.
            if (!rows.length) {
              syncState.phaseLabel = `豆豆柴 Live 无有效记录，正在尝试 Bear 批量备用接口`;
              log(`[sync] 豆豆柴 Live：HTTP ${liveResponse?.status ?? '未取得响应'}，raw=${liveDetail.rawCount}，parsed=${liveDetail.parsedCount}，ignoredHunts=${liveDetail.ignoredHunts}，ignoredWorlds=${liveDetail.ignoredWorlds}；尝试批量备用读取`);
              try {
                await waitForRemoteSlot();
                const bulkRead = await readBatchWithWorldFallback({
                  worlds: group.worlds,
                  requestBatch: worlds => rest.lastDeathTimers(worlds, 'sRank'),
                  delayMs: Math.max(650, Number(cfg.watch.sRankRequestDelayMs) || 650),
                  sleep,
                  beforeFallback: () => waitForRemoteSlot(),
                  onFallbackError: error => {
                    if (Number(error.status) === 429) remoteCooldownUntil = Math.max(remoteCooldownUntil, Date.now() + Math.max(60000, Number(error.retryAfterMs) || 60000));
                  }
                });
                const bulkResponse = bulkRead.primary;
                const timers = bulkRead.timers;
                const parsedBulk = [];
                const rejectReasons = {};
                const rawWorldCounts = new Map(group.worlds.map(world => [world, 0]));
                const parsedWorldCounts = new Map(group.worlds.map(world => [world, 0]));
                const rejectedWorldCounts = new Map(group.worlds.map(world => [world, 0]));
                const sampleRows = [];
                let unknownWorldRows = 0;
                const unknownWorldNames = new Set();
                for (const timer of timers) {
                  const rawWorld = String(timer?.worldName || timer?.WorldName || timer?.World || '').trim();
                  if (rawWorldCounts.has(rawWorld)) rawWorldCounts.set(rawWorld, rawWorldCounts.get(rawWorld) + 1);
                  else { unknownWorldRows++; if (rawWorld) unknownWorldNames.add(rawWorld); }
                  const result = normalizeBulkTimerDetailed(timer, resources, allowedWorlds);
                  if (result.record) {
                    const normalized = result.record;
                    normalized.timerResourcesFetchedAt = resourcesFetchedAt;
                    normalized.dataCenter = group.dc;
                    normalized.huntName = mapToLocalName(normalized.huntName);
                    parsedBulk.push(normalized);
                    parsedWorldCounts.set(normalized.worldName, (parsedWorldCounts.get(normalized.worldName) || 0) + 1);
                  } else {
                    const reason = result.reason || 'unknown-rejection';
                    rejectReasons[reason] = (rejectReasons[reason] || 0) + 1;
                    if (result.worldName && rejectedWorldCounts.has(result.worldName)) rejectedWorldCounts.set(result.worldName, rejectedWorldCounts.get(result.worldName) + 1);
                  }
                  if (sampleRows.length < 3) sampleRows.push({
                    keys: timer && typeof timer === 'object' && !Array.isArray(timer) ? Object.keys(timer).slice(0, 16) : [],
                    huntName: timer?.huntName || timer?.HuntName || null,
                    worldName: timer?.worldName || timer?.WorldName || null,
                    lastDeathTimeType: timer?.lastDeathTime == null ? null : typeof timer.lastDeathTime,
                    isMaintType: Object.prototype.hasOwnProperty.call(timer || {}, 'isMaint') ? typeof timer.isMaint : 'omitted'
                  });
                }
                const deduped = new Map();
                for (const row of parsedBulk) {
                  const key = keyOf(row.worldName, row.huntName);
                  const old = deduped.get(key);
                  if (!old || row.lastDeathTime > old.lastDeathTime) deduped.set(key, row);
                }
                const bulkRows = [...deduped.values()];
                if (bulkRead.fallbackIssues.length) {
                  bulkFallbackError = new Error(`豆豆柴单服务器备用查询有 ${bulkRead.fallbackIssues.length} 项未完成：${bulkRead.fallbackIssues[0].error}`);
                  syncState.errors += bulkRead.fallbackErrors.length;
                  if (!syncState.lastError) syncState.lastError = bulkFallbackError.message;
                }
                // Commit raw response diagnostics before the all-rejected guard throws.
                const rawFallbackCount = timers.length;
                const parsedFallbackCount = parsedBulk.length;
                const rejectedFallbackCount = Math.max(0, rawFallbackCount - parsedFallbackCount);
                bulkFallbackDiagnostics = {
                  httpStatus: bulkResponse.status, payloadKeys: Object.keys(bulkResponse.json || {}).slice(0, 16),
                  timersType: 'array', rawRecords: rawFallbackCount, parsedRecords: parsedFallbackCount,
                  distinctRecords: bulkRows.length, rejectedRecords: rejectedFallbackCount,
                  rejectedByReason: rejectReasons, unknownWorldRows,
                  unknownWorldNames: [...unknownWorldNames].slice(0, 12), sampleRows,
                  primaryRawRecords: bulkRead.primaryTimers.length,
                  primaryReturnedWorlds: bulkRead.primaryReturnedWorlds,
                  requestDiagnostics: bulkResponse.requestDiagnostics || null,
                  perWorldFallback: bulkRead.fallbackDiagnostics,
                  perWorldFallbackErrors: bulkRead.fallbackIssues
                };
                rawRecords += rawFallbackCount;
                parsedRecords += parsedFallbackCount;
                rejectedRecords += rejectedFallbackCount;
                for (const world of group.worlds) {
                  rawCounts.set(world, (rawCounts.get(world) || 0) + (rawWorldCounts.get(world) || 0));
                  parsedCounts.set(world, (parsedCounts.get(world) || 0) + (parsedWorldCounts.get(world) || 0));
                  rejectedCounts.set(world, (rejectedCounts.get(world) || 0) + (rejectedWorldCounts.get(world) || 0));
                }
                // The batch may be empty for the whole DC; compare one-world
                // queries before declaring that the upstream has no data.
                assertBulkNormalization(timers, parsedBulk, `${group.dc} 备用批量接口`);
                rows = bulkRows;
                if (rows.length) sourceUsed = 'bear-lastDeathTimers-fallback';
              } catch (error) {
                bulkFallbackError = error;
                bulkFallbackDiagnostics = bulkFallbackDiagnostics || {
                  httpStatus: Number(error.response?.status || error.responseDetails?.status || error.status) || null,
                  contentType: error.response?.headers?.get?.('content-type') || error.responseDetails?.contentType || null,
                  payloadKeys: error.response?.json && typeof error.response.json === 'object' ? Object.keys(error.response.json).slice(0, 16) : (error.responseDetails?.payloadKeys || []),
                  rawRecords: error.response?.json?.timers?.length || 0,
                  parsedRecords: 0, rejectedRecords: 0,
                  responseSample: String(error.response?.text || error.responseDetails?.responseSample || error.body || '').slice(0, 600),
                  requestDiagnostics: error.response?.requestDiagnostics || null,
                  perWorldFallback: error.response?.fallbackDiagnostics || [],
                  perWorldFallbackErrors: error.response?.fallbackIssues || []
                };
                // If parsing rejected the complete raw batch, preserve row-level
                // details before showing an error. Never let failed rows count as success.
                if (!bulkFallbackDiagnostics && Array.isArray(error?.diagnostics?.timers)) {
                  bulkFallbackDiagnostics = error.diagnostics;
                }
                log(`[sync] 豆豆柴 Bear 批量备用读取未取得有效数据：${error.message}`);
              }
            }

            const byWorld = new Map(group.worlds.map(world => [world, rows.filter(row => row.worldName === world)]));
            const worldErrorStats = [];
            for (const world of group.worlds) {
              const worldRows = byWorld.get(world) || [];
              const raw = rawCounts.get(world) || 0;
              const parsed = parsedCounts.get(world) || 0;
              const rejected = rejectedCounts.get(world) || 0;
              const ignored = ignoredLiveCounts.get(world) || 0;
              const status = worldRows.length ? (rejected ? 'partial' : 'validated')
                : raw > 0 ? 'error' : bulkFallbackError ? 'error' : 'empty';
              const error = status === 'error'
                ? (raw > 0 ? '接口返回了原始计时条目，但没有通过 S 怪 / 时间 / CD 校验'
                  : bulkFallbackError?.message || liveFailureError?.message || null)
                : null;
              if (status === 'error') worldErrorStats.push({ world, error });
              const notes = [];
              if (!worldRows.length && raw === 0) notes.push('Live 与批量备用接口均未取得可用 S 怪计时记录');
              if (ignored) {
                const ignoredNames = (liveDetail.ignoredHuntNames || []).filter(item => item.world === world).slice(0, 5).map(item => `${item.hunt}(${item.rowCount ?? 0})`);
                notes.push(`Live 忽略 ${ignored} 个非 S / 未映射词条${ignoredNames.length ? `：${ignoredNames.join('、')}` : ''}`);
              }
              if (liveDetail.ignoredWorlds) notes.push(`Live 返回 ${liveDetail.ignoredWorlds} 个未选服务器`);
              if (liveFailureError) notes.push(`Live 接口错误：${liveFailureError.message}${liveFailureError.responseDetails ? ` · HTTP ${liveFailureError.responseDetails.status} · ${liveFailureError.responseDetails.contentType || 'unknown'} · fields=${liveFailureError.responseDetails.payloadKeys.join(',') || '无 JSON 字段'}` : ''}`);
              if (bulkFallbackDiagnostics?.rawRecords === 0) notes.push('备用批量接口 timers 数组为空');
              updateWorldState(group.dc, world, status, {
                rawRecords: raw, parsedRecords: parsed, distinctRecords: worldRows.length,
                records: worldRows.length, rejectedRecords: rejected,
                duplicateRecords: 0, isolatedRecords: 0,
                ignoredRecords: ignored, source: sourceUsed, error,
                httpStatus: bulkFallbackDiagnostics?.httpStatus || liveResponse?.status || null,
                responseDiagnostics: liveFailureError?.responseDetails || bulkFallbackDiagnostics || null,
                fallbackDiagnostics: bulkFallbackDiagnostics?.perWorldFallback?.find(item => item.world === world) || null,
                responseSample: bulkFallbackDiagnostics?.responseSample || liveFailureError?.responseDetails?.responseSample || null,
                note: notes.join('；') || null
              });
              syncState.validatedTargets += 1;
            }
            syncState.validatedRecords = (syncState.validatedRecords || 0) + rows.length;
            syncState.rejectedRecords = (syncState.rejectedRecords || 0) + rejectedRecords;
            recalcSyncProgress();
            syncState.phase = 'persist'; syncState.phaseLabel = `正在保存 ${group.dc} 的校验结果`;
            for (let offset = 0; offset < rows.length; offset += 25) {
              await waitIfSyncPaused();
              const chunk = rows.slice(offset, offset + 25);
              const applied = flushRows(group.dc, chunk);
              syncState.recordsFound += Number(applied?.applied) || 0;
              await sleep(0);
            }
            for (const world of group.worlds) {
              const worldRows = byWorld.get(world) || [];
              const raw = rawCounts.get(world) || 0;
              const parsed = parsedCounts.get(world) || 0;
              const rejected = rejectedCounts.get(world) || 0;
              const ignored = ignoredLiveCounts.get(world) || 0;
              const worldFallback = bulkFallbackDiagnostics?.perWorldFallback?.find(item => item.world === world) || null;
              const status = worldRows.length ? (rejected ? 'partial' : 'saved') : raw > 0 || bulkFallbackError ? 'error' : 'empty';
              updateWorldState(group.dc, world, status, {
                rawRecords: raw, parsedRecords: parsed, distinctRecords: worldRows.length,
                records: worldRows.length, rejectedRecords: rejected,
                duplicateRecords: 0, isolatedRecords: 0, ignoredRecords: ignored, source: sourceUsed,
                httpStatus: bulkFallbackDiagnostics?.httpStatus || liveResponse?.status || null,
                responseDiagnostics: liveFailureError?.responseDetails || bulkFallbackDiagnostics || null,
                fallbackDiagnostics: worldFallback,
                responseSample: bulkFallbackDiagnostics?.responseSample || liveFailureError?.responseDetails?.responseSample || null,
                error: status === 'error' ? (raw > 0 ? '存在原始记录，但均未通过时间 / CD 校验' : bulkFallbackError?.message || liveFailureError?.message || '读取失败') : null,
                note: [status === 'empty' ? `Live HTTP ${liveResponse?.status ?? '无响应'}；Live 世界数=${liveDetail.liveWorldNames?.length||0}，忽略世界=${liveDetail.ignoredWorlds}，忽略词条=${liveDetail.ignoredHunts}；备用 timers=${bulkFallbackDiagnostics?.rawRecords ?? '未取得'}` : null,
                  worldFallback ? `单服复核 ${worldFallback.status} · HTTP ${worldFallback.httpStatus ?? '未知'} · raw ${worldFallback.rawRecords ?? 0} · ${worldFallback.contentType || ''} · 字段 ${(worldFallback.payloadKeys||[]).join(',')} · ${worldFallback.error || ''}` : null].filter(Boolean).join('；') || null
              });
              if (worldRows.length) syncState.persistedTargets += 1;
              syncState.completed += 1;
              if (!worldRows.length) syncState.noRecord++;
              await sleep(0);
            }
            recalcSyncProgress();
            const hasRows = rows.length > 0;
            const hasRejectedOnly = !hasRows && (rawRecords > 0 || !!bulkFallbackError || !!liveFailureError);
            const hasPartial = rejectedRecords > 0 || worldErrorStats.length > 0 || !!liveFailureError;
            const dcStatus = hasRows ? (hasPartial ? 'partial' : 'completed') : hasRejectedOnly ? 'error' : 'empty';
            if (dcStatus === 'empty') syncState.emptyDataCenters = (syncState.emptyDataCenters || 0) + 1;
            if (dcStatus === 'partial') syncState.partialDataCenters = (syncState.partialDataCenters || 0) + 1;
            if (dcStatus === 'error') {
              syncState.errors++;
              if (!syncState.lastError) syncState.lastError = bulkFallbackError?.message || liveFailureError?.message || '豆豆柴接口返回数据，但解析 / CD 校验未通过';
            }
            syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
            scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
            const liveAt = new Date().toISOString();
            const diagnostic = {
              status: dcStatus, phase: dcStatus, lastSyncAt: liveAt,
              lastSuccessAt: hasRows ? liveAt : (syncState.byDataCenter?.[group.dc]?.lastSuccessAt || null),
              lastError: dcStatus === 'empty' ? 'Live 与 Bear 批量备用接口均返回 0 条 S 怪计时记录'
                : dcStatus === 'error' ? (bulkFallbackError?.message || liveFailureError?.message || '接口原始记录未通过解析 / CD 校验')
                : dcStatus === 'partial' ? `原始 ${rawRecords} 条，解析 ${parsedRecords} 条，有效 ${rows.length} 条，拒绝 ${rejectedRecords} 条` : null,
              recordsFound: rows.length, rawRecords, parsedRecords, rejectedRecords,
              sourceUsed, liveHttpStatus: liveResponse?.status || null,
              liveTopLevelKeys: liveDetail.liveTopLevelKeys,
              liveWorldNames: liveDetail.liveWorldNames,
              liveIgnoredWorlds: liveDetail.ignoredWorlds,
              liveIgnoredWorldNames: liveDetail.ignoredWorldNames,
              liveIgnoredHunts: liveDetail.ignoredHunts,
              liveIgnoredHuntNames: liveDetail.ignoredHuntNames,
              liveRawRecords: liveDetail.rawCount, liveParsedRecords: liveDetail.parsedCount,
              liveRejectedRecords: liveDetail.rejectedCount,
              liveFailure: liveFailureError?.message || null,
              liveFailureDiagnostics: liveFailureError?.responseDetails || null,
              bulkFallback: bulkFallbackDiagnostics,
              bulkFallbackError: bulkFallbackError?.message || null
            };
            updateDataCenterSyncState(group.dc, diagnostic);
            log(`[sync] 豆豆柴结束：source=${sourceUsed}，Live HTTP=${liveResponse?.status ?? 'failed'} raw=${liveDetail.rawCount}/parsed=${liveDetail.parsedCount}/rejected=${liveDetail.rejectedCount}/ignoredHunts=${liveDetail.ignoredHunts}/ignoredWorlds=${liveDetail.ignoredWorlds}，批量备用=${bulkFallbackDiagnostics?.rawRecords ?? '未取得'}，合计 raw=${rawRecords}/parsed=${parsedRecords}/accepted=${rows.length}/rejected=${rejectedRecords}，状态=${dcStatus}`);
            return;
          }
          try {
            await waitForRemoteSlot();
            response = await rest.lastDeathTimers(group.worlds, 'sRank');
          } catch (error) {
            // Compatibility fallback only for an explicitly unsupported endpoint.
            // Never fan out into hundreds of requests after auth/rate-limit/server errors.
            if (![404, 405, 501].includes(Number(error.status))) throw error;
            log(`[sync] ${group.dc}: 批量接口不支持，使用受限逐只查询兼容模式`);
            const tasks = [];
            for (const worldName of group.worlds) for (const item of definitions) tasks.push({ ...item, worldName });
            const extraFallbackTargets = Math.max(0, tasks.length - group.worlds.length);
            syncState.totalTargets += extraFallbackTargets;
            syncState.requestQueue += extraFallbackTargets;
            recalcSyncProgress();
            const rows = [];
            const recordsByWorld = new Map(group.worlds.map(world => [world, 0]));
            const failedByWorld = new Map();
            const concurrency = 1;
            let cursor = 0;
            let nextFallbackAt = 0;
            async function fallbackWorker() {
              while (cursor < tasks.length) {
                const task = tasks[cursor++];
                const wait = Math.max(0, nextFallbackAt - Date.now());
                if (wait) await sleep(wait);
                nextFallbackAt = Date.now() + Math.max(500, Number(cfg.watch.sRankRequestDelayMs) || 600);
                await waitForRemoteSlot();
                syncState.phase = 'fallback'; syncState.phaseLabel = `兼容逐只查询：${task.worldName} / ${task.name}`;
                let responseResolved = false;
                let validatedRecord = false;
                try {
                  const result = await rest.huntInfo(task.name, task.worldName);
                  responseResolved = true;
                  const normalized = normalizeHuntInfo(task.name, task.worldName, result.json, task.definition);
                  if (normalized) {
                    normalized.timerResourcesFetchedAt = resourcesFetchedAt;
                    normalized.dataCenter = group.dc;
                    normalized.huntName = mapToLocalName(normalized.huntName);
                    rows.push(normalized);
                    validatedRecord = true;
                    syncState.validatedRecords = (syncState.validatedRecords || 0) + 1;
                    recordsByWorld.set(task.worldName, (recordsByWorld.get(task.worldName) || 0) + 1);
                  }
                } catch (e) {
                  syncState.errors++;
                  failedByWorld.set(task.worldName, e.message);
                  if (!syncState.lastError) syncState.lastError = e.message;
                }
                if (responseResolved) syncState.completed++;
                if (validatedRecord) syncState.validatedTargets++;
                recalcSyncProgress();
                updateWorldState(group.dc, task.worldName, 'querying', { currentHunt: task.name, error: failedByWorld.get(task.worldName) || null });
                if (rows.length >= 20) { const batch = rows.splice(0); const applied = flushRows(group.dc, batch); syncState.recordsFound += Number(applied?.applied) || 0; }
                await sleep(0);
              }
            }
            await Promise.all(Array.from({length:concurrency},fallbackWorker));
            if (rows.length) { const applied = flushRows(group.dc, rows); syncState.recordsFound += Number(applied?.applied) || 0; }
            for (const world of group.worlds) {
              const failure = failedByWorld.get(world);
              const count = recordsByWorld.get(world) || 0;
              if (count > 0) syncState.persistedTargets++;
              updateWorldState(group.dc, world, failure ? 'error' : count ? 'saved' : 'empty', {
                rawRecords: count, parsedRecords: count, distinctRecords: count, records: count,
                rejectedRecords: 0, duplicateRecords: 0, isolatedRecords: 0,
                error: failure || null, note: !failure && !count ? '逐只查询已结束，但本轮没有有效 S 怪击杀记录' : null
              });
            }
            syncState.noRecord += [...recordsByWorld.values()].filter(count => count === 0).length;
            syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
            scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
            const fallbackRecords = [...recordsByWorld.values()].reduce((a, b) => a + b, 0);
            const fallbackAt = new Date().toISOString();
            const fallbackStatus = failedByWorld.size ? 'partial' : fallbackRecords ? 'completed' : 'empty';
            if (!fallbackRecords) syncState.emptyDataCenters = (syncState.emptyDataCenters || 0) + 1;
            if (failedByWorld.size) syncState.partialDataCenters = (syncState.partialDataCenters || 0) + 1;
            updateDataCenterSyncState(group.dc, { status: fallbackStatus, phase: fallbackStatus, lastSyncAt: fallbackAt, lastSuccessAt: fallbackRecords ? fallbackAt : (syncState.byDataCenter?.[group.dc]?.lastSuccessAt || null), lastError: failedByWorld.size ? [...failedByWorld.values()][0] : !fallbackRecords ? '逐只查询已完成，但没有返回有效计时记录' : null, recordsFound: fallbackRecords });
            return;
          }
          await waitIfSyncPaused();
          const batchRead = await readBatchWithWorldFallback({
            worlds: group.worlds,
            requestBatch: (worlds, requestInfo) => requestInfo.purpose === 'primary'
              ? Promise.resolve(response)
              : rest.lastDeathTimers(worlds, 'sRank'),
            delayMs: Math.max(650, Number(cfg.watch.sRankRequestDelayMs) || 650),
            sleep,
            beforeFallback: () => waitForRemoteSlot(),
            onFallbackError: error => {
              if (Number(error.status) === 429) remoteCooldownUntil = Math.max(remoteCooldownUntil, Date.now() + Math.max(60000, Number(error.retryAfterMs) || 60000));
            }
          });
          response = batchRead.primary;
          const payload = response.json;
          syncState.phase = 'validation'; syncState.phaseLabel = `正在校验 ${group.dc} 返回记录`;
          for (const world of group.worlds) updateWorldState(group.dc, world, 'validating');
          const allowedWorlds = new Set(group.worlds);
          const deduped = new Map();
          const sourceTimers = batchRead.timers;
          const rawWorldCounts = new Map(group.worlds.map(world => [world, 0]));
          const parsedRows = [];
          const rejectReasons = {};
          const unknownWorldNames = new Set();
          const sampleRows = [];
          for (let index = 0; index < sourceTimers.length; index++) {
            const timer = sourceTimers[index];
            const rawWorld = String(timer?.worldName || timer?.WorldName || timer?.World || '').trim();
            if (rawWorldCounts.has(rawWorld)) rawWorldCounts.set(rawWorld, rawWorldCounts.get(rawWorld) + 1);
            else if (rawWorld) unknownWorldNames.add(rawWorld);
            const detailed = normalizeBulkTimerDetailed(timer, resources, allowedWorlds);
            const normalized = detailed.record;
            if (normalized) {
              normalized.timerResourcesFetchedAt = resourcesFetchedAt;
              normalized.dataCenter = group.dc;
              normalized.huntName = mapToLocalName(normalized.huntName);
              parsedRows.push(normalized);
              const key = keyOf(normalized.worldName, normalized.huntName);
              const previous = deduped.get(key);
              if (!previous || normalized.lastDeathTime > previous.lastDeathTime) deduped.set(key, normalized);
            } else {
              const reason = detailed.reason || 'unknown-rejection';
              rejectReasons[reason] = (rejectReasons[reason] || 0) + 1;
            }
            if (sampleRows.length < 3) sampleRows.push({ keys: timer && typeof timer === 'object' && !Array.isArray(timer) ? Object.keys(timer).slice(0, 16) : [], huntName: timer?.huntName || timer?.HuntName || null, worldName: timer?.worldName || timer?.WorldName || null, lastDeathTimeType: timer?.lastDeathTime == null ? null : typeof timer.lastDeathTime, isMaintType: Object.prototype.hasOwnProperty.call(timer || {}, 'isMaint') ? typeof timer.isMaint : 'omitted' });
            if ((index + 1) % 80 === 0) { syncState.validationRecords = index + 1; await sleep(0); }
          }
          const distinctRows = [...deduped.values()];
          let normalization;
          try {
            normalization = assertBulkNormalization(sourceTimers, parsedRows, group.dc);
          } catch (error) {
            // Preserve per-world raw/parsed diagnostics even when the complete
            // batch is rejected. Otherwise the control center would show only
            // "0 records" and hide the exact parser mismatch that caused it.
            const diagnosticStats = summarizeBulkWorlds(group.worlds, sourceTimers, parsedRows, distinctRows, []);
            const diagnosticSample = {
              httpStatus: response.status,
              payloadKeys: Object.keys(payload || {}).slice(0, 20),
              timersType: Array.isArray(sourceTimers) ? 'array' : typeof sourceTimers,
              rawRecords: sourceTimers.length, parsedRecords: parsedRows.length,
              rejectedRecords: Math.max(0, sourceTimers.length - parsedRows.length),
              rejectReasons, unknownWorldNames: [...unknownWorldNames].slice(0, 20), sampleRows
            };
            updateDataCenterSyncState(group.dc, { status: 'error', phase: 'error', responseDiagnostics: diagnosticSample, rawRecords: diagnosticSample.rawRecords, parsedRecords: diagnosticSample.parsedRecords, rejectedRecords: diagnosticSample.rejectedRecords, lastError: error.message });
            for (const stat of diagnosticStats) {
              const knownRaw = rawWorldCounts.get(stat.world) ?? stat.rawRecords;
              updateWorldState(group.dc, stat.world, stat.status, {
                rawRecords: knownRaw,
                parsedRecords: stat.parsedRecords,
                distinctRecords: stat.distinctRecords,
                records: 0,
                rejectedRecords: stat.rejectedRecords,
                duplicateRecords: stat.duplicateRecords,
                isolatedRecords: stat.isolatedRecords,
                rejectReasons,
                httpStatus: response.status,
                error: stat.error || error.message,
                note: `${stat.note || ''}${unknownWorldNames.size ? `；另有 ${unknownWorldNames.size} 个返回服务器名不在本次选择内` : ''}`
              });
            }
            syncState.rejectedRecords = (syncState.rejectedRecords || 0) + Math.max(0, sourceTimers.length - parsedRows.length);
            throw error;
          }
          if (normalization.rejectedCount) {
            syncState.rejectedRecords = (syncState.rejectedRecords || 0) + normalization.rejectedCount;
            log(`[guard] ${group.dc}: 原始 ${normalization.rawCount} 条，解析通过 ${normalization.parsedCount} 条，拒绝 ${normalization.rejectedCount} 条；原因=${JSON.stringify(rejectReasons)}`);
          }
          const responseDiagnostics = {
            httpStatus: response.status,
            payloadKeys: Object.keys(payload || {}).slice(0, 20),
            timersType: 'array', rawRecords: sourceTimers.length,
            sampleRows, unknownWorldNames: [...unknownWorldNames].slice(0, 20), rejectReasons,
            responseSample: String(response.text || '').slice(0, 600),
            contentType: response.headers?.get?.('content-type') || null,
            responseDate: response.headers?.get?.('date') || null,
            primaryRawRecords: batchRead.primaryTimers.length,
            primaryReturnedWorlds: batchRead.primaryReturnedWorlds,
            perWorldFallback: batchRead.fallbackDiagnostics,
            perWorldFallbackErrors: batchRead.fallbackIssues,
            requestWorlds: group.worlds,
            requestDiagnostics: response.requestDiagnostics || null
          };
          log(`[api] ${group.dc} /api/lastDeathTimers HTTP ${response.status}，batch=${batchRead.primaryTimers.length} 条 / ${batchRead.primaryReturnedWorlds} 台服务器；单服备用=${batchRead.fallbackDiagnostics.length} 台；合计 timers=${sourceTimers.length}；payloadKeys=${responseDiagnostics.payloadKeys.join(',')}；样本=${JSON.stringify(sampleRows.slice(0, 2))}`);
          let rows = await verifySuspiciousRows(group.dc, distinctRows, definitions);
          syncState.validatedRecords = (syncState.validatedRecords || 0) + rows.length;
          const byWorld = new Map(group.worlds.map(world => [world, rows.filter(row => row.worldName === world)]));
          const worldStats = summarizeBulkWorlds(group.worlds, sourceTimers, parsedRows, distinctRows, rows);
          for (const stat of worldStats) {
            const worldRows = byWorld.get(stat.world) || [];
            const splitFallback = batchRead.fallbackDiagnostics.find(item => item.world === stat.world);
            const worldStatus = splitFallback && splitFallback.status !== 'completed' && stat.rawRecords === 0 ? 'error' : stat.status;
            updateWorldState(group.dc, stat.world, worldStatus, {
              rawRecords: rawWorldCounts.get(stat.world) || stat.rawRecords,
              parsedRecords: stat.parsedRecords, distinctRecords: stat.distinctRecords, records: worldRows.length,
              rejectedRecords: stat.rejectedRecords, duplicateRecords: stat.duplicateRecords, isolatedRecords: stat.isolatedRecords,
              rejectReasons,
              httpStatus: response.status,
              responseDiagnostics,
              fallbackDiagnostics: splitFallback,
              error: stat.error || splitFallback?.error || null,
              note: [stat.note, splitFallback ? `单服务器备用读取 ${splitFallback.status} · HTTP ${splitFallback.httpStatus ?? '失败'} · raw=${splitFallback.rawRecords} · ${splitFallback.contentType || '未知内容类型'} · 字段=${(splitFallback.payloadKeys || []).join(',') || '无'}${splitFallback.error ? ` · ${splitFallback.error}` : ''}` : null].filter(Boolean).join('；') || null
            });
            if (stat.records > 0) syncState.validatedTargets += 1;
            recalcSyncProgress();
            await sleep(0);
          }
          syncState.phase = 'persist'; syncState.phaseLabel = `正在保存 ${group.dc} 的校验结果`;
          for (let offset = 0; offset < rows.length; offset += 25) {
            await waitIfSyncPaused();
            const chunk = rows.slice(offset, offset + 25);
            const applied = flushRows(group.dc, chunk);
            syncState.recordsFound += Number(applied?.applied) || 0;
            const touchedWorlds = [...new Set(chunk.map(row => row.worldName))];
            for (const world of touchedWorlds) updateWorldState(group.dc, world, 'saving', { records: (byWorld.get(world) || []).length });
            await sleep(0);
          }
          for (const stat of worldStats) {
            const splitFallback = batchRead.fallbackDiagnostics.find(item => item.world === stat.world);
            const worldStatus = splitFallback && splitFallback.status !== 'completed' && stat.rawRecords === 0 ? 'error' : stat.status;
            updateWorldState(group.dc, stat.world, worldStatus, {
              rawRecords: stat.rawRecords, parsedRecords: stat.parsedRecords,
              distinctRecords: stat.distinctRecords, records: stat.records,
              rejectedRecords: stat.rejectedRecords, duplicateRecords: stat.duplicateRecords,
              isolatedRecords: stat.isolatedRecords, rejectReasons, httpStatus: response.status,
              responseDiagnostics, fallbackDiagnostics: splitFallback,
              error: stat.error || splitFallback?.error || null,
              note: [stat.note, splitFallback ? `单服务器备用读取 ${splitFallback.status} · HTTP ${splitFallback.httpStatus ?? '失败'} · raw=${splitFallback.rawRecords} · ${splitFallback.contentType || '未知内容类型'} · 字段=${(splitFallback.payloadKeys || []).join(',') || '无'}${splitFallback.error ? ` · ${splitFallback.error}` : ''}` : null].filter(Boolean).join('；') || null
            });
            if ((byWorld.get(stat.world) || []).length) syncState.persistedTargets += 1;
            syncState.completed += 1;
            recalcSyncProgress();
            await sleep(0);
          }
          syncState.noRecord += worldStats.filter(stat => stat.records === 0).length;
          const splitFallbackIssues = batchRead.fallbackIssues.length;
          const splitFallbackErrors = batchRead.fallbackErrors.length;
          if (splitFallbackErrors) syncState.errors += splitFallbackErrors;
          const dcSyncStatus = rows.length === 0
            ? (normalization.status === 'empty' && !splitFallbackIssues ? 'empty' : 'error')
            : (normalization.status === 'partial' || splitFallbackIssues || worldStats.some(stat => ['partial', 'error', 'isolated'].includes(stat.status)) ? 'partial' : 'completed');
          if (dcSyncStatus === 'empty') syncState.emptyDataCenters = (syncState.emptyDataCenters || 0) + 1;
          if (dcSyncStatus === 'partial') syncState.partialDataCenters = (syncState.partialDataCenters || 0) + 1;
          log(`[sync] ${group.dc}: 批量 raw ${batchRead.primaryTimers.length} 条；单服备用 ${batchRead.fallbackDiagnostics.length} 台；合计 raw ${sourceTimers.length} 条，字段解析通过 ${parsedRows.length} 条，可信接受 ${rows.length} 条，字段拒绝 ${normalization.rejectedCount} 条`);
          syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
          scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
          const completedAt = new Date().toISOString();
          updateDataCenterSyncState(group.dc, {
            status: dcSyncStatus, phase: dcSyncStatus, lastSyncAt: completedAt,
            lastSuccessAt: rows.length ? completedAt : (syncState.byDataCenter?.[group.dc]?.lastSuccessAt || null),
            lastError: dcSyncStatus === 'empty' ? `整区批量及 ${batchRead.fallbackWorlds} 个单服务器备用查询均返回空数组；不能证明已取得 CD 数据` : dcSyncStatus === 'error' ? `批量 / 单服务器查询异常：${batchRead.fallbackIssues[0]?.error || '无有效数据'}` : dcSyncStatus === 'partial' ? `原始 ${sourceTimers.length} 条，字段解析 ${parsedRows.length} 条，可信接受 ${rows.length} 条` : null,
            recordsFound: rows.length, rawRecords: sourceTimers.length, parsedRecords: parsedRows.length,
            rejectedRecords: normalization.rejectedCount,
            responseDiagnostics,
            primaryRawRecords: batchRead.primaryTimers.length,
            perWorldFallback: batchRead.fallbackDiagnostics,
            perWorldFallbackErrors: batchRead.fallbackIssues,
            corroboratedRecords: rows.filter(row => row.trustLevel === 'corroborated').length,
            singleSourceRecords: rows.filter(row => row.trustLevel === 'validated-single-source').length
          });
        } catch (error) {
          syncState.errors++;
          const status = Number(error.status) || 0;
          if (!syncState.lastError) syncState.lastError = status ? `HTTP ${status}：${error.message}` : error.message;
          const responseInfo = error.response || null;
          const responseDiagnostics = responseInfo || error.responseDetails ? {
            httpStatus: responseInfo?.status || error.responseDetails?.status || status || null,
            payloadKeys: responseInfo?.json && typeof responseInfo.json === 'object'
              ? Object.keys(responseInfo.json).slice(0, 16) : (error.responseDetails?.payloadKeys || []),
            contentType: responseInfo?.headers?.get?.('content-type') || error.responseDetails?.contentType || null,
            responseDate: responseInfo?.headers?.get?.('date') || null,
            responseSample: String(responseInfo?.text || error.responseDetails?.responseSample || error.body || '').slice(0, 600),
            requestWorlds: group.worlds,
            error: error.message
          } : null;
          updateDataCenterSyncState(group.dc, { status: 'error', phase: 'error', lastSyncAt: new Date().toISOString(), lastError: error.message,
            responseDiagnostics, rawRecords: 0, parsedRecords: 0, rejectedRecords: 0,
            retryAt: new Date(Date.now() + Math.max(5 * 60 * 1000, Number(error.retryAfterMs) || 15 * 60 * 1000)).toISOString() });
          log(`[sync] ${group.dc} 批量读取失败：${error.message}${responseDiagnostics ? `；HTTP=${responseDiagnostics.httpStatus}；Content-Type=${responseDiagnostics.contentType || 'unknown'}；payloadKeys=${responseDiagnostics.payloadKeys.join(',')}；response=${responseDiagnostics.responseSample}` : ''}`);
          // Mark only this DC's targets as attempted. Existing cached data is never cleared.
          for (const world of group.worlds) updateWorldState(group.dc, world, 'error', {
            error: error.message, httpStatus: responseDiagnostics?.httpStatus || status || null,
            responseDiagnostics, responseSample: responseDiagnostics?.responseSample || null,
            note: responseDiagnostics ? `HTTP ${responseDiagnostics.httpStatus || '未知'} · ${responseDiagnostics.contentType || 'unknown'} · fields=${responseDiagnostics.payloadKeys.join(',') || '无 JSON 字段'} · ${responseDiagnostics.responseSample}` : error.message
          });
          syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
          // Failed requests are errors, not completed/validated/persisted targets.
          recalcSyncProgress();
          dcNextPollAt.set(group.dc, Date.now() + Math.max(5 * 60 * 1000, Number(error.retryAfterMs) || 15 * 60 * 1000));
          if (status === 429) {
            const retry = Number(error.retryAfterMs) || 60000;
            remoteCooldownUntil = Math.max(remoteCooldownUntil, Date.now() + Math.max(60000, retry));
            log(`[rate-limit] Bear Tracker 限流，暂停后续大区请求 ${Math.ceil(retry/1000)} 秒`);
            await sleep(Math.min(15 * 60 * 1000, Math.max(60000, retry)));
          }
        }
            };
      const dcWorkerCount = Math.min(DC_CONCURRENCY, dcWorlds.length);
      syncState.strategy = `bulk-plus-targeted-verification;dc-concurrency-${dcWorkerCount}`;
      await runWithConcurrency(dcWorlds, dcWorkerCount, async (group, index) => {
        try { await processDataCenter(group, index); }
        finally {
          syncState.activeDataCenters = (syncState.activeDataCenters || []).filter(dc => dc !== group.dc);
        }
      });
      const ended = Date.now();
      const finalStatus = syncState.errors && !syncState.validatedRecords ? 'error'
        : syncState.errors || syncState.partialDataCenters ? 'partial'
        : syncState.validatedRecords ? 'completed' : 'empty';
      const finalLabel = finalStatus === 'error' ? '同步校验失败；没有可信记录写入，旧缓存保留'
        : finalStatus === 'partial' ? '同步部分完成；请检查逐服务器拒绝 / 隔离诊断'
        : finalStatus === 'empty' ? '接口响应已处理，但本轮 0 条有效记录；缓存未变。请检查 Bear 原始响应 / 服务器筛选（不是数据同步成功）'
        : syncState.recordsFound > 0 ? `同步已核验：本轮实际新增 / 更新 ${syncState.recordsFound} 条记录` 
        : `取得 ${syncState.validatedRecords} 条有效记录，其中 ${syncState.unchangedRecords || 0} 条与本地一致；未产生新的 CD 变更`;
      Object.assign(syncState, {
        status: finalStatus,
        running: false, currentDataCenter: null, activeDataCenters: [], phase: finalStatus, phaseLabel: finalLabel,
        progressPercent: syncState.progressPercent || 0, requestQueue: 0, paused: false, pauseRequested: false,
        finishedAt: new Date(ended).toISOString(), lastSyncAt: new Date(ended).toISOString(),
        lastSuccessAt: syncState.validatedRecords > 0 ? new Date(ended).toISOString() : (syncState.lastSuccessAt || null),
        durationMs: ended - started
      });
      recalcSyncProgress();
      log(`[sync] 批量同步结束：新增/更新候选 ${syncState.recordsFound} 条；无记录 ${syncState.noRecord} 项；失败大区/批次 ${syncState.errors}；耗时 ${(syncState.durationMs/1000).toFixed(1)} 秒`);
      return { ...syncState, records: syncState.recordsFound };
    })().catch(error => {
      syncState.status = 'error'; syncState.running = false; syncState.lastError = error.message;
      syncState.phase = 'error'; syncState.phaseLabel = '同步异常'; syncState.paused = false; syncState.pauseRequested = false;
      syncState.finishedAt = new Date().toISOString(); syncState.lastSyncAt = syncState.finishedAt;
      log(`[sync] S 怪同步失败：${error.message}`); throw error;
    }).finally(() => { syncPromise = null; });
    return syncPromise;
  }

  async function updateAliases(aliases) {
    const db = resources?.DatabaseHunt || {};
    const next = {};
    const used = new Set();
    for (const [localRaw, remoteRaw] of Object.entries(aliases || {})) {
      const localName = String(localRaw || '').trim();
      const trackerName = String(remoteRaw || '').trim();
      if (!localName || !trackerName) continue;
      if (!db[trackerName]) throw Object.assign(new Error(`Bear Tracker 词库中不存在：${trackerName}`), { status: 400 });
      if (Number(db[trackerName].Rank) !== 5) throw Object.assign(new Error(`${trackerName} 不是 Rank=5 的 S 怪，不能绑定。`), { status: 400 });
      if (used.has(trackerName)) throw Object.assign(new Error(`同一个 Bear S 怪不能重复绑定：${trackerName}`), { status: 400 });
      used.add(trackerName);
      next[localName] = trackerName;
    }
    cfg.aliases = next;
    config.save(cfg);
    return { count: Object.keys(next).length };
  }

  async function updateDataCenters(dataCenters, worldSelections = null) {
    // Existing DC selections are preserved; newly selected DCs default to all
    // their worlds. Unselected DCs and their world choices are removed.
    const next = validateDataCenters(dataCenters);
    const normalizedWorldSelections = normalizeWorldSelections(
      next,
      worldSelections,
      resources,
      cfg.watch.worldSelections || {}
    );
    cfg.watch.dataCenters = next;
    cfg.watch.worldSelections = normalizedWorldSelections;
    cfg.watch.worlds = [...new Set(Object.values(normalizedWorldSelections).flat())];
    cfg.watch.selectionConfirmed = true;
    config.save(cfg);
    setImmediate(async () => {
      try { if (syncPromise) await syncPromise; await runAnonymousSRankSync('data-center-change'); } catch (error) { log(`[sync] 大区/服务器选择变更后的自动同步失败：${error.message}`); }
    });
    return { dataCenters: next, worldSelections: normalizedWorldSelections };
  }

  const localServer = new LocalServer({
    cfg, rest, store, socket: null, log,
    updateAliases, updateDataCenters, pauseSync, resumeSync,
    getStatus: (stateSnapshot = store.loadState()) => ({
      mode: 'anonymous-srank', authenticated: false, username: null,
      socketConnected: false, timerCount: Object.values(stateSnapshot.hunts || {}).filter(row => row.rank === 's').length,
      cacheUpdatedAt: stateSnapshot.updatedAt || null,
      aliasCount: Object.keys(cfg.aliases || {}).length,
      sRankDefinitionCount: sRankDefinitions().length,
      dataCenters: cfg.watch.dataCenters || [],
      worldSelections: cfg.watch.worldSelections || {},
      sync: { ...syncState },
      bridgeVersion: BRIDGE_VERSION,
      resourcesReady: remoteReady && timerResourcesAreFresh(),
      timerResourcesFetchedAt: resourcesFetchedAt || null
    })
  }).start();

  localServer.on('manualSync', dataCenters => {
    runAnonymousSRankSync('manual', Array.isArray(dataCenters) && dataCenters.length ? dataCenters : null).catch(() => {});
  });

  // Start the localhost server first. Network initialization and the full scan are background tasks.
  (async () => {
    try {
      await ensureResources();
      if (cfg.watch.selectionConfirmed === true && (cfg.watch.dataCenters || []).length) await runAnonymousSRankSync('startup');
      else { syncState.status = 'ready'; log('[startup] 尚未选择监控大区；仅准备本地词库，不启动全量扫描。'); }
    } catch (error) {
      syncState.status = 'error';
      syncState.running = false;
      syncState.lastError = error.message;
      log(`[init] Bear Tracker 匿名初始化失败：${error.message}；本地接口仍保持运行，可稍后点击“立即同步”。`);
    }
  })();

  // Lightweight scheduler tick; each data center has its own next-check time derived
  // from its S-rank respawn windows. Unknown anchors retain a conservative 15-minute check.
  const refreshTimer = setInterval(() => {
    if (!remoteReady || cfg.watch.selectionConfirmed !== true || !(cfg.watch.dataCenters || []).length || syncPromise) return;
    const now = Date.now();
    const due = (cfg.watch.dataCenters || []).filter(dc => !dcNextPollAt.has(dc) || dcNextPollAt.get(dc) <= now);
    if (due.length) runAnonymousSRankSync('cd-scheduled', due).catch(() => {});
  }, 60 * 1000);

  const shutdown = () => {
    log('[exit] 正在关闭本地 S 怪同步桥接');
    clearInterval(refreshTimer);
    localServer.stop();
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  log(`[ready] 免登录 S 怪桥接服务：http://${cfg.local.host}:${cfg.local.port}；数据中心=${(cfg.watch.dataCenters || []).join('、')}`);
}

async function main() {
  const mode = process.argv[2] || 'serve';
  if (mode === 'serve') return runServe();
  if (mode === 'sync') {
    const rest = new TrackerRest(cfg, log);
    const store = new Store(cfg);
    await rest.bootstrap();
    const resources = await getResources(rest, store);
    const worlds = worldsFor(resources);
    const targets = Object.entries(resources.DatabaseHunt).filter(([, row]) => Number(row?.Rank) === 5);
    console.log(JSON.stringify({ mode: 'anonymous-srank', sRankCount: targets.length, worlds, instruction: '启动服务请运行 node src/index.js' }, null, 2));
    return;
  }
  console.log('仅支持：node src/index.js（启动）或 node src/index.js sync（检查匿名资源）。');
}

main().catch(error => { console.error(`[FATAL] ${error.message}`); process.exitCode = 1; });
