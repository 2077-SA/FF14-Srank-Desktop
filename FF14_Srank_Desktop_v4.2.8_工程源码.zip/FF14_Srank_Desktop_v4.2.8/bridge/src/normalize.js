'use strict';

const RANK_BY_CODE = { 1: 'a', 2: 'b', 3: 'b+', 5: 's' };
const first = (obj, keys) => {
  for (const key of keys) if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  return null;
};


function toBoolean(value, fallback = false) {
  if (value === true || value === 1) return true;
  if (value === false || value === 0) return false;
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (['true', '1', 'yes', 'on'].includes(normalized)) return true;
    if (['false', '0', 'no', 'off', ''].includes(normalized)) return false;
  }
  return fallback;
}

function getTimerWindowParts(window) {
  if (!window || typeof window !== 'object') return null;
  const minHours = Number(window.minHours);
  const maxHours = Number(window.maxHours);
  const startTs = Number(window.startTs);
  const endTs = Number(window.endTs);
  if (!Number.isFinite(minHours) || !Number.isFinite(maxHours) || minHours <= 0 || maxHours < minHours
      || !Number.isFinite(startTs) || !Number.isFinite(endTs) || endTs <= startTs) return null;
  return { minHours, windowHours: maxHours - minHours, maxHours, startTs, endTs };
}

function toUnixSeconds(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'string' && !/^\d+(?:\.\d+)?$/.test(value)) {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : null;
  }
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.floor(n > 1e12 ? n / 1000 : n);
}

function isoFromUnix(value) {
  const sec = toUnixSeconds(value);
  if (!sec) return null;
  const d = new Date(sec * 1000);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

function getHuntDefinition(name, resources) {
  const db = resources?.DatabaseHunt || {};
  if (!name) return null;
  if (db[name]) return db[name];
  const needle = String(name).toLowerCase();
  const key = Object.keys(db).find(k => String(k).toLowerCase() === needle);
  return key ? db[key] : null;
}

function computeWindow(lastDeathValue, definition, isMaint) {
  const base = toUnixSeconds(lastDeathValue);
  if (typeof isMaint !== 'boolean') return null;
  const arr = isMaint ? definition?.MaintTimer : definition?.RespawnTimer;
  if (!base || !Array.isArray(arr) || arr.length < 2) return null;
  const minH = Number(arr[0]);
  const maxH = Number(arr[1]);
  if (!Number.isFinite(minH) || !Number.isFinite(maxH) || minH <= 0 || maxH < minH || maxH > 500) return null;
  return {
    start: isoFromUnix(base + minH * 3600),
    end: isoFromUnix(base + maxH * 3600),
    startTs: base + minH * 3600,
    endTs: base + maxH * 3600,
    minHours: minH,
    maxHours: maxH
  };
}

/** Derive a CD window only when the record carries an explicit maintenance state. */
function computeRecordWindow(record, definition, timeOverride) {
  if (!record || typeof record.maint !== 'boolean') return null;
  const timestamp = timeOverride !== undefined ? timeOverride
    : first(record, ['lastDeathTime', 'lastDeath', 'time', 'timestamp']);
  return computeWindow(timestamp, definition, record.maint);
}

function normalizeEvent(name, payload, resources) {
  const p = payload && typeof payload === 'object' ? payload : {};
  const hunt = first(p, ['Hunt', 'HuntName', 'hunt', 'huntName', 'Name']);
  const fate = first(p, ['Fate', 'FATE', 'FateName', 'fateName']);
  const huntName = hunt || fate;
  const worldName = first(p, ['World', 'WorldName', 'world', 'worldName']);
  const def = getHuntDefinition(huntName, resources) || getHuntDefinition(fate, resources);
  const rankCode = first(def, ['Rank', 'rank']);
  const rank = RANK_BY_CODE[Number(rankCode)] || (typeof rankCode === 'string' ? rankCode.toLowerCase() : null);
  const rawTime = first(p, ['Time', 'ReportTime', 'Timestamp', 'time', 'timestamp']);
  const time = toUnixSeconds(rawTime);
  const base = { source: 'socket', event: name, receivedAt: new Date().toISOString() };

  switch (name) {
    case 'DeathReport': {
      const mark = toUnixSeconds(first(p, ['LastMarkTime', 'lastMarkTime', 'LastDeathTime']));
      const maint = toBoolean(first(p, ['MaintState', 'IsMaint', 'isMaint', 'maint']), null);
      return {
        ...base, type: 'death', huntName, worldName, time, at: isoFromUnix(time), rank,
        region: def?.Region || def?.region || null, patch: def?.Patch || def?.patch || null,
        missing: Number(first(p, ['MissingCounter', 'Missing', 'missingCounter'])) || 0,
        maint, lastMarkTime: mark,
        // Missing maintenance state is unknown, not equivalent to normal operation.
        window: def && maint !== null ? computeWindow(mark || time, def, maint) : null,
        raw: p
      };
    }
    case 'FoundReport':
      return { ...base, type: 'found', huntName, worldName, time, at: isoFromUnix(time), rank,
        progress: first(p, ['Progress', 'progress']), position: first(p, ['Position', 'position']),
        reporter: first(p, ['Reporter', 'reporter']), patch: def?.Patch || null, raw: p };
    case 'FATEUpdate':
      return { ...base, type: 'fate', huntName, worldName, time, at: isoFromUnix(time),
        progress: first(p, ['Progress', 'progress']), raw: p };
    case 'SRankFATEUpdate': {
      const lastSeen = toUnixSeconds(first(p, ['LastSeen', 'lastSeen']));
      const lastDeath = toUnixSeconds(first(p, ['LastDeath', 'lastDeath', 'LastDeathTime']));
      return { ...base, type: 'srank_fate', huntName, worldName, rank,
        lastSeen, lastDeath, time: lastDeath || lastSeen, at: isoFromUnix(lastDeath || lastSeen), raw: p };
    }
    case 'SRankMappingReport':
      return { ...base, type: 'spawnpoint', huntName, worldName,
        position: first(p, ['Position', 'position']), time, at: isoFromUnix(time),
        verified: Boolean(first(p, ['Verified', 'verified'])), reporter: first(p, ['Reporter', 'reporter']),
        notification: first(p, ['Notification', 'notification']), raw: p };
    default:
      return { ...base, type: 'unknown', payload: p };
  }
}

function normalizeTimer(timer, resources) {
  const t = timer && typeof timer === 'object' ? timer : {};
  const huntName = first(t, ['huntName', 'HuntName', 'Hunt', 'hunt', 'name']);
  const worldName = first(t, ['worldName', 'WorldName', 'World', 'world']);
  const def = getHuntDefinition(huntName, resources) || getHuntDefinition(first(t, ['huntKey', 'HuntKey']), resources);
  const lastDeath = toUnixSeconds(first(t, ['lastDeathTime', 'LastDeathTime', 'lastDeath', 'LastDeath', 'Time']));
  const lastMark = toUnixSeconds(first(t, ['lastMarkTime', 'LastMarkTime', 'LastMark']));
  const isMaint = toBoolean(first(t, ['isMaint', 'IsMaint', 'MaintState', 'maint']), null);
  const rankCode = first(def, ['Rank', 'rank']);
  return {
    huntName: huntName || null,
    huntKey: first(t, ['huntKey', 'HuntKey']) || huntName || null,
    worldName: worldName || null,
    instance: Number(first(t, ['instance', 'Instance'])) || 0,
    rank: RANK_BY_CODE[Number(rankCode)] || null,
    rankCode: rankCode == null ? null : Number(rankCode),
    region: def?.Region || def?.region || null,
    patch: def?.Patch || def?.patch || null,
    lastDeathTime: lastDeath,
    lastDeathAt: isoFromUnix(lastDeath),
    lastMarkTime: lastMark,
    missingCounter: Number(first(t, ['missingCounter', 'MissingCounter', 'Missing'])) || 0,
    maint: isMaint,
    reporter: first(t, ['reporter', 'Reporter']) || null,
    window: def && isMaint !== null ? computeWindow(lastMark || lastDeath, def, isMaint) : null,
    updatedAt: new Date().toISOString()
  };
}

const TIME_KEYS = new Set([
  'time', 'reporttime', 'timestamp', 'datetime', 'date', 'death', 'deathtime',
  'lastdeath', 'lastdeathtime', 'reportedat', 'createdat', 'created', 'occurredat',
  'unix', 'unixtime', 'epoch', 'value'
]);
const CONTAINER_KEYS = new Set([
  'data', 'result', 'results', 'record', 'report', 'death', 'previousdeath',
  'previousstate', 'state', 'history', 'item', 'details', 'huntinfo', 'hunt_info'
]);

function validHuntTimestamp(value) {
  const sec = toUnixSeconds(value);
  if (!sec) return null;
  // Hunt report history predates the game, but cannot reasonably be before 2000
  // or more than five minutes in the future (small allowance for clock skew).
  const now = Math.floor(Date.now() / 1000);
  return sec >= 946684800 && sec <= now + 5 * 60 ? sec : null;
}

function timestampInside(value, depth = 0) {
  if (depth > 7 || value == null) return null;
  if (typeof value === 'number' || typeof value === 'string') return validHuntTimestamp(value);
  if (Array.isArray(value)) {
    for (const item of value) { const found = timestampInside(item, depth + 1); if (found) return found; }
    return null;
  }
  if (typeof value !== 'object') return null;
  const entries = Object.entries(value);
  for (const [key, child] of entries) {
    if (TIME_KEYS.has(String(key).toLowerCase().replace(/[-_]/g, ''))) {
      const found = timestampInside(child, depth + 1);
      if (found) return found;
    }
  }
  for (const [key, child] of entries) {
    const normalized = String(key).toLowerCase().replace(/[-_]/g, '');
    if (CONTAINER_KEYS.has(normalized)) {
      const found = timestampInside(child, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

function findNamedValue(root, wanted, depth = 0) {
  if (!root || typeof root !== 'object' || depth > 6) return undefined;
  for (const [key, value] of Object.entries(root)) {
    if (wanted.has(String(key).toLowerCase())) return value;
  }
  for (const [key, value] of Object.entries(root)) {
    const normalized = String(key).toLowerCase();
    if (CONTAINER_KEYS.has(normalized.replace(/[-_]/g, '')) && value && typeof value === 'object') {
      const found = findNamedValue(value, wanted, depth + 1);
      if (found !== undefined) return found;
    }
  }
  return undefined;
}

/**
 * Anonymous /api/huntInfo parser. The observed response exposes previousDeath,
 * previousState and count. Only previousDeath (or an explicit timestamp nested
 * inside it) is accepted as a kill anchor; state text and report counts never are.
 */
function normalizeHuntInfo(huntName, worldName, response, definition, options = {}) {
  const root = response && typeof response === 'object' ? response : {};
  const previousDeath = findNamedValue(root, new Set(['previousdeath', 'previous_death']));
  const previousState = findNamedValue(root, new Set(['previousstate', 'previous_state']));
  const lastDeathTime = timestampInside(previousDeath);
  const rankCode = Number(definition?.Rank ?? definition?.rank);
  const maintInput = options.maint !== undefined ? options.maint
    : first(root, ['isMaint', 'IsMaint', 'MaintState', 'maint']);
  const maint = toBoolean(maintInput, null);
  const window = lastDeathTime && rankCode === 5 && maint !== null ? computeWindow(lastDeathTime, definition, maint) : null;
  // Without the exact Bear timer definition, this response is not safe to feed into CD.
  if (!lastDeathTime || rankCode !== 5 || !window) return null;
  return {
    huntName: String(huntName),
    worldName: String(worldName),
    rank: 's',
    rankCode: 5,
    region: definition?.Region || definition?.region || null,
    patch: definition?.Patch || definition?.patch || null,
    lastDeathTime,
    lastDeathAt: isoFromUnix(lastDeathTime),
    maint,
    window,
    timerWindowSource: 'bear-resource-definition',
    count: Number(first(root, ['count', 'Count'])) || null,
    previousStateKind: previousState == null ? null : Array.isArray(previousState) ? 'array' : typeof previousState,
    source: 'anonymous-huntInfo',
    updatedAt: new Date().toISOString()
  };
}

/** Normalize one row from the public /api/lastDeathTimers endpoint with a reason. */
function normalizeBulkTimerDetailed(timer, resources, allowedWorlds) {
  const row = timer && typeof timer === 'object' && !Array.isArray(timer) ? timer : {};
  if (!timer || typeof timer !== 'object' || Array.isArray(timer)) return { record: null, reason: 'invalid-row-shape' };
  const huntName = first(row, ['huntName', 'HuntName']);
  const worldName = first(row, ['worldName', 'WorldName']);
  if (typeof huntName !== 'string' || !huntName.trim()) return { record: null, reason: 'missing-hunt-name', worldName: typeof worldName === 'string' ? worldName : null };
  if (typeof worldName !== 'string' || !worldName.trim()) return { record: null, reason: 'missing-world-name', huntName };
  if (!allowedWorlds.has(worldName)) return { record: null, reason: 'world-not-selected', huntName, worldName };
  const definition = getHuntDefinition(huntName, resources);
  if (!definition) return { record: null, reason: 'hunt-definition-not-found', huntName, worldName };
  if (Number(definition.Rank ?? definition.rank) !== 5) return { record: null, reason: 'not-s-rank', huntName, worldName };
  const rawTime = first(row, ['lastDeathTime', 'LastDeathTime']);
  const lastDeathTime = validHuntTimestamp(rawTime);
  if (!lastDeathTime) return { record: null, reason: 'invalid-kill-timestamp', huntName, worldName };
  const maintKeys = ['isMaint', 'IsMaint', 'MaintState', 'maint'];
  // The public Bear client treats an omitted isMaint property as normal mode.
  // An explicitly present null/unknown value remains invalid, to avoid guessing.
  const maintFieldPresent = maintKeys.some(key => Object.prototype.hasOwnProperty.call(row, key));
  const maint = maintFieldPresent ? toBoolean(first(row, maintKeys), null) : false;
  if (maint === null) return { record: null, reason: 'invalid-maintenance-flag', huntName, worldName };
  const window = computeWindow(lastDeathTime, definition, maint);
  if (!window) return { record: null, reason: 'invalid-cd-definition', huntName, worldName };
  return { record: {
    huntName, huntKey: huntName, worldName, rank: 's', rankCode: 5,
    region: definition.Region || definition.region || null,
    patch: definition.Patch || definition.patch || null,
    lastDeathTime, lastDeathAt: isoFromUnix(lastDeathTime),
    maint, window, timerWindowSource: 'bear-resource-definition',
    source: 'bear-lastDeathTimers', updatedAt: new Date().toISOString()
  }, reason: null, huntName, worldName };
}

/** Normalize the public /api/lastDeathTimers bulk response. Only exact Rank=5
 * definitions, selected worlds and plausible Unix timestamps are accepted. */
function normalizeBulkTimer(timer, resources, allowedWorlds) {
  return normalizeBulkTimerDetailed(timer, resources, allowedWorlds).record;
}

/**
 * Detailed parser for the public live snapshot used by MagicBucket for 豆豆柴.
 * MagicBucket accepts tuples with only [line, timestamp] and treats an omitted
 * maintenance flag as false. We preserve that public contract while rejecting
 * an explicitly malformed third field and reporting every stage per world.
 */
function normalizeMainSiteLiveDetailed(payload, resources, allowedWorlds) {
  const live = payload?.live;
  if (!live || typeof live !== 'object' || Array.isArray(live)) throw new Error('豆豆柴 live 数据结构无效。');
  const output = new Map();
  const stats = new Map([...allowedWorlds].map(world => [world, {
    world, rawRecords: 0, parsedRecords: 0, distinctRecords: 0,
    rejectedRecords: 0, ignoredNonSRank: 0, conflictingRecords: 0,
    records: 0, status: 'empty', source: 'main-site-live'
  }]));
  let rawCount = 0;
  let ignoredWorlds = 0;
  let ignoredHunts = 0;
  const ignoredWorldNames = [];
  const ignoredHuntNames = [];
  const liveWorldNames = Object.keys(live);
  for (const [worldName, hunts] of Object.entries(live)) {
    if (!allowedWorlds.has(worldName)) { ignoredWorlds++; if (ignoredWorldNames.length < 12) ignoredWorldNames.push(worldName); continue; }
    const stat = stats.get(worldName);
    if (!hunts || typeof hunts !== 'object' || Array.isArray(hunts)) {
      stat.rejectedRecords++;
      continue;
    }
    for (const [huntName, rows] of Object.entries(hunts)) {
      // Raw means every tuple returned by Live for this selected world, even
      // when the hunt name is unknown or its rank cannot be mapped. Previously
      // unknown names were skipped before raw counting and made a non-empty
      // server look like a true empty result.
      if (Array.isArray(rows)) {
        rawCount += rows.length;
        stat.rawRecords += rows.length;
      }
      const definition = getHuntDefinition(huntName, resources);
      if (!definition || Number(definition.Rank ?? definition.rank) !== 5 || !Array.isArray(rows)) {
        ignoredHunts++;
        stat.ignoredNonSRank++;
        if (ignoredHuntNames.length < 20) ignoredHuntNames.push({ world: worldName, hunt: huntName, rowsType: Array.isArray(rows) ? 'array' : typeof rows, rowCount: Array.isArray(rows) ? rows.length : 0 });
        continue;
      }
      let latest = 0;
      let maint = false;
      let maintConflict = false;
      let acceptedTuple = false;
      for (const row of rows) {
        if (!Array.isArray(row) || row.length < 2) {
          stat.rejectedRecords++;
          continue;
        }
        const timestamp = validHuntTimestamp(row[1]);
        if (!timestamp) {
          stat.rejectedRecords++;
          continue;
        }
        // The reference client treats a missing third tuple member as normal mode.
        // An explicitly present but malformed marker remains rejected for CD safety.
        const isMaint = row.length < 3 ? false : toBoolean(row[2], null);
        if (isMaint === null) {
          stat.rejectedRecords++;
          continue;
        }
        acceptedTuple = true;
        if (timestamp > latest) { latest = timestamp; maint = isMaint; maintConflict = false; }
        else if (timestamp === latest && maint !== isMaint) maintConflict = true;
      }
      if (!latest) continue;
      if (maintConflict) {
        stat.conflictingRecords++;
        stat.rejectedRecords++;
        continue;
      }
      const window = computeWindow(latest, definition, maint);
      if (!window) {
        stat.rejectedRecords++;
        continue;
      }
      const timer = {
        huntName, huntKey: huntName, worldName, rank: 's', rankCode: 5,
        region: definition.Region || definition.region || null,
        patch: definition.Patch || definition.patch || null,
        lastDeathTime: latest, lastDeathAt: isoFromUnix(latest), maint,
        window, timerWindowSource: 'bear-resource-definition', source: 'main-site-live',
        updatedAt: new Date().toISOString()
      };
      const key = `${worldName}|${huntName}`;
      const previous = output.get(key);
      if (!previous || timer.lastDeathTime > previous.lastDeathTime) output.set(key, timer);
      stat.parsedRecords++;
    }
  }
  for (const stat of stats.values()) {
    stat.distinctRecords = [...output.values()].filter(row => row.worldName === stat.world).length;
    // `records` is the accepted, deduplicated row count shown to the UI.
    // Keep it identical to what the bridge will actually persist for this world.
    stat.records = stat.distinctRecords;
    stat.status = stat.rawRecords === 0 ? 'empty'
      : stat.distinctRecords === 0 ? 'error'
      : stat.rejectedRecords || stat.conflictingRecords ? 'partial' : 'parsed';
    if (stat.status === 'empty') stat.note = 'Live 接口本轮没有返回该服务器的 S 怪时间条目';
    else if (stat.status === 'error') stat.error = 'Live 返回了原始 S 怪条目，但所有条目均未通过时间 / CD 校验';
  }
  return {
    rows: [...output.values()],
    stats: [...stats.values()],
    rawCount,
    parsedCount: output.size,
    rejectedCount: [...stats.values()].reduce((sum, item) => sum + item.rejectedRecords, 0),
    ignoredWorlds, ignoredHunts, ignoredWorldNames, ignoredHuntNames,
    liveWorldNames: liveWorldNames.slice(0, 30),
    liveTopLevelKeys: Object.keys(payload || {}).slice(0, 20)
  };
}

function normalizeMainSiteLive(payload, resources, allowedWorlds) {
  return normalizeMainSiteLiveDetailed(payload, resources, allowedWorlds).rows;
}

module.exports = {
  normalizeMainSiteLive, normalizeMainSiteLiveDetailed, normalizeBulkTimer, normalizeBulkTimerDetailed, normalizeEvent, normalizeTimer, normalizeHuntInfo, isoFromUnix,
  computeWindow, computeRecordWindow, toUnixSeconds, toBoolean, getTimerWindowParts, RANK_BY_CODE, timestampInside
};
