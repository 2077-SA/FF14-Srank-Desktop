'use strict';
const SAFE_READ_ENDPOINTS = new Set(['/api/syncSession', '/api/lastDeathTimers', '/api/huntInfo']);
const RETRYABLE_HTTP_STATUS = new Set([408, 425, 500, 502, 503, 504]);

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function splitSetCookieHeader(value) {
  if (!value) return [];
  // Set-Cookie values may be combined by older fetch implementations. Split only
  // at a comma followed by a new cookie-pair, not the comma in Expires dates.
  return String(value).split(/,(?=\s*[^;,=\s]+=[^;,]*)/g);
}

class TrackerRest {
  constructor(cfg, log = () => {}) {
    this.cfg = cfg;
    this.log = log;
    // Anonymous session material is strictly in-memory. Never import or persist
    // browser cookies, Bear credentials, CSRF tokens, or session identifiers.
    this.cookies = {};
    this.csrfToken = '';
  }

  _captureCookies(res) {
    let list = [];
    if (typeof res.headers.getSetCookie === 'function') list = res.headers.getSetCookie();
    else list = splitSetCookieHeader(res.headers.get('set-cookie'));
    for (const cookie of list) {
      const pair = String(cookie).split(';', 1)[0];
      const i = pair.indexOf('=');
      if (i > 0) this.cookies[pair.slice(0, i).trim()] = pair.slice(i + 1).trim();
    }
  }

  cookieHeader() {
    return Object.entries(this.cookies).filter(([k, v]) => k && v !== undefined)
      .map(([k, v]) => `${k}=${v}`).join('; ');
  }

  async _fetchWithRetry(send, label, { maxRetries = 2 } = {}) {
    let attempt = 0;
    while (true) {
      try {
        const response = await send();
        if (RETRYABLE_HTTP_STATUS.has(Number(response.status)) && attempt < maxRetries) {
          this.log(`[rest] ${label} 返回 HTTP ${response.status}，${attempt + 1}/${maxRetries} 次安全重试`);
          try { await response.body?.cancel(); } catch {}
          await new Promise(resolve => setTimeout(resolve, 300 * (attempt + 1)));
          attempt++;
          continue;
        }
        // 429 / 403 / 419 and other client errors deliberately do not enter network retry.
        return response;
      } catch (error) {
        const retryable = error?.name === 'AbortError' || error?.name === 'TimeoutError'
          || error instanceof TypeError || /ECONNRESET|ETIMEDOUT|EAI_AGAIN|UND_ERR_CONNECT_TIMEOUT/i.test(String(error?.cause?.code || error?.code || error?.message || ''));
        if (!retryable || attempt >= maxRetries) throw error;
        this.log(`[rest] ${label} 网络暂时不可用：${error.message || error}；${attempt + 1}/${maxRetries} 次安全重试`);
        await new Promise(resolve => setTimeout(resolve, 300 * (attempt + 1)));
        attempt++;
      }
    }
  }

  async bootstrap() {
    const base = this.cfg.tracker.restBase.replace(/\/$/, '');
    const res = await this._fetchWithRetry(() => fetch(base + '/', {
      headers: { 'User-Agent': UA, Accept: 'text/html', Referer: base + '/srank', ...(this.cookieHeader() ? { Cookie: this.cookieHeader() } : {}) },
      redirect: 'follow', signal: AbortSignal.timeout(20000)
    }), 'GET / 会话初始化');
    this._captureCookies(res);
    const html = await res.text();
    if (!res.ok) {
      const error = new Error(`Bear 匿名会话初始化失败（HTTP ${res.status}）：${String(html || '').slice(0, 180)}`);
      error.status = res.status;
      throw error;
    }
    const candidates = [
      /<meta[^>]+name=["']csrfmiddlewaretoken["'][^>]+content=["']([^"']+)["']/i,
      /<meta[^>]+content=["']([^"']+)["'][^>]+name=["']csrfmiddlewaretoken["']/i,
      /name=["']csrfmiddlewaretoken["'][^>]+value=["']([^"']+)["']/i,
      /value=["']([^"']+)["'][^>]+name=["']csrfmiddlewaretoken["']/i
    ];
    for (const re of candidates) {
      const m = html.match(re);
      if (m) { this.csrfToken = m[1]; break; }
    }
    if (!this.csrfToken && this.cookies.csrftoken) this.csrfToken = this.cookies.csrftoken;
    if (!this.csrfToken) {
      const error = new Error(`Bear 匿名会话 HTTP ${res.status}，但页面未提供 CSRF token；已停止请求，不会发送无效请求。响应类型=${res.headers.get('content-type') || 'unknown'}`);
      error.status = 502;
      throw error;
    }
    return { status: res.status, csrf: true, hasSession: !!this.cookies.sessionid, cookieNames: Object.keys(this.cookies), finalUrl: res.url || base + '/' };
  }

  async post(endpoint, body = {}, { retryCsrf = true, timeoutMs = 12000 } = {}) {
    // Match the public Bear client: only the CSRF token is a prerequisite.
    // Some anonymous pages do not issue sessionid; requiring it forced redundant
    // bootstrap GETs and could block otherwise valid read-only batch requests.
    if (!this.csrfToken) await this.bootstrap();
    const url = this.cfg.tracker.restBase.replace(/\/$/, '') + endpoint;
    const send = () => fetch(url, {
      method: 'POST',
      headers: {
        'User-Agent': UA,
        'Content-Type': 'application/json;charset=utf-8',
        'X-CSRFToken': this.csrfToken,
        Accept: 'application/json, text/plain, */*',
        Cookie: this.cookieHeader(),
        Origin: this.cfg.tracker.origin,
        Referer: this.cfg.tracker.origin + '/srank'
      },
      body: JSON.stringify(body || {}),
      signal: AbortSignal.timeout(timeoutMs)
    });

    const maxRetries = SAFE_READ_ENDPOINTS.has(endpoint) ? 2 : 0;
    let res = await this._fetchWithRetry(send, endpoint, { maxRetries });
    this._captureCookies(res);
    if ((res.status === 403 || res.status === 419) && retryCsrf && SAFE_READ_ENDPOINTS.has(endpoint)) {
      this.log(`[rest] ${endpoint} 返回 ${res.status}，丢弃旧匿名会话并重新获取 CSRF 后重试一次`);
      this.clearSession();
      await this.bootstrap();
      res = await this._fetchWithRetry(send, endpoint, { maxRetries });
      this._captureCookies(res);
    }
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch {}
    return { status: res.status, json, text, headers: res.headers };
  }

  async _ok(endpoint, body, options = {}) {
    const r = await this.post(endpoint, body, options);
    if (r.status >= 400) {
      const err = new Error(`${endpoint} 返回 ${r.status}: ${String(r.text).slice(0, 240)}`);
      err.status = r.status; err.body = r.text;
      err.responseDetails = {
        status: r.status,
        url: this.cfg.tracker.restBase.replace(/\/$/, '') + endpoint,
        contentType: r.headers?.get?.('content-type') || null,
        responseDate: r.headers?.get?.('date') || null,
        responseSample: String(r.text || '').slice(0, 600)
      };
      const retryAfter = r.headers?.get?.('retry-after');
      err.retryAfterMs = retryAfter ? (Number.isFinite(Number(retryAfter)) ? Number(retryAfter) * 1000 : Math.max(0, Date.parse(retryAfter) - Date.now())) : 0;
      throw err;
    }
    return r;
  }


  async login(username, password) {
    const response = await this.post('/api/login', {
      Username: String(username || '').trim(),
      Password: String(password || ''),
      RememberMe: true
    });
    if (response.status >= 400 || !response.json) {
      const error = new Error(`Bear Tracker 登录失败（HTTP ${response.status}）：${String(response.text || '').slice(0, 180)}`);
      error.status = response.status;
      throw error;
    }
    const user = response.json.User || response.json.user || {};
    const apiToken = user.APIToken || user.ApiToken || response.json.APIToken || '';
    if (!apiToken) {
      const error = new Error('登录响应中没有 User.APIToken；无法完成 S/A 怪 Socket 权限订阅。请确认账号登录成功且接口响应结构未变化。');
      error.status = 502;
      throw error;
    }
    this.cfg.auth.apiToken = apiToken;
    return { response: response.json, user, apiToken };
  }

  clearSession() {
    this.cookies = {};
    this.csrfToken = '';
  }

  syncSession() { return this._ok('/api/syncSession', {}); }
  async lastDeathTimers(worlds, rankType = 'sRank') {
    if (!Array.isArray(worlds) || !worlds.length) throw new TypeError('批量计时查询必须提供服务器列表。');
    const requestBody = { QueryDeathTimers: worlds.map(world => String(world)), RankType: rankType };
    const sentAt = new Date().toISOString();
    const response = await this._ok('/api/lastDeathTimers', requestBody, { timeoutMs: 20000 });
    response.requestDiagnostics = {
      method: 'POST', endpoint: '/api/lastDeathTimers',
      requestWorlds: requestBody.QueryDeathTimers.slice(), rankType: requestBody.RankType,
      requestBody, sentAt, receivedAt: new Date().toISOString()
    };
    return response;
  }
  async liveDataCenter(dataCenter) {
    const base = String(this.cfg.tracker.mainSiteLiveBase || 'http://119.29.119.179/api/live?dc=');
    const url = base + encodeURIComponent(String(dataCenter || ''));
    const response = await this._fetchWithRetry(() => fetch(url, {
      headers: { 'User-Agent': UA, Accept: 'application/json', Referer: this.cfg.tracker.origin + '/srank' },
      signal: AbortSignal.timeout(20000), redirect: 'follow'
    }), `GET live ${dataCenter}`);
    const text = await response.text();
    let json = null; try { json = JSON.parse(text); } catch {}
    const responseDetails = {
      status: response.status, url, contentType: response.headers.get('content-type') || null,
      responseDate: response.headers.get('date') || null,
      payloadKeys: json && typeof json === 'object' && !Array.isArray(json) ? Object.keys(json).slice(0, 16) : [],
      responseSample: String(text || '').slice(0, 600)
    };
    if (!response.ok) {
      const error = new Error(`豆豆柴公开计时源返回 HTTP ${response.status}`);
      error.status = response.status; error.retryAfterMs = Number(response.headers.get('retry-after')) * 1000 || 0;
      error.responseDetails = responseDetails; throw error;
    }
    if (!json || typeof json !== 'object' || Array.isArray(json) || !json.live || typeof json.live !== 'object' || Array.isArray(json.live)) {
      const error = new Error('豆豆柴公开计时源响应结构无效，拒绝导入。');
      error.status = 502; error.responseDetails = responseDetails; throw error;
    }
    return { status: response.status, json, text, headers: response.headers, responseDetails };
  }
  async huntInfo(huntName, worldName) {
    const response = await this.post('/api/huntInfo', { HuntName: huntName, WorldName: worldName }, { retryCsrf: true, timeoutMs: 10000 });
    if (response.status >= 400) {
      const error = new Error(`/api/huntInfo 返回 ${response.status}: ${String(response.text || '').slice(0, 160)}`);
      error.status = response.status;
      throw error;
    }
    if (!response.json || typeof response.json !== 'object') throw new Error('/api/huntInfo 返回了无法解析的 JSON。');
    return response;
  }
  getLinkFATEInfo(huntName, worldName) { return this._ok('/api/getLinkFATEInfo', { HuntName: huntName, WorldName: worldName }); }

  reportDeath({ huntName, worldName, reportTime, missing = 0 }) {
    return this._ok('/api/deathReport', {
      HuntName: huntName, WorldName: worldName,
      ReportTime: Math.floor(reportTime || Date.now() / 1000), Missing: missing ? 1 : 0
    });
  }
  reportFound({ huntName, worldName, report = true }) {
    return this._ok('/api/foundReport', { HuntName: huntName, WorldName: worldName, Report: !!report });
  }
  querySpawnPoints({ huntName, worldName, mode = 'Query', mapPoint, version, position, state }) {
    const body = { WorldName: worldName, HuntName: huntName, QuerySpawnPoint: mode };
    if (mode === 'Set') Object.assign(body, { MapPoint: mapPoint, Version: version, Position: position, State: state ? 1 : 0 });
    return this._ok('/api/querySpawnPoints', body);
  }
  setSpawnAttempt(huntName, worldName) {
    return this._ok('/api/querySpawnAttempts', { QueryMethod: 'SetAttempt', HuntName: huntName, WorldName: worldName });
  }
  revertDeathReport({ huntName, worldName, id }) {
    return this._ok('/api/revertDeathReport', { HuntName: huntName, WorldName: worldName, ID: id });
  }
  searchHistory({ worldNames = [], huntNames = [], startTime, endTime }) {
    return this._ok('/api/searchHistory', {
      WorldNames: worldNames, HuntNames: huntNames,
      StartTime: Math.floor(startTime), EndTime: Math.floor(endTime)
    });
  }
  updateSession(patch) { return this.post('/api/updateSession', patch); }
}

module.exports = { TrackerRest, UA };
