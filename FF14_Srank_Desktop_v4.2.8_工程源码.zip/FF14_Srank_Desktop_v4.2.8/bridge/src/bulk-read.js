'use strict';

function timerWorldName(row) {
  const value = row && (row.worldName ?? row.WorldName ?? row.World);
  return typeof value === 'string' ? value.trim() : '';
}

/**
 * Read an entire selected-world batch first, then make one bounded per-world
 * request only for worlds absent from the batch response. This catches server
 * behavior where a multi-world batch returns an empty/partial `timers` array
 * while a single-world request still returns data. It never fans out per hunt.
 */
async function readBatchWithWorldFallback({ worlds, requestBatch, delayMs = 650, sleep = ms => new Promise(resolve => setTimeout(resolve, ms)), beforeFallback = async () => {}, onFallbackError = async () => {} }) {
  if (!Array.isArray(worlds) || worlds.length === 0) throw new TypeError('读取 Bear 批量计时必须指定服务器。');
  if (typeof requestBatch !== 'function') throw new TypeError('缺少 Bear 批量请求函数。');
  const primary = await requestBatch(worlds, { purpose: 'primary', world: null });
  const primaryTimers = primary?.json?.timers;
  if (!Array.isArray(primaryTimers)) {
    const error = new Error(`批量接口响应结构无效（HTTP ${primary?.status ?? '未知'}）：缺少 timers 数组。`);
    error.status = primary?.status || 502;
    error.response = primary;
    error.responseDetails = {
      status: primary?.status || null,
      contentType: primary?.headers?.get?.('content-type') || null,
      payloadKeys: primary?.json && typeof primary.json === 'object' ? Object.keys(primary.json).slice(0, 16) : [],
      responseSample: String(primary?.text || '').slice(0, 600)
    };
    throw error;
  }
  const worldSet = new Set(worlds);
  const returned = new Set(primaryTimers.map(timerWorldName).filter(world => worldSet.has(world)));
  const missingWorlds = worlds.filter(world => !returned.has(world));
  const fallback = [];
  const diagnostics = [];
  for (let index = 0; index < missingWorlds.length; index++) {
    const world = missingWorlds[index];
    if (index > 0 || primaryTimers.length > 0) await sleep(Math.max(0, Number(delayMs) || 0));
    try {
      await beforeFallback({ world, index, total: missingWorlds.length });
      const response = await requestBatch([world], { purpose: 'world-fallback', world });
      const timers = response?.json?.timers;
      if (!Array.isArray(timers)) {
        const error = new Error(`单服务器备用查询 ${world} 响应缺少 timers 数组（HTTP ${response?.status ?? '未知'}）。`);
        error.status = response?.status || 502;
        error.response = response;
        error.responseDetails = {
          status: response?.status || null,
          contentType: response?.headers?.get?.('content-type') || null,
          payloadKeys: response?.json && typeof response.json === 'object' ? Object.keys(response.json).slice(0, 16) : [],
          responseSample: String(response?.text || '').slice(0, 600)
        };
        throw error;
      }
      fallback.push(...timers);
      diagnostics.push({ world, status: 'completed', httpStatus: response.status, rawRecords: timers.length,
        contentType: response.headers?.get?.('content-type') || null,
        payloadKeys: Object.keys(response.json || {}).slice(0, 12),
        sampleKeys: timers[0] && typeof timers[0] === 'object' ? Object.keys(timers[0]).slice(0, 12) : [],
        sample: timers[0] && typeof timers[0] === 'object' ? Object.fromEntries(Object.entries(timers[0]).slice(0, 10)) : null,
        responseSample: String(response.text || '').slice(0, 400), requestDiagnostics: response.requestDiagnostics || null });
    } catch (error) {
      await onFallbackError(error, { world, index, total: missingWorlds.length });
      diagnostics.push({ world, status: 'error', httpStatus: Number(error.status || error.responseDetails?.status) || null,
        contentType: error.responseDetails?.contentType || null, payloadKeys: error.responseDetails?.payloadKeys || [],
        responseSample: error.responseDetails?.responseSample || String(error.body || '').slice(0, 600), rawRecords: 0, error: error.message });
      if (Number(error.status) === 429) {
        for (const skippedWorld of missingWorlds.slice(index + 1)) {
          diagnostics.push({ world: skippedWorld, status: 'skipped-cooldown', httpStatus: 429, rawRecords: 0, error: 'Bear 触发 429，全局冷却期间跳过备用查询' });
        }
        break;
      }
    }
  }
  return {
    primary,
    primaryTimers,
    timers: [...primaryTimers, ...fallback],
    fallbackDiagnostics: diagnostics,
    fallbackErrors: diagnostics.filter(row => row.status === 'error'),
    fallbackIssues: diagnostics.filter(row => row.status !== 'completed'),
    requestedWorlds: worlds.length,
    primaryReturnedWorlds: returned.size,
    fallbackWorlds: missingWorlds.length
  };
}

module.exports = { readBatchWithWorldFallback, timerWorldName };
