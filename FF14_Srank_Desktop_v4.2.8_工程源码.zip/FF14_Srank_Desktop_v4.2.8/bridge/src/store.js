'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { SUPPORTED_DATA_CENTERS, dataCenterForWorld } = require('./data-centers');

function atomicWrite(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), { mode: 0o600 });
  fs.renameSync(temp, file);
  try { fs.chmodSync(file, 0o600); } catch {}
}

function emptyState() { return { updatedAt: null, dataCenter: null, schemaVersion: 2, hunts: {} }; }
function dcFileName(dataCenter) { return `dc-${Buffer.from(dataCenter, 'utf8').toString('hex')}.json`; }

class Store {
  constructor(cfg) {
    this.dir = cfg.dataDir;
    fs.mkdirSync(this.dir, { recursive: true });
    this.resourcesCache = null;
    this.partitionCache = new Map();
    this.migrationDone = false;
    this.dcDir = path.join(this.dir, 'data-centers');
    fs.mkdirSync(this.dcDir, { recursive: true });
    this.files = {
      resources: path.join(this.dir, 'resources.json'),
      // Kept as read-only migration source; new writes never go into this shared file.
      state: path.join(this.dir, 'state.json'),
      migration: path.join(this.dir, 'state-partitions-v2.json'),
      unassigned: path.join(this.dir, 'state-unassigned-v2.json'),
      outbox: path.join(this.dir, 'outbox.json'),
      events: path.join(this.dir, 'events.jsonl'),
      seen: path.join(this.dir, 'seen-events.json')
    };
  }
  _readJson(file, fallback) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
  }
  loadResources() { return this._readJson(this.files.resources, null); }
  saveResources(resources) {
    const clean = {
      fetchedAt: resources?.fetchedAt || new Date().toISOString(),
      DatabaseHunt: resources?.DatabaseHunt || {},
      DatabaseFate: resources?.DatabaseFate || {},
      DataCenters: resources?.DataCenters || {},
      Instances: resources?.Instances || {},
      Regions: resources?.Regions || {},
      SpawnPoint: resources?.SpawnPoint || {}
    };
    this.resourcesCache = clean;
    atomicWrite(this.files.resources, clean);
    this.ensurePartitionMigration(clean);
  }
  setResources(resources) {
    this.resourcesCache = resources || null;
    if (this.resourcesCache) this.ensurePartitionMigration(this.resourcesCache);
  }
  _partitionFile(dataCenter) {
    if (!SUPPORTED_DATA_CENTERS.includes(dataCenter)) throw Object.assign(new Error(`未知数据中心命名空间：${dataCenter || '空'}`), { status: 400 });
    return path.join(this.dcDir, dcFileName(dataCenter));
  }
  ensurePartitionMigration(resources = this.resourcesCache || this.loadResources()) {
    if (this.migrationDone || fs.existsSync(this.files.migration)) { this.migrationDone = true; return { migrated: 0, unassigned: 0, alreadyDone: true }; }
    if (!fs.existsSync(this.files.state)) {
      atomicWrite(this.files.migration, { schemaVersion: 2, migratedAt: new Date().toISOString(), migrated: 0, unassigned: 0 });
      this.migrationDone = true;
      return { migrated: 0, unassigned: 0, alreadyDone: false };
    }
    const legacy = this._readJson(this.files.state, emptyState());
    const groups = new Map(SUPPORTED_DATA_CENTERS.map(dc => [dc, this._readJson(this._partitionFile(dc), emptyState())]));
    const unassigned = { schemaVersion: 2, preservedAt: new Date().toISOString(), reason: '无法唯一映射到四大区的旧版记录，隔离保留，不参与 CD 计算。', hunts: {} };
    let migrated = 0;
    let quarantined = 0;
    for (const [legacyKey, row] of Object.entries(legacy?.hunts || {})) {
      const dc = dataCenterForWorld(row?.worldName, resources);
      if (!dc) { unassigned.hunts[legacyKey] = row; quarantined++; continue; }
      const state = groups.get(dc);
      const key = `${String(row.worldName)}|${String(row.huntName || legacyKey.split('|').slice(1).join('|'))}`;
      const previous = state.hunts[key];
      const oldTs = Number(previous?.lastDeathTime) || 0;
      const incomingTs = Number(row?.lastDeathTime) || 0;
      if (!previous || incomingTs > oldTs) state.hunts[key] = { ...row, dataCenter: dc, migratedFromLegacy: true };
      else state.hunts[key] = { ...previous, dataCenter: dc };
      state.dataCenter = dc;
      state.schemaVersion = 2;
      state.updatedAt = legacy.updatedAt || new Date().toISOString();
      migrated++;
    }
    for (const dc of SUPPORTED_DATA_CENTERS) {
      const state = groups.get(dc);
      state.dataCenter = dc;
      state.schemaVersion = 2;
      if (Object.keys(state.hunts || {}).length) atomicWrite(this._partitionFile(dc), state);
      this.partitionCache.set(dc, state);
    }
    if (quarantined) atomicWrite(this.files.unassigned, unassigned);
    atomicWrite(this.files.migration, { schemaVersion: 2, migratedAt: new Date().toISOString(), migrated, unassigned: quarantined });
    this.migrationDone = true;
    return { migrated, unassigned: quarantined, alreadyDone: false };
  }
  _metaFile(dataCenter) {
    const stateFile = this._partitionFile(dataCenter);
    return stateFile.replace(/\.json$/i, '.meta.json');
  }
  loadDataCenterMeta(dataCenter) {
    this._partitionFile(dataCenter);
    const meta = this._readJson(this._metaFile(dataCenter), { dataCenter, status: 'idle', lastSyncAt: null, lastSuccessAt: null, lastError: null, nextPollAt: null });
    return { ...meta, dataCenter };
  }
  saveDataCenterMeta(dataCenter, meta) {
    this._partitionFile(dataCenter);
    const value = { ...meta, dataCenter, updatedAt: new Date().toISOString() };
    atomicWrite(this._metaFile(dataCenter), value);
    return value;
  }
  loadDataCenterState(dataCenter) {
    const file = this._partitionFile(dataCenter);
    if (this.partitionCache.has(dataCenter)) return this.partitionCache.get(dataCenter);
    const state = this._readJson(file, emptyState());
    if (!state || typeof state !== 'object' || !state.hunts || typeof state.hunts !== 'object') return emptyState();
    state.dataCenter = dataCenter;
    state.schemaVersion = 2;
    this.partitionCache.set(dataCenter, state);
    return state;
  }
  saveDataCenterState(dataCenter, state) {
    const file = this._partitionFile(dataCenter);
    state.dataCenter = dataCenter;
    state.schemaVersion = 2;
    state.updatedAt = new Date().toISOString();
    this.partitionCache.set(dataCenter, state);
    atomicWrite(file, state);
    return state;
  }
  /** Aggregate is read-only and namespaced; callers should request one DC when calculating. */
  loadState(dataCenter = null) {
    if (dataCenter) return this.loadDataCenterState(dataCenter);
    const aggregate = { updatedAt: null, schemaVersion: 2, isolated: true, dataCenters: {}, hunts: {} };
    for (const dc of SUPPORTED_DATA_CENTERS) {
      const state = this.loadDataCenterState(dc);
      aggregate.dataCenters[dc] = { updatedAt: state.updatedAt || null, huntCount: Object.keys(state.hunts || {}).length };
      if (state.updatedAt && (!aggregate.updatedAt || state.updatedAt > aggregate.updatedAt)) aggregate.updatedAt = state.updatedAt;
      for (const [key, row] of Object.entries(state.hunts || {})) {
        aggregate.hunts[`${dc}|${key}`] = { ...row, dataCenter: dc };
      }
    }
    return aggregate;
  }
  saveState(state, dataCenter) {
    if (!dataCenter) throw new Error('禁止写入未指定大区的共享 S 怪状态；请使用 saveDataCenterState。');
    return this.saveDataCenterState(dataCenter, state);
  }
  applyTimers(timers, keyOf, dataCenter = null) {
    const grouped = new Map();
    let rejected = 0;
    let inserted = 0;
    let updated = 0;
    let unchanged = 0;
    let stale = 0;
    const sameSubstantiveValue = (left, right) => {
      if (left === right) return true;
      if (Array.isArray(left) || Array.isArray(right)) return JSON.stringify(left ?? null) === JSON.stringify(right ?? null);
      if (left && typeof left === 'object' || right && typeof right === 'object') {
        const a = left && typeof left === 'object' ? left : {};
        const b = right && typeof right === 'object' ? right : {};
        const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
        for (const key of keys) if (!sameSubstantiveValue(a[key], b[key])) return false;
        return true;
      }
      return Number.isFinite(Number(left)) && Number.isFinite(Number(right)) && left !== '' && right !== ''
        ? Number(left) === Number(right) : left === right;
    };
    const timingFields = [
      'lastDeathTime', 'maint', 'window', 'timerWindowSource', 'timerResourcesFetchedAt',
      'trustLevel', 'verifiedRoutes', 'source', 'rank', 'rankCode', 'dataCenter',
      'region', 'patch', 'lastMarkTime', 'missingCounter'
    ];
    const sameTiming = (left, right) => timingFields.every(field => sameSubstantiveValue(left?.[field], right?.[field]));

    for (const timer of timers || []) {
      if (!timer?.worldName || !timer?.huntName) { rejected++; continue; }
      const inferred = dataCenterForWorld(timer.worldName, this.resourcesCache || this.loadResources());
      const targetDc = dataCenter || inferred;
      // Enforce an exact 1:1 world-to-DC assignment. Unknown and mismatched rows are rejected.
      if (!targetDc || !inferred || targetDc !== inferred || (timer.dataCenter && timer.dataCenter !== targetDc)) { rejected++; continue; }
      if (!grouped.has(targetDc)) grouped.set(targetDc, []);
      grouped.get(targetDc).push({ ...timer, dataCenter: targetDc });
    }
    for (const [dc, rows] of grouped) {
      const state = this.loadDataCenterState(dc);
      let changed = false;
      for (const timer of rows) {
        const key = keyOf(timer.worldName, timer.huntName);
        const current = state.hunts[key];
        const newTs = Number(timer.lastDeathTime) || 0;
        const oldTs = Number(current?.lastDeathTime) || 0;
        if (!current || !oldTs) {
          state.hunts[key] = { ...(current || {}), ...timer, dataCenter: dc };
          inserted++;
          changed = true;
          continue;
        }
        if (newTs < oldTs) {
          stale++;
          continue;
        }
        if (newTs === oldTs && sameTiming(current, timer)) {
          unchanged++;
          continue;
        }
        state.hunts[key] = { ...current, ...timer, dataCenter: dc };
        updated++;
        changed = true;
      }
      // A byte-for-byte equivalent Bear snapshot must not rewrite the cache just
      // to change updatedAt. The renderer still receives the final sync result
      // and can refresh its monitor bindings explicitly after a manual run.
      if (changed) this.saveDataCenterState(dc, state);
    }
    return {
      state: this.loadState(), rejected, inserted, updated,
      unchanged, stale, applied: inserted + updated
    };
  }
  upsertHunt(key, patch) {
    const dc = patch?.dataCenter;
    if (!dc || dataCenterForWorld(patch?.worldName, this.resourcesCache || this.loadResources()) !== dc) {
      throw new Error('拒绝更新：记录缺少有效的大区归属。');
    }
    const state = this.loadDataCenterState(dc);
    state.hunts[key] = { ...(state.hunts[key] || {}), ...patch, dataCenter: dc };
    this.saveDataCenterState(dc, state);
    return state.hunts[key];
  }
  appendQuarantine(dataCenter, entry) {
    const file = path.join(this.dcDir, `${dcFileName(dataCenter).replace(/\.json$/i, '')}.quarantine.jsonl`);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.appendFileSync(file, JSON.stringify({ dataCenter, ...entry }) + '\n', { mode: 0o600 });
    try { fs.chmodSync(file, 0o600); } catch {}
    return file;
  }
  appendEvent(event) {
    fs.appendFileSync(this.files.events, JSON.stringify(event) + '\n', { mode: 0o600 });
  }
  tailEvents(limit = 100) {
    try {
      const lines = fs.readFileSync(this.files.events, 'utf8').split(/\r?\n/).filter(Boolean);
      return lines.slice(-Math.max(1, Math.min(1000, limit))).map(line => { try { return JSON.parse(line); } catch { return null; } }).filter(Boolean);
    } catch { return []; }
  }
  hasSeen(id) { const seen = this._readJson(this.files.seen, {}); return !!seen[id]; }
  markSeen(id) {
    const seen = this._readJson(this.files.seen, {});
    seen[id] = Date.now();
    const entries = Object.entries(seen).sort((a, b) => b[1] - a[1]).slice(0, 3000);
    atomicWrite(this.files.seen, Object.fromEntries(entries));
  }
  loadOutbox() { return this._readJson(this.files.outbox, []); }
  saveOutbox(list) { atomicWrite(this.files.outbox, list); }
  enqueue(item, dedupeKey) {
    const list = this.loadOutbox(); const key = dedupeKey || item.dedupeKey;
    if (key && list.some(entry => entry.dedupeKey === key)) return list;
    list.push({ ...item, id: item.id || `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`, dedupeKey: key || null, attempts: 0, createdAt: new Date().toISOString() });
    this.saveOutbox(list); return list;
  }
  removeFromOutbox(id) { this.saveOutbox(this.loadOutbox().filter(item => item.id !== id)); }
  markAttempt(id, err) {
    const list = this.loadOutbox(); const item = list.find(x => x.id === id);
    if (item) { item.attempts = (item.attempts || 0) + 1; item.lastError = String(err || '').slice(0, 300); item.lastAttemptAt = new Date().toISOString(); this.saveOutbox(list); }
  }
}

module.exports = { Store, atomicWrite, dcFileName };
