'use strict';

const { validateDataCenters, normalizeWorldSelections, worldsForDataCenter } = require('./data-centers');

/**
 * Build one canonical sync plan. Progress is always measured in selected worlds,
 * never in (worlds × monster definitions), because Bear's primary API is batch-per-DC.
 */
function buildSyncPlan(dataCenters, worldSelections, resources = null, previousSelections = null) {
  const selectedDataCenters = validateDataCenters(dataCenters);
  const normalizedWorldSelections = normalizeWorldSelections(
    selectedDataCenters, worldSelections, resources, previousSelections
  );
  const groups = selectedDataCenters.map(dataCenter => ({
    dataCenter,
    worlds: [...(normalizedWorldSelections[dataCenter] || worldsForDataCenter(dataCenter, resources))]
  }));
  const emptyGroups = groups.filter(group => !group.worlds.length);
  if (emptyGroups.length) {
    throw new Error(`以下大区没有解析到服务器列表：${emptyGroups.map(group => group.dataCenter).join('、')}`);
  }
  const targetServers = groups.reduce((count, group) => count + group.worlds.length, 0);
  return {
    dataCenters: selectedDataCenters,
    worldSelections: normalizedWorldSelections,
    groups,
    targetServers,
    targetRequests: groups.length
  };
}

module.exports = { buildSyncPlan };
