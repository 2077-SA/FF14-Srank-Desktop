'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { readBatchWithWorldFallback } = require('../src/bulk-read');

test('empty multi-world Bear batch is checked with one bounded request per missing world', async () => {
  const calls = [];
  const sleeps = [];
  const result = await readBatchWithWorldFallback({
    worlds: ['红玉海', '神意之地'], delayMs: 700,
    sleep: async ms => sleeps.push(ms),
    requestBatch: async worlds => {
      calls.push(worlds);
      if (worlds.length > 1) return { status: 200, json: { timers: [] } };
      return { status: 200, json: { timers: [{ huntName: `S-${worlds[0]}`, worldName: worlds[0], lastDeathTime: 1790000000 }] } };
    }
  });
  assert.deepEqual(calls, [['红玉海', '神意之地'], ['红玉海'], ['神意之地']]);
  assert.equal(result.primaryTimers.length, 0);
  assert.equal(result.timers.length, 2);
  assert.equal(result.fallbackWorlds, 2);
  assert.equal(result.fallbackErrors.length, 0);
  assert.deepEqual(sleeps, [700]);
});

test('partial multi-world batch only probes worlds absent from the primary result', async () => {
  const calls = [];
  const result = await readBatchWithWorldFallback({
    worlds: ['红玉海', '神意之地', '拉诺西亚'],
    sleep: async () => {},
    requestBatch: async worlds => {
      calls.push(worlds);
      if (worlds.length > 1) return { status: 200, json: { timers: [{ huntName: 'S-One', worldName: '红玉海', lastDeathTime: 1790000000 }] } };
      return { status: 200, json: { timers: [{ huntName: `S-${worlds[0]}`, worldName: worlds[0], lastDeathTime: 1790000001 }] } };
    }
  });
  assert.deepEqual(calls, [['红玉海', '神意之地', '拉诺西亚'], ['神意之地'], ['拉诺西亚']]);
  assert.equal(result.timers.length, 3);
  assert.equal(result.primaryReturnedWorlds, 1);
});

test('per-world endpoint errors stay visible and are not mistaken for empty results', async () => {
  const result = await readBatchWithWorldFallback({
    worlds: ['水晶塔'], sleep: async () => {},
    requestBatch: async (worlds, requestInfo) => {
      if (requestInfo.purpose === 'primary') return { status: 200, json: { timers: [] } };
      const error = new Error('HTTP 503'); error.status = 503; throw error;
    }
  });
  assert.equal(result.timers.length, 0);
  assert.equal(result.fallbackErrors.length, 1);
  assert.equal(result.fallbackDiagnostics[0].status, 'error');
  assert.match(result.fallbackDiagnostics[0].error, /503/);
});

test('invalid primary response shape aborts before issuing fallback requests', async () => {
  let calls = 0;
  await assert.rejects(() => readBatchWithWorldFallback({
    worlds: ['红玉海'], requestBatch: async () => { calls++; return { status: 200, json: { result: [] } }; }
  }), /缺少 timers 数组/);
  assert.equal(calls, 1);
});

test('single-world selection still executes a second, explicitly classified per-world request', async () => {
  const calls = [];
  const result = await readBatchWithWorldFallback({
    worlds: ['水晶塔'], sleep: async () => {},
    requestBatch: async (worlds, info) => {
      calls.push(info.purpose);
      return info.purpose === 'primary'
        ? { status: 200, json: { timers: [] } }
        : { status: 200, json: { timers: [{ huntName: 'S-One', worldName: '水晶塔', lastDeathTime: 1790000000 }] } };
    }
  });
  assert.deepEqual(calls, ['primary', 'world-fallback']);
  assert.equal(result.timers.length, 1);
});

test('HTTP 429 stops remaining fallback requests and reports skipped worlds', async () => {
  const calls = [];
  let cooldownHookCalls = 0;
  const result = await readBatchWithWorldFallback({
    worlds: ['红玉海', '神意之地', '拉诺西亚'], sleep: async () => {},
    requestBatch: async (worlds, info) => {
      calls.push(info.purpose + ':' + (info.world || '*'));
      if (info.purpose === 'primary') return { status: 200, json: { timers: [] } };
      const error = new Error('HTTP 429'); error.status = 429; error.retryAfterMs = 120000; throw error;
    },
    onFallbackError: async error => { if (error.status === 429) cooldownHookCalls++; }
  });
  assert.deepEqual(calls, ['primary:*', 'world-fallback:红玉海']);
  assert.equal(cooldownHookCalls, 1);
  assert.equal(result.fallbackErrors.length, 1);
  assert.equal(result.fallbackIssues.length, 3);
  assert.equal(result.fallbackDiagnostics[1].status, 'skipped-cooldown');
});
