'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { SUPPORTED_WORLD_GROUPS, normalizeWorldSelections } = require('../src/data-centers');

test('newly selected data center defaults to all child worlds when no prior choice exists', () => {
  const result = normalizeWorldSelections(['陆行鸟', '莫古力'], { '陆行鸟': ['红玉海'] }, null, {});
  assert.deepEqual(result['陆行鸟'], ['红玉海']);
  assert.deepEqual(result['莫古力'], SUPPORTED_WORLD_GROUPS['莫古力']);
});

test('retaining a previously selected data center preserves its checked child worlds', () => {
  const result = normalizeWorldSelections(['陆行鸟', '莫古力'], { '陆行鸟': ['红玉海'] }, null, { '莫古力': ['白银乡'] });
  assert.deepEqual(result['莫古力'], ['白银乡']);
});

test('unselected data centers and their world selections are removed from config', () => {
  const result = normalizeWorldSelections(['豆豆柴'], { '豆豆柴': ['水晶塔'], '陆行鸟': ['红玉海'] }, null, {});
  assert.deepEqual(Object.keys(result), ['豆豆柴']);
  assert.deepEqual(result['豆豆柴'], ['水晶塔']);
});

test('world selections reject empty or cross-data-center-only choices', () => {
  assert.throws(() => normalizeWorldSelections(['莫古力'], { '莫古力': [] }), /至少保留一个服务器/);
  assert.throws(() => normalizeWorldSelections(['豆豆柴'], { '豆豆柴': ['白银乡'] }), /至少保留一个服务器/);
});
