'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { TrackerRest } = require('../src/tracker-rest');

function makeRest() {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff14-rest-test-'));
  const rest = new TrackerRest({
    tracker: { restBase: 'https://tracker.example.test', origin: 'https://tracker.example.test' },
    auth: { csrfToken: 'must-not-be-imported', cookie: 'sessionid=must-not-be-imported' },
    dataDir
  }, () => {});
  // Tests that need an already established anonymous session set in-memory state
  // explicitly. Production constructor must never import credentials/cookies.
  rest.csrfToken = 'test-csrf';
  rest.cookies = { sessionid: 'test-session' };
  return { rest, dataDir, cleanup: () => fs.rmSync(dataDir, { recursive: true, force: true }) };
}

const jsonResponse = (status, value = {}) => new Response(JSON.stringify(value), {
  status, headers: { 'content-type': 'application/json' }
});


test('anonymous Bear bootstrap matches the public timer client root session and /srank referer', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  const calls = [];
  rest.csrfToken = '';
  rest.cookies = {};
  global.fetch = async (url, options = {}) => {
    calls.push({ url: String(url), options });
    if (String(url) === 'https://tracker.example.test/') {
      return new Response('<html><input type="hidden" name="csrfmiddlewaretoken" value="csrf-from-root"></html>', {
        status: 200, headers: { 'content-type': 'text/html' }
      });
    }
    return jsonResponse(200, { timers: [{ huntName: 'S Test', worldName: '红玉海', lastDeathTime: 1700000000 }] });
  };
  try {
    const response = await rest.lastDeathTimers(['红玉海'], 'sRank');
    assert.equal(response.status, 200);
    assert.equal(calls.length, 2);
    assert.equal(calls[0].url, 'https://tracker.example.test/');
    assert.equal(calls[0].options.headers.Referer, 'https://tracker.example.test/srank');
    assert.equal(calls[1].url, 'https://tracker.example.test/api/lastDeathTimers');
    assert.equal(calls[1].options.headers.Referer, 'https://tracker.example.test/srank');
    assert.equal(calls[1].options.headers['X-CSRFToken'], 'csrf-from-root');
    assert.deepEqual(JSON.parse(calls[1].options.body), { QueryDeathTimers: ['红玉海'], RankType: 'sRank' });
  } finally { global.fetch = original; cleanup(); }
});

test('safe Bear read retries a transient network failure and then succeeds', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; if (calls === 1) throw new TypeError('temporary network error'); return jsonResponse(200, { ok: true }); };
  try {
    const result = await rest.post('/api/lastDeathTimers', {});
    assert.equal(result.status, 200);
    assert.equal(calls, 2);
  } finally { global.fetch = original; cleanup(); }
});

test('safe Bear read retries 503 but does not retry 429', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; return calls === 1 ? jsonResponse(503, {}) : jsonResponse(200, { ok: true }); };
  try {
    const recovered = await rest.post('/api/huntInfo', {});
    assert.equal(recovered.status, 200);
    assert.equal(calls, 2);
    calls = 0;
    global.fetch = async () => { calls++; return jsonResponse(429, { retryAfter: 60 }); };
    const limited = await rest.post('/api/lastDeathTimers', {});
    assert.equal(limited.status, 429);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});

test('write-like Bear endpoints are never retried after network failure', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; throw new TypeError('temporary network error'); };
  try {
    await assert.rejects(rest.post('/api/deathReport', {}), /temporary network error/);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});


test('write-like Bear endpoints do not resend after 403/419 CSRF responses', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; return jsonResponse(403, { error: 'forbidden' }); };
  try {
    const result = await rest.post('/api/deathReport', {});
    assert.equal(result.status, 403);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});


test('anonymous REST constructor ignores configured Bear credentials and does not persist session cookies', async () => {
  const { rest, dataDir, cleanup } = makeRest();
  const original = global.fetch;
  rest.csrfToken = '';
  rest.cookies = {};
  global.fetch = async (url, options = {}) => {
    if (String(url) === 'https://tracker.example.test/') {
      return new Response('<input type="hidden" name="csrfmiddlewaretoken" value="ephemeral-csrf">', {
        status: 200,
        headers: { 'content-type': 'text/html', 'set-cookie': 'csrftoken=ephemeral-cookie; Path=/; SameSite=Lax' }
      });
    }
    return jsonResponse(200, { timers: [] });
  };
  try {
    const fresh = new TrackerRest({
      tracker: { restBase: 'https://tracker.example.test', origin: 'https://tracker.example.test' },
      auth: { csrfToken: 'configured-token', cookie: 'sessionid=configured-session' }, dataDir
    }, () => {});
    assert.equal(fresh.csrfToken, '');
    assert.deepEqual(fresh.cookies, {});
    await fresh.bootstrap();
    assert.equal(fresh.csrfToken, 'ephemeral-csrf');
    assert.equal(fs.existsSync(require('node:path').join(dataDir, 'cookies.json')), false);
    assert.equal(fs.existsSync(require('node:path').join(dataDir, 'auth-session.json')), false);
  } finally { global.fetch = original; cleanup(); }
});

test('anonymous bootstrap fails closed if the site provides no CSRF token', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  rest.csrfToken = '';
  rest.cookies = {};
  global.fetch = async () => new Response('<html>JavaScript required</html>', { status: 200, headers: { 'content-type': 'text/html' } });
  try {
    await assert.rejects(rest.bootstrap(), /未提供 CSRF token/);
  } finally { global.fetch = original; cleanup(); }
});

test('豆豆柴 Live endpoint preserves HTTP status and response-shape diagnostics', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  global.fetch = async () => new Response('<html>upstream proxy error</html>', {
    status: 503, headers: { 'content-type': 'text/html', 'retry-after': '30' }
  });
  try {
    await assert.rejects(rest.liveDataCenter('豆豆柴'), error => {
      assert.equal(error.status, 503);
      assert.equal(error.retryAfterMs, 30000);
      assert.equal(error.responseDetails.contentType, 'text/html');
      assert.match(error.responseDetails.responseSample, /upstream proxy error/);
      return true;
    });
  } finally { global.fetch = original; cleanup(); }
});

test('豆豆柴 Live endpoint rejects a JSON response with the wrong structure and keeps diagnostics', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  global.fetch = async () => new Response(JSON.stringify({ status: 'ok', data: [] }), {
    status: 200, headers: { 'content-type': 'application/json' }
  });
  try {
    await assert.rejects(rest.liveDataCenter('豆豆柴'), error => {
      assert.equal(error.status, 502);
      assert.deepEqual(error.responseDetails.payloadKeys, ['status', 'data']);
      assert.match(error.message, /结构无效/);
      return true;
    });
  } finally { global.fetch = original; cleanup(); }
});
