'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { summarizeBulkWorlds, assertBulkNormalization } = require('../src/sync-report');

test('raw Bear rows rejected by every validator cannot be reported as a completed empty sync', () => {
  const raw = [{ worldName: '白银乡', huntName: 'S Test Hunt', lastDeathTime: 1700000000 }];
  assert.throws(() => assertBulkNormalization(raw, [], '莫古力'), /原始记录，但有效 S 怪记录为 0/);
});

test('a genuinely empty Bear response is identified as no-data, not success', () => {
  assert.deepEqual(assertBulkNormalization([], [], '莫古力'), {
    rawCount: 0, parsedCount: 0, rejectedCount: 0, status: 'empty'
  });
  const stats = summarizeBulkWorlds(['白银乡'], [], [], [], []);
  assert.equal(stats[0].status, 'empty');
  assert.match(stats[0].note, /不代表已获取到 CD/);
});

test('world report separates raw, parsed, duplicates, accepted and quarantined records', () => {
  const raw = [
    { worldName: '白银乡' }, { worldName: '白银乡' }, { worldName: '白银乡' },
    { worldName: '白金幻象' }
  ];
  const parsed = [
    { worldName: '白银乡', huntName: 'S1' },
    { worldName: '白银乡', huntName: 'S1' },
    { worldName: '白银乡', huntName: 'S2' }
  ];
  const distinct = [parsed[0], parsed[2]];
  const accepted = [parsed[2]];
  const stats = summarizeBulkWorlds(['白银乡', '白金幻象'], raw, parsed, distinct, accepted);
  assert.deepEqual(stats[0], {
    world: '白银乡', rawRecords: 3, parsedRecords: 3, distinctRecords: 2,
    records: 1, rejectedRecords: 0, duplicateRecords: 1, isolatedRecords: 1,
    status: 'partial'
  });
  assert.equal(stats[1].status, 'error');
  assert.equal(stats[1].rawRecords, 1);
});
