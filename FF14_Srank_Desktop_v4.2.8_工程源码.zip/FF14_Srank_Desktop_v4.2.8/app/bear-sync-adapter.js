/* FF14 Srank <-> Bear Tracker anonymous S-rank adapter.
 * This build is read-only against Bear Tracker and does not require an account.
 * It imports Rank=5 S-rank kill anchors only; no A/B/FATE data and no upstream writes.
 */
(function FF14BearAnonymousSRankAdapter(){
  'use strict';
  if (window.__FF14BearAnonymousAdapterInstalled) return;
  window.__FF14BearAnonymousAdapterInstalled = true;

  const CONFIG = Object.assign({
    baseUrl: 'http://127.0.0.1:8790',
    expectedBridgeVersion: '',
    requestTimeoutMs: 2200,
    maxHistoryScan: 5000,
    pullChunkSize: 8,
    syncPollMs: 2500,
    localRefreshMs: 30000
  }, window.FF14BearBridgeConfig || {});
  const STORAGE = 'ff14_bear_anonymous_srank_state_v3';
  const MAX_BEAR_TIMER_RESOURCE_AGE_MS = 6 * 60 * 60 * 1000;
  const KNOWN_DATA_CENTERS = Object.freeze(['豆豆柴', '陆行鸟', '莫古力', '猫小胖']);
  const WORLD_TO_DC = Object.freeze({
    '水晶塔':'豆豆柴','银泪湖':'豆豆柴','太阳海岸':'豆豆柴','伊修加德':'豆豆柴','红茶川':'豆豆柴',
    '红玉海':'陆行鸟','神意之地':'陆行鸟','拉诺西亚':'陆行鸟','幻影群岛':'陆行鸟','萌芽池':'陆行鸟','宇宙和音':'陆行鸟','沃仙曦染':'陆行鸟','晨曦王座':'陆行鸟',
    '白银乡':'莫古力','白金幻象':'莫古力','神拳痕':'莫古力','潮风亭':'莫古力','旅人栈桥':'莫古力','拂晓之间':'莫古力','龙巢神殿':'莫古力','梦羽宝境':'莫古力',
    '紫水栈桥':'猫小胖','延夏':'猫小胖','静语庄园':'猫小胖','摩杜纳':'猫小胖','海猫茶屋':'猫小胖','柔风海湾':'猫小胖','琥珀原':'猫小胖'
  });
  const dataCenterForWorld = world => WORLD_TO_DC[String(world || '').trim()] || null;
  const state = {
    serviceReady: false,
    desktopVersion: String(window.ff14Desktop?.version || '网页版'),
    bridgeVersion: 'unknown', bridgePort: 8790,
    dataCenters: ['陆行鸟'],
    worldSelections: {},
    syncStatus: 'offline',
    syncRunning: false,
    totalTargets: 0,
    completed: 0,
    timerCount: 0,
    sRankCount: 0,
    aliasCount: 0,
    pulled: 0,
    skipped: 0,
    lastSyncAt: null,
    lastAppliedSyncAt: null,
    lastCacheUpdatedAt: null, lastAppliedCacheUpdatedAt: null,
    lastError: null,
    progressPercent: 0, phaseLabel: '等待本机同步服务', worldResults: [], byDataCenter: {}, unchangedRecords: 0, staleRecords: 0, activeDataCenters: [], corroboratedRecords: 0, singleSourceRecords: 0, quarantinedRecords: 0, validatedRecords: 0, rejectedRecords: 0, emptyDataCenters: 0, partialDataCenters: 0, paused: false, pauseRequested: false, lastSuccessAt: null
  };

  let panel = null;
  let pill = null;
  let panelDetail = null;
  let dcOptions = null;
  let worldOptions = null;
  let worldList = null;
  let calculatorCard = null;
  let mapList = null;
  let mapSearch = null;
  let localMonsterList = [];
  let latestRecordsIndex = new Map();
  let cachedRemoteHunts = [];
  let cachedAliases = {};
  let mappingLoaded = false;
  let syncWaitToken = 0;
  let statusTimer = null;
  let healthBusy = false;
  let pullBusy = false;

  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const url = path => CONFIG.baseUrl.replace(/\/$/, '') + path;
  const log = (...args) => console.info('[FF14 同步数据]', ...args);
  const warn = (...args) => console.warn('[FF14 同步数据]', ...args);
  const toSeconds = value => {
    if (value == null || value === '') return null;
    if (typeof value === 'string' && !/^\d+(?:\.\d+)?$/.test(value)) {
      const parsed = Date.parse(value);
      return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : null;
    }
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return null;
    return Math.floor(n > 1e12 ? n / 1000 : n);
  };
  const localDate = sec => {
    const date = new Date(sec * 1000);
    const pad = n => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  function persistState(){
    try {
      localStorage.setItem(STORAGE, JSON.stringify({
        pulled: state.pulled, skipped: state.skipped,
        lastSyncAt: state.lastSyncAt, lastAppliedSyncAt: state.lastAppliedSyncAt, lastCacheUpdatedAt: state.lastCacheUpdatedAt, lastAppliedCacheUpdatedAt: state.lastAppliedCacheUpdatedAt
      }));
    } catch {}
  }
  function restoreState(){
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE) || '{}');
      state.pulled = Number(value.pulled) || 0;
      state.skipped = Number(value.skipped) || 0;
      state.lastSyncAt = value.lastSyncAt || null;
      state.lastAppliedSyncAt = value.lastAppliedSyncAt || null;
      state.lastCacheUpdatedAt = value.lastCacheUpdatedAt || null;
      state.lastAppliedCacheUpdatedAt = value.lastAppliedCacheUpdatedAt || null;
    } catch {}
  }
  async function request(path, options = {}){
    const method = String(options.method || 'GET').toUpperCase();
    const maxRetries = method === 'GET' ? 2 : 0;
    let attempt = 0;
    while (true) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(new Error('本机桥接请求超时')), CONFIG.requestTimeoutMs);
      try {
        const response = await fetch(url(path), Object.assign({
          cache: 'no-store', signal: controller.signal
        }, options));
        const text = await response.text();
        let data = {};
        try { data = text ? JSON.parse(text) : {}; }
        catch { data = { raw: text.slice(0, 240) }; }
        if (!response.ok) {
          const error = new Error(data.error || `${response.status} ${response.statusText}`);
          error.status = response.status;
          if (method === 'GET' && [408, 425, 500, 502, 503, 504].includes(response.status) && attempt < maxRetries) {
            warn(`本机桥接 ${path} 返回 HTTP ${response.status}，${attempt + 1}/${maxRetries} 次有限重试`);
            await delay(250 * (attempt + 1)); attempt++; continue;
          }
          throw error;
        }
        return data;
      } catch (error) {
        const retryable = method === 'GET' && error.status !== 429 && attempt < maxRetries
          && (error instanceof TypeError || error.name === 'AbortError' || error.message === '本机桥接请求超时');
        if (!retryable) throw error;
        warn(`本机桥接 ${path} 暂时不可用，${attempt + 1}/${maxRetries} 次有限重试：${error.message}`);
        await delay(250 * (attempt + 1)); attempt++;
      } finally { clearTimeout(timeout); }
    }
  }

  function readRecords(){
    try {
      const data = JSON.parse(localStorage.getItem('ff14_all_kill_records') || '[]');
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }
  function buildLatestIndex(records){
    const index = new Map();
    for (const item of records.slice(0, CONFIG.maxHistoryScan)) {
      if (!item?.server || !item?.name) continue;
      const inferredDc = dataCenterForWorld(item.server);
      const dataCenter = item.dataCenter || inferredDc;
      // Dynamic worlds are accepted only with an explicit known DC from the bridge;
      // built-in worlds must always match their canonical ownership.
      if (!dataCenter || !KNOWN_DATA_CENTERS.includes(dataCenter) || (inferredDc && inferredDc !== dataCenter)) continue;
      let ms = Number(item.killTimeMs || item.killTsMs || (Number(item.killTs) > 0 ? Number(item.killTs) * 1000 : 0));
      if (!Number.isFinite(ms) || ms <= 0) ms = item.time ? (Date.parse(String(item.time).replace(/-/g, '/')) || 0) : 0;
      const key = `${dataCenter}|${item.server}|${normalizeRecordName(item.name)}`;
      if (ms > (index.get(key) || 0)) index.set(key, ms);
    }
    return index;
  }
  function resolveLocalMonster(name){
    const key=normalizeRecordName(name);
    if(!key||!localMonsterList.length)return null;
    return localMonsterList.find(monster=>normalizeRecordName(monster.name)===key||
      (Array.isArray(monster.aliases)&&monster.aliases.some(alias=>normalizeRecordName(alias)===key)))||null;
  }
  function isKnownLocalSName(name){return !!resolveLocalMonster(name);}

  function readBearTimerWindow(record, killTs){
    const raw=record?.window;
    // A future kill anchor is never a valid CD base, even if within the
    // bridge parser's small clock-skew allowance. Fail closed at the UI edge.
    if(!Number.isFinite(Number(killTs))||Number(killTs)<=0||Number(killTs)>Date.now()/1000)return null;
    if(!raw||typeof raw!=='object')return null;
    const minHours=Number(raw.minHours),maxHours=Number(raw.maxHours);
    const startTs=Number(raw.startTs),endTs=Number(raw.endTs);
    const expectedStart=Number(killTs)+minHours*3600;
    const expectedEnd=Number(killTs)+maxHours*3600;
    // The source must explicitly report its maintenance state. Missing state is
    // not equivalent to normal operation; otherwise a maintenance CD can be misreported.
    if(typeof record.maint!=='boolean'||!Number.isFinite(minHours)||!Number.isFinite(maxHours)||minHours<=0||maxHours<minHours||maxHours>500
      ||!Number.isFinite(startTs)||!Number.isFinite(endTs)||endTs<=startTs
      ||Math.abs(startTs-expectedStart)>1||Math.abs(endTs-expectedEnd)>1)return null;
    const source=String(record.timerWindowSource||'');
    const trustLevel=String(record.trustLevel||'');
    const acceptedTrustLevels=new Set(['corroborated','validated-single-source','supplemental-single-source']);
    const fetchedAtMs=Date.parse(String(record.timerResourcesFetchedAt||record.bearTimerResourcesFetchedAt||''));
    const resourceAgeMs=Date.now()-fetchedAtMs;
    if(source!=='bear-resource-definition'||!acceptedTrustLevels.has(trustLevel)
      ||!Number.isFinite(fetchedAtMs)||resourceAgeMs < -5*60*1000||resourceAgeMs > MAX_BEAR_TIMER_RESOURCE_AGE_MS)return null;
    return {cdHours:minHours,windowHours:maxHours-minHours,maxHours,startTs,endTs,
      maint:record.maint===true,source,trustLevel,resourcesFetchedAt:new Date(fetchedAtMs).toISOString()};
  }

  function applyRecord(record, latestIndex, addedRecords){
    const server = String(record?.worldName || record?.server || '').trim();
    const inputName = String(record?.huntName || record?.sName || record?.name || '').trim();
    const localMonster = resolveLocalMonster(inputName);
    const name = localMonster?.name || inputName;
    const killTs = toSeconds(record?.lastDeathTime ?? record?.killTs ?? record?.time ?? record?.lastDeathAt);
    const bearWindow = readBearTimerWindow(record, killTs);
    const inferredDc = dataCenterForWorld(server);
    const recordDc = String(record?.dataCenter || inferredDc || '').trim();
    if (!server || !name || !killTs || !bearWindow || !KNOWN_DATA_CENTERS.includes(recordDc) || (inferredDc && recordDc !== inferredDc) || (record.rank !== 's' && Number(record.rankCode) !== 5)) {
      state.skipped++;
      return false;
    }
    if (!localMonster) {
      state.skipped++;
      return false;
    }
    const killMs = killTs * 1000;
    const key = `${recordDc}|${server}|${normalizeRecordName(name)}`;
    const latestKillMs = latestIndex.get(key) || 0;
    if (latestKillMs >= killMs) {
      // Bear may change a hunt's maintenance/normal timer window while its kill
      // anchor stays the same. Treat an identical timestamp with changed,
      // validated Bear metadata as an update, not as a duplicate snapshot.
      if (latestKillMs === killMs) {
        const currentRows = readRecords();
        const rowKillMs = row => {
          const value = Number(row?.killTimeMs || row?.killTsMs || 0) || (Number(row?.killTs) > 0 ? Number(row.killTs) * 1000 : 0);
          if (value > 0) return value;
          const parsed = row?.time ? Date.parse(String(row.time).replace(/-/g, '/')) : 0;
          return Number.isFinite(parsed) ? parsed : 0;
        };
        const candidates = currentRows.filter(row => {
          const rowDc = row?.dataCenter || dataCenterForWorld(row?.server);
          return rowDc === recordDc && row?.server === server
            && normalizeRecordName(row?.name || '') === normalizeRecordName(name)
            && Math.abs(rowKillMs(row) - killMs) < 1000;
        }).sort((a, b) => Number(b?.syncReceivedAt || b?.bearSyncedAt || 0) - Number(a?.syncReceivedAt || a?.bearSyncedAt || 0));
        const existing = candidates.find(row => row?.syncSource === 'bear-tracker-anonymous') || candidates[0];
        if (existing) {
          const metadataChanged = Number(existing.bearCdHours) !== bearWindow.cdHours
            || Number(existing.bearWindowHours) !== bearWindow.windowHours
            || Number(existing.bearMaxHours) !== bearWindow.maxHours
            || (existing.bearMaint === true) !== bearWindow.maint
            || Number(existing.bearWindowStartTs) !== bearWindow.startTs
            || Number(existing.bearWindowEndTs) !== bearWindow.endTs
            || String(existing.bearTimerSource || '') !== bearWindow.source
            || String(existing.bearTimerResourcesFetchedAt || '') !== bearWindow.resourcesFetchedAt;
          if (metadataChanged) {
            // Keep the original source/manual fields on the history record; the
            // validated Bear timing fields are an additional authoritative overlay.
            existing.dataCenter = recordDc;
            existing.bearCdHours = bearWindow.cdHours;
            existing.bearWindowHours = bearWindow.windowHours;
            existing.bearMaxHours = bearWindow.maxHours;
            existing.bearMaint = bearWindow.maint;
            existing.bearWindowStartTs = bearWindow.startTs;
            existing.bearWindowEndTs = bearWindow.endTs;
            existing.bearTimerSource = bearWindow.source;
            existing.bearTrustLevel = bearWindow.trustLevel;
            existing.bearTimerResourcesFetchedAt = bearWindow.resourcesFetchedAt;
            existing.bearSyncedAt = Date.now();
            addedRecords.push(existing);
            latestIndex.set(key, killMs);
            state.pulled++;
            return true;
          }
        }
      }
      state.skipped++;
      return false;
    }
    if (typeof window.addAllKillRecord !== 'function') return false;

    const row = window.addAllKillRecord(server, name, localMonster.area || record.region || record.area || '', '同步数据', {
      triggerTimeMs: killMs, killTimeMs: killMs, syncSource: 'bear-tracker-anonymous', dataCenter: recordDc,
      version: localMonster.version || '', bearCdHours: bearWindow.cdHours,
      bearWindowHours: bearWindow.windowHours, bearMaxHours: bearWindow.maxHours,
      bearMaint: bearWindow.maint, bearWindowStartTs: bearWindow.startTs,
      bearWindowEndTs: bearWindow.endTs, bearTimerSource: bearWindow.source,
      bearTrustLevel: bearWindow.trustLevel, bearTimerResourcesFetchedAt: bearWindow.resourcesFetchedAt
    });
    if (!row || typeof row !== 'object') return false;
    row.killTimeMs = killMs;
    row.killTs = killTs;
    row.triggerTimeMs = killMs;
    row.time = localDate(killTs);
    row.syncSource = 'bear-tracker-anonymous';
    row.dataCenter = recordDc;
    row.area = localMonster.area || row.area || record.region || record.area || '';
    row.version = String(localMonster.version || row.version || '').replace(/^版本/, '');
    row.syncReceivedAt = Date.now();
    row.bearCdHours = bearWindow.cdHours;
    row.bearWindowHours = bearWindow.windowHours;
    row.bearMaxHours = bearWindow.maxHours;
    row.bearMaint = bearWindow.maint;
    row.bearWindowStartTs = bearWindow.startTs;
    row.bearWindowEndTs = bearWindow.endTs;
    row.bearTimerSource = bearWindow.source;
    row.bearTrustLevel = bearWindow.trustLevel;
    row.bearTimerResourcesFetchedAt = bearWindow.resourcesFetchedAt;
    latestIndex.set(key, killMs);
    addedRecords.push(row);
    state.pulled++;
    return true;
  }

  function persistAddedBatch(addedRecords){
    if (!addedRecords.length) return;
    const current = readRecords();
    const rowDc = row => row?.dataCenter || dataCenterForWorld(row?.server);
    const recordKey = row => `${rowDc(row) || 'unassigned'}|${row?.server || ''}|${normalizeRecordName(row?.name || '')}`;
    const replacedBearKeys = new Set(addedRecords.filter(row => row?.syncSource === 'bear-tracker-anonymous').map(recordKey));
    const rowAnchorMs = row => Number(row?.killTimeMs || row?.killTsMs || 0) || (Number(row?.killTs) > 0 ? Number(row.killTs) * 1000 : 0);
    const exactLocalUpdates = new Set(addedRecords.filter(row => row?.syncSource !== 'bear-tracker-anonymous')
      .map(row => `${recordKey(row)}|${String(row?.syncSource || '')}|${rowAnchorMs(row)}`));
    // New Bear anchors replace older Bear anchors only in the same DC + world +
    // hunt partition. Same-anchor updates replace only the exact local snapshot
    // they were merged into; older manual history remains untouched.
    const retained = current.filter(row => {
      if (row?.syncSource === 'bear-tracker-anonymous' && replacedBearKeys.has(recordKey(row))) return false;
      const exactKey = `${recordKey(row)}|${String(row?.syncSource || '')}|${rowAnchorMs(row)}`;
      return !exactLocalUpdates.has(exactKey);
    });
    // Also collapse legacy Bear rows that differ only by spacing/punctuation. Keep
    // manual records untouched and keep each data-center/world partition separate.
    const dedupedBearKeys = new Set();
    const dedupedAdded = addedRecords.slice().reverse().filter(row => {
      const key=recordKey(row);if(dedupedBearKeys.has(key))return false;dedupedBearKeys.add(key);return true;
    });
    // addAllKillRecord unshifts each record, so reverse the collected batch for newest-first order.
    const merged = [...dedupedAdded, ...retained];
    const max = Math.max(1000, Number(window.PredictorConfig?.MAX_RECORDS) || 5000);
    const bounded = merged.slice(0, max);
    try {
      if (typeof window.__ff14ReplaceKillRecords === 'function') {
        if (!window.__ff14ReplaceKillRecords(bounded)) throw new Error('宿主记录存储拒绝写入');
      } else {
        localStorage.setItem('ff14_all_kill_records', JSON.stringify(bounded));
      }
    } catch (error) { warn('保存同步记录失败：', error.message); }
  }

  async function pullSnapshot(syncAt){
    if (pullBusy) return { added: 0, busy: true };
    pullBusy = true;
    try {
      const data = await request('/hunts?rank=s');
      const rows = Array.isArray(data.hunts) ? data.hunts : [];
      const existing = readRecords();
      const latestIndex = buildLatestIndex(existing);
      let added = 0;
      for (let offset = 0; offset < rows.length; offset += CONFIG.pullChunkSize) {
        const chunk = rows.slice(offset, offset + CONFIG.pullChunkSize);
        const batch = [];
        const previousBulk = window.__ff14MonitorBulkSyncActive;
        const originalDirtyMarker = window.__ff14MonitorMarkKillRecordsDirty;
        const predictor = window.__predictor;
        const originalInvalidate = predictor && predictor.invalidate;
        try {
          // Keep the bulk flag only during this synchronous chunk; never leave it set across a yield.
          window.__ff14MonitorBulkSyncActive = true;
          if (typeof originalDirtyMarker === 'function') window.__ff14MonitorMarkKillRecordsDirty = () => {};
          if (predictor && typeof originalInvalidate === 'function') predictor.invalidate = () => {};
          for (const row of chunk) if (applyRecord(row, latestIndex, batch)) added++;
        } finally {
          window.__ff14MonitorBulkSyncActive = previousBulk;
          if (typeof originalDirtyMarker === 'function') window.__ff14MonitorMarkKillRecordsDirty = originalDirtyMarker;
          if (predictor && typeof originalInvalidate === 'function') predictor.invalidate = originalInvalidate;
        }
        // Persist once per small batch, then yield so input/render work can proceed.
        if (batch.length) persistAddedBatch(batch);
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      if (added) {
        refreshUI();
      } else {
        // A snapshot can be newer for the monitor even when every kill anchor is
        // already present in local history. Still re-send the authoritative
        // host binding payload; otherwise the embedded monitor can remain blank.
        try { window.FF14TriggerMonitorHostBindingRefresh?.(); } catch {}
        try { window.dispatchEvent(new CustomEvent('ff14:kill-records-changed')); } catch {}
        rebuildLatestRecordsIndex();
        refreshCalculatorSnapshot();
      }
      if (syncAt) state.lastAppliedSyncAt = syncAt;
      state.lastAppliedCacheUpdatedAt = data.updatedAt || state.lastCacheUpdatedAt || null;
      state.lastCacheUpdatedAt = data.updatedAt || state.lastCacheUpdatedAt || null;
      rebuildLatestRecordsIndex();
      persistState();
      updatePanelStatus();
      log(`S 怪 CD 快照应用完成：新增 ${added} 条，已存在/跳过 ${rows.length - added} 条`);
      return { added, count: rows.length };
    } finally { pullBusy = false; }
  }

  function refreshUI(){
    // Exactly one refresh pass after an imported batch, not once per monster.
    try { window.renderRecentList?.(); } catch {}
    try { window.renderAllKillRecordsList?.(); } catch {}
    try { window.calcManual?.(); } catch {}
    try { window.__predictor?.invalidate?.(); } catch {}
    try { window.FF14TriggerMonitorHostBindingRefresh?.(); } catch {}
    rebuildLatestRecordsIndex();
    try { window.dispatchEvent(new CustomEvent('ff14:kill-records-changed')); } catch {}
    refreshCalculatorSnapshot();
  }

  function formatStamp(value){
    if(!value)return '暂无';
    const date=new Date(value);
    return Number.isFinite(date.getTime())?date.toLocaleString():'暂无';
  }
  function updatePill(){
    if(!pill)return;
    const text=state.syncStatus==='bridge-version-mismatch'?'同步数据 · 桥接版本不匹配':!state.serviceReady?'同步数据 · 服务未连接':state.syncRunning?`同步数据 · ${Math.round(state.progressPercent||0)}%`:state.syncStatus==='error'?'同步数据 · 读取/校验异常':state.syncStatus==='empty'?'同步数据 · 本轮无有效记录':state.syncStatus==='partial'?'同步数据 · 部分记录待核验':`同步数据 · ${state.timerCount} 条缓存`;
    pill.textContent=text;
    pill.dataset.state=!state.serviceReady?'off':state.syncRunning?'pending':['error','empty','partial'].includes(state.syncStatus)?'warn':'on';
  }
  function renderWorldResults(){
    if(!worldList)return;
    const rows=Array.isArray(state.worldResults)?state.worldResults:[];
    worldList.replaceChildren();
    if(!rows.length){const empty=document.createElement('div');empty.className='ff14-bear-empty';empty.textContent='尚无服务器同步记录。保存大区后会显示每个服务器的状态。';worldList.appendChild(empty);return;}
    const fragment=document.createDocumentFragment();
    for(const row of rows){
      const item=document.createElement('div');item.className='ff14-bear-world-row';
      const left=document.createElement('div');left.className='ff14-bear-world-name';
      const strong=document.createElement('strong');strong.textContent=row.world||'未知服务器';
      const accepted=Number(row.records)||0;const raw=Number(row.rawRecords)||0;const parsed=Number(row.parsedRecords)||0;
      const distinct=Number(row.distinctRecords)||0;const rejected=Number(row.rejectedRecords)||0;
      const duplicates=Number(row.duplicateRecords)||0;const isolated=Number(row.isolatedRecords)||0;const ignored=Number(row.ignoredRecords)||0;
      const diagnostics=row.responseDiagnostics||{};
      const fallback=row.fallbackDiagnostics||row.worldFallback||null;
      const requestDiag=diagnostics.requestDiagnostics||{};
      const requestHint=requestDiag.endpoint?` · 请求 ${requestDiag.endpoint} · ${requestDiag.rankType||'rank?'} · ${Array.isArray(requestDiag.requestWorlds)?requestDiag.requestWorlds.length:0} 台` : '';
      const detail=raw>0?`原始 ${raw} · 解析 ${parsed} · 去重 ${distinct} · 有效 ${accepted} · 拒绝 ${rejected} · 重复 ${duplicates} · 隔离 ${isolated}${ignored?` · 忽略 ${ignored}`:''}${row.httpStatus?` · HTTP ${row.httpStatus}`:''}${row.source?` · 来源 ${row.source}`:''}`:`${row.note||'本轮没有返回计时记录'}${row.httpStatus?` · HTTP ${row.httpStatus}`:''}${diagnostics.contentType?` · ${diagnostics.contentType}`:''}${diagnostics.payloadKeys?.length?` · 返回字段 ${diagnostics.payloadKeys.join(',')}`:''}${fallback?` · 单服复核 ${fallback.status||'已运行'} HTTP ${fallback.httpStatus??'—'} raw ${fallback.rawRecords??0}`:''}${requestHint}`;

      const small=document.createElement('small');small.textContent=`${row.dataCenter||''} · ${detail}`;
      left.append(strong,small);
      const status=document.createElement('span');status.className='ff14-bear-world-state';
      const labels={queued:'排队中',requesting:'请求中',validating:'校验中',validated:'已校验',saving:'保存中',saved:'已保存',partial:'部分通过',empty:'接口无记录',isolated:'全部记录已隔离',querying:'逐只查询',error:'校验/读取异常'};
      status.textContent=labels[row.status]||row.status||'等待中';status.dataset.state=row.status||'queued';
      item.append(left,status);
      if(row.error){const error=document.createElement('small');error.className='ff14-bear-world-error';error.textContent=row.error;item.appendChild(error);}
      const responseSample=row.responseSample||diagnostics.responseSample||fallback?.responseSample;if(responseSample){const sample=document.createElement('small');sample.className='ff14-bear-world-error';sample.textContent=`响应样本：${String(responseSample).slice(0,240)}`;item.appendChild(sample);}
      fragment.appendChild(item);
    }
    worldList.appendChild(fragment);
  }
  function updatePanelStatus(){
    const target=panel?.querySelector('[data-role="connection"]');
    if(target){
      if(!state.serviceReady)target.textContent=state.lastError||'本机同步服务尚未连接。请检查桌面端桥接后台是否启动。';
      else {
        const dcLines=KNOWN_DATA_CENTERS.map(dc=>{const item=state.byDataCenter?.[dc];if(!item)return `${dc}：尚无同步记录`;const label=item.status==='completed'?'有有效数据':item.status==='partial'?'部分通过':item.status==='empty'?'接口无记录':item.status==='error'?'读取/校验异常':item.status==='running'?'读取中':'待同步';const evidence=item.rawRecords!=null?` · HTTP ${item.responseDiagnostics?.httpStatus??item.httpStatus??'—'} · raw ${item.rawRecords}/parsed ${item.parsedRecords||0}/accepted ${item.recordsFound||0}/rejected ${item.rejectedRecords||0}`:'';const liveIgnored=item.liveIgnoredHunts?` · Live 未映射词条 ${item.liveIgnoredHunts}`:'';const diag=item.responseDiagnostics||{};const fallback=Array.isArray(diag.perWorldFallback)?diag.perWorldFallback.length:Array.isArray(item.bulkFallback?.perWorldFallback)?item.bulkFallback.perWorldFallback.length:0;const routeEvidence=diag.primaryRawRecords!=null?` · 批量 ${diag.primaryRawRecords} 条/${diag.primaryReturnedWorlds??0} 台 · 单服复核 ${fallback} 台${diag.contentType?` · ${diag.contentType}`:''}`:item.sourceUsed?` · 来源 ${item.sourceUsed}${item.liveHttpStatus?` · Live HTTP ${item.liveHttpStatus}`:''}${item.bulkFallback?` · 备用批量 raw ${item.bulkFallback.rawRecords??0} / 单服复核 ${fallback} 台 · HTTP ${item.bulkFallback.httpStatus??'—'}`:''}`:'';return `${dc}：${label}${evidence}${routeEvidence}${liveIgnored} · 最近成功 ${formatStamp(item.lastSuccessAt)}${item.lastError?` · ${item.lastError}`:''}`;}).join('\n');
        const selectedWorldCount=Object.values(state.worldSelections||{}).reduce((sum,list)=>sum+(Array.isArray(list)?list.length:0),0);
        target.textContent=`桌面 v${state.desktopVersion} · 本机服务：已连接 · 桥接 v${state.bridgeVersion||'未知'} · 端口 ${state.bridgePort}\n当前订阅：${(state.dataCenters||[]).join('、')||'尚未选择'} · ${selectedWorldCount} 台服务器\nS 怪词库：${state.sRankCount} 只 · 本地缓存：${state.timerCount} 条\n${dcLines}\n当前并行读取：${(state.activeDataCenters||[]).join('、')||'无'}\n本轮有效记录：${state.validatedRecords||0}（未变化 ${state.unchangedRecords||0}）· 字段拒绝：${state.rejectedRecords||0} · 空数据大区：${state.emptyDataCenters||0} · 部分数据大区：${state.partialDataCenters||0}\n多路线核验：交叉确认 ${state.corroboratedRecords||0} · 单源校验 ${state.singleSourceRecords||0} · 冲突隔离 ${state.quarantinedRecords||0}\n最近完成：${formatStamp(state.lastSyncAt)} · 最近成功：${formatStamp(state.lastSuccessAt)}\n${state.lastError?`最近错误：${state.lastError}`:'当前无错误'}`;
      }
    }
    const mapping=panel?.querySelector('[data-role="mapping-count"]');
    if(mapping)mapping.textContent=`Bear Tracker Rank=5：${state.sRankCount} 只；工具箱正式 S 怪：${localMonsterList.length} 只；已绑定：${Object.keys(cachedAliases).length} 条。`;
    const phase=panel?.querySelector('[data-role="phase"]');if(phase)phase.textContent=state.phaseLabel||'等待同步';
    const percent=Math.max(0,Math.min(100,Number(state.progressPercent)||0));
    const bar=panel?.querySelector('[data-role="progress"]');if(bar)bar.style.width=`${percent}%`;
    const track=panel?.querySelector('.ff14-bear-progress-track[role="progressbar"]');if(track)track.setAttribute('aria-valuenow',String(percent));
    renderProgressExplanation();
    const pct=panel?.querySelector('[data-role="percent"]');if(pct)pct.textContent=`${percent.toFixed(1)}%`;
    const queue=panel?.querySelector('[data-role="queue"]');if(queue){const queued=Number(state.requestQueue)||0;queue.textContent=`待请求 ${queued} 台服务器 · 已处理 ${state.completed}/${state.totalTargets} 台服务器请求`+((state.activeDataCenters||[]).length?` · 并行：${state.activeDataCenters.join('、')}`:'')+(state.syncRunning&&state.phase==='request'?' · 等待整区响应':'');}
    const sync=panel?.querySelector('[data-action="sync"]');if(sync){sync.disabled=!state.serviceReady||state.syncRunning;sync.textContent=state.syncRunning?'正在同步…':'立即同步所选大区';}
    const pause=panel?.querySelector('[data-action="pause"]');if(pause)pause.disabled=!state.serviceReady||!state.syncRunning||state.paused||state.pauseRequested;
    const resume=panel?.querySelector('[data-action="resume"]');if(resume)resume.disabled=!state.serviceReady||(!state.paused&&!state.pauseRequested);
    const mappingBtn=panel?.querySelector('[data-action="save-maps"]');if(mappingBtn)mappingBtn.disabled=!state.serviceReady||!mappingLoaded;
    renderWorldResults();updatePill();refreshCalculatorSnapshot();
  }
  function applyHealth(health){
    state.bridgeVersion=String(health?.bridgeVersion||health?.sync?.bridgeVersion||'unknown');
    try{state.bridgePort=Number(new URL(CONFIG.baseUrl).port)||8790;}catch{state.bridgePort=8790;}
    const expectedBridgeVersion=String(CONFIG.expectedBridgeVersion||'').trim();
    const versionMismatch=!!expectedBridgeVersion&&state.bridgeVersion!==expectedBridgeVersion;
    state.serviceReady=!!health?.ok&&!versionMismatch;state.syncRunning=!!health?.sync?.running&&!versionMismatch;
    state.syncStatus=versionMismatch?'bridge-version-mismatch':(health?.sync?.status||(state.serviceReady?'ready':'offline'));
    if(versionMismatch)state.lastError=`桥接版本不匹配：桌面要求 v${expectedBridgeVersion}，当前服务为 v${state.bridgeVersion}。请完全退出桌面程序后重新打开。`;
    state.totalTargets=Number(health?.sync?.totalTargets)||0;state.completed=Number(health?.sync?.completed)||0;
    state.progressPercent=Number(health?.sync?.progressPercent)||0;
    state.phase=health?.sync?.phase||'idle';
    state.phaseLabel=health?.sync?.phaseLabel|| (state.syncRunning?'同步进行中':'等待同步');
    state.requestQueue=Number(health?.sync?.requestQueue)||0;
    state.worldResults=Array.isArray(health?.sync?.worldResults)?health.sync.worldResults:[];
    state.byDataCenter=health?.sync?.byDataCenter&&typeof health.sync.byDataCenter==='object'?health.sync.byDataCenter:{};
    state.activeDataCenters=Array.isArray(health?.sync?.activeDataCenters)?health.sync.activeDataCenters:[];
    state.corroboratedRecords=Number(health?.sync?.corroboratedRecords)||0;
    state.singleSourceRecords=Number(health?.sync?.singleSourceRecords)||0;
    state.quarantinedRecords=Number(health?.sync?.quarantinedRecords)||0;
    state.validatedRecords=Number(health?.sync?.validatedRecords)||0;
    state.unchangedRecords=Number(health?.sync?.unchangedRecords)||0;state.staleRecords=Number(health?.sync?.staleRecords)||0;
    state.rejectedRecords=Number(health?.sync?.rejectedRecords)||0;
    state.emptyDataCenters=Number(health?.sync?.emptyDataCenters)||0;
    state.partialDataCenters=Number(health?.sync?.partialDataCenters)||0;
    state.paused=!!health?.sync?.paused;state.pauseRequested=!!health?.sync?.pauseRequested;
    state.timerCount=Number(health?.timerCount)||0;state.sRankCount=Number(health?.sRankDefinitionCount)||0;
    state.aliasCount=Number(health?.aliasCount)||0;
    const reported=health?.dataCenters||health?.sync?.dataCenters;if(Array.isArray(reported)&&reported.length)state.dataCenters=reported.slice();
    ensureWorldSelections(state.dataCenters,health?.worldSelections||health?.sync?.worldSelections||state.worldSelections);
    state.lastSyncAt=health?.sync?.lastSyncAt||null;state.lastSuccessAt=health?.sync?.lastSuccessAt||null;
    if(!versionMismatch)state.lastError=health?.sync?.lastError||null;state.resourcesReady=!!health?.resourcesReady&&!versionMismatch;
    state.lastCacheUpdatedAt=health?.cacheUpdatedAt||null;
    updatePanelStatus();
  }
  async function refreshHealth({applySnapshot=true,forceSnapshot=false}={}){
    if(healthBusy)return null;healthBusy=true;
    try{
      const health=await request('/health');applyHealth(health);
      const cacheChanged=state.lastCacheUpdatedAt && state.lastCacheUpdatedAt!==state.lastAppliedCacheUpdatedAt;
      if(applySnapshot&&state.serviceReady&&!state.syncRunning&&(forceSnapshot||cacheChanged|| (state.lastSyncAt&&state.lastSyncAt!==state.lastAppliedSyncAt)))await pullSnapshot(state.lastSyncAt);
      return health;
    }catch(error){state.serviceReady=false;state.syncStatus='offline';state.lastError=error.message;updatePanelStatus();return null;}
    finally{healthBusy=false;}
  }
  function selectedDataCenters(){return Array.from(dcOptions?.querySelectorAll('[data-dc-option][aria-pressed="true"]')||[]).map(button=>button.dataset.dcOption);}
  function updateDcButtons(){
    if(!dcOptions)return;const selected=new Set(Array.isArray(state.dataCenters)?state.dataCenters:[]);
    dcOptions.querySelectorAll('[data-dc-option]').forEach(button=>{const active=selected.has(button.dataset.dcOption);button.setAttribute('aria-pressed',String(active));});
    renderWorldOptions();
  }
  function selectedWorldsForDc(dc){
    const all=Object.keys(WORLD_TO_DC).filter(world=>WORLD_TO_DC[world]===dc);
    const selected=state.worldSelections?.[dc];
    if(!Array.isArray(selected))return all;
    return all.filter(world=>selected.includes(world));
  }
  function ensureWorldSelections(dataCenters, incoming=state.worldSelections){
    const next={};
    for(const dc of dataCenters){
      const allowed=Object.keys(WORLD_TO_DC).filter(world=>WORLD_TO_DC[world]===dc);
      const raw=Array.isArray(incoming?.[dc])?incoming[dc]:allowed;
      const chosen=allowed.filter(world=>raw.includes(world));
      if(!chosen.length)throw new Error(`${dc} 至少保留一个服务器；如不需要该大区，请取消整个大区。`);
      next[dc]=chosen;
    }
    state.worldSelections=next;
  }
  function renderWorldOptions(){
    if(!worldOptions)return;
    worldOptions.replaceChildren();
    const fragment=document.createDocumentFragment();
    const selectedDcs=state.dataCenters||[];
    if(!selectedDcs.length){const empty=document.createElement('small');empty.textContent='先选择一个大区，系统会自动勾选它的全部服务器。';worldOptions.appendChild(empty);return;}
    for(const dc of KNOWN_DATA_CENTERS.filter(name=>selectedDcs.includes(name))){
      const group=document.createElement('section');group.className='ff14-bear-world-choice-group';
      const header=document.createElement('div');header.className='ff14-bear-world-choice-head';
      const title=document.createElement('strong');title.textContent=dc;
      const count=document.createElement('small');const chosen=selectedWorldsForDc(dc);const all=Object.keys(WORLD_TO_DC).filter(world=>WORLD_TO_DC[world]===dc);count.textContent=`${chosen.length}/${all.length} 个服务器已选`;
      header.append(title,count);group.appendChild(header);
      const grid=document.createElement('div');grid.className='ff14-bear-world-choice-grid';
      for(const world of all){
        const label=document.createElement('label');label.className='ff14-bear-world-choice';
        const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.dataset.worldChoice=world;checkbox.dataset.worldDc=dc;checkbox.checked=chosen.includes(world);
        checkbox.addEventListener('change',()=>{
          const current=selectedWorldsForDc(dc);
          const next=checkbox.checked?[...current,world]:current.filter(item=>item!==world);
          if(!next.length){checkbox.checked=true;setMessage(`${dc} 至少保留一个服务器；如不需要该大区，请取消大区选择。`,'warn');return;}
          state.worldSelections={...(state.worldSelections||{}),[dc]:all.filter(item=>next.includes(item))};
          renderWorldOptions();
        });
        const text=document.createElement('span');text.textContent=world;label.append(checkbox,text);grid.appendChild(label);
      }
      group.append(header,grid);fragment.appendChild(group);
    }
    worldOptions.appendChild(fragment);
  }
  function setSelectedDataCenters(names){
    const next=[...new Set((names||[]).filter(name=>KNOWN_DATA_CENTERS.includes(name)))];
    state.dataCenters=next;ensureWorldSelections(next,state.worldSelections);updateDcButtons();
  }
  function renderProgressExplanation(){
    const hint=panel?.querySelector('[data-role="progress-hint"]');if(!hint)return;
    hint.textContent=state.syncRunning&&state.phase==='request'?'当前整区请求尚未返回，进度保持不变；只在服务器请求真实返回后推进。进度只表示请求已处理，不代表发现记录或同步成功。':state.syncStatus==='empty'?'所有请求已处理，但没有取得有效记录；本轮不计为数据同步成功，旧缓存保持不变。':'进度按所选服务器的实际请求结果计算；有效 CD 记录数和实际写入数单独统计。';
  }
  function normalizeRecordName(value){
    return String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
  }
  function recordTimeMs(row){
    return Number(row?.killTimeMs||row?.killTsMs||0)||((Number(row?.killTs)||0)*1000)||(row?.time?Date.parse(String(row.time).replace(/-/g,'/')):0);
  }
  function rebuildLatestRecordsIndex(){
    const index=new Map();
    for(const row of readRecords().slice(0,CONFIG.maxHistoryScan)){
      const server=String(row?.server||'').trim(),name=normalizeRecordName(row?.name),ms=recordTimeMs(row);
      if(!server||!name||!Number.isFinite(ms)||ms<=0)continue;
      const dc=row?.dataCenter||dataCenterForWorld(server);
      if(!dc)continue;
      const key=`${dc}|${server}|${name}`,prior=index.get(key);
      if(!prior||ms>prior.timeMs)index.set(key,{row,timeMs:ms,dataCenter:dc});
    }
    latestRecordsIndex=index;
    return index;
  }
  function latestRecordFor(server,name){
    if(!server||!name)return null;
    const aliases=[name,...(localMonsterList.find(item=>item.name===name)?.aliases||[])];
    let best=null;
    const dataCenter=dataCenterForWorld(server);
    if(!dataCenter)return null;
    for(const alias of aliases){
      const hit=latestRecordsIndex.get(`${dataCenter}|${server}|${normalizeRecordName(alias)}`);
      if(hit&&(!best||hit.timeMs>best.timeMs))best=hit;
    }
    return best;
  }
  function formatDuration(ms){
    const seconds=Math.max(0,Math.floor(ms/1000));
    const days=Math.floor(seconds/86400),hours=Math.floor(seconds%86400/3600),minutes=Math.floor(seconds%3600/60),secs=seconds%60;
    return `${days?`${days}天 `:''}${String(hours).padStart(2,'0')}:${String(minutes).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
  }
  function calculatorCooldownHours(){
    try { if(typeof CD_HOURS!=='undefined'&&Number(CD_HOURS)>0)return Number(CD_HOURS); } catch {}
    return 84;
  }
  function calculatorLifeHours(){
    try { if(typeof LT_HOURS!=='undefined'&&Number(LT_HOURS)>0)return Number(LT_HOURS); } catch {}
    return 48;
  }
  function refreshCalculatorSnapshot(){
    const box=document.getElementById('ff14BearCalculatorSnapshot');if(!box)return;
    const server=document.getElementById('mServer')?.value?.trim()||'';
    const name=String(document.getElementById('mMonster')?.value||'').split('|')[0].trim();
    const match=latestRecordFor(server,name);
    const text=box.querySelector('[data-role="calculator-sync-text"]');
    const phase=box.querySelector('[data-role="calculator-cd-phase"]');
    const times=box.querySelector('[data-role="calculator-cd-times"]');
    const progress=box.querySelector('[data-role="calculator-cd-progress"]');
    const button=box.querySelector('[data-action="use-sync-time"]');
    if(!match){
      if(text)text.textContent=server&&name?`当前目标 ${server} / ${name} 暂无可用击杀锚点。`:'选择服务器和 S 怪后显示对应同步数据。';
      if(phase)phase.textContent='等待击杀数据';if(times)times.textContent='进闸时间：— · 强制时间：—';
      if(progress)progress.style.width='0%';if(button)button.disabled=true;box.dataset.timeMs='';return;
    }
    const now=Date.now(),killMs=match.timeMs;
    const syncedRow=match.row||{};
    const bearCdHours=Number(syncedRow.bearCdHours),bearWindowHours=Number(syncedRow.bearWindowHours);
    const bearMaxHours=Number(syncedRow.bearMaxHours),bearStartTs=Number(syncedRow.bearWindowStartTs),bearEndTs=Number(syncedRow.bearWindowEndTs);
    const anchorSec=killMs/1000;
    const bearClaimed=(syncedRow.syncSource==='bear-tracker-anonymous'||!!syncedRow.bearTimerSource);
    const bearTrustLevel=String(syncedRow.bearTrustLevel||'');
    const acceptedBearTrust=new Set(['corroborated','validated-single-source','supplemental-single-source']);
    const resourceFetchedAtMs=Date.parse(String(syncedRow.bearTimerResourcesFetchedAt||''));
    const resourceAgeMs=now-resourceFetchedAtMs;
    const bearResourceFresh=Number.isFinite(resourceFetchedAtMs)&&resourceAgeMs>=-5*60*1000&&resourceAgeMs<=MAX_BEAR_TIMER_RESOURCE_AGE_MS;
    const bearWindowValid=bearClaimed&&killMs<=now&&bearResourceFresh&&typeof syncedRow.bearMaint==='boolean'
      &&String(syncedRow.bearTimerSource||'')==='bear-resource-definition'
      &&acceptedBearTrust.has(bearTrustLevel)
      &&Number.isFinite(bearCdHours)&&bearCdHours>0
      &&Number.isFinite(bearWindowHours)&&bearWindowHours>=0
      &&Number.isFinite(bearMaxHours)&&bearMaxHours<=500&&Math.abs(bearMaxHours-(bearCdHours+bearWindowHours))<0.001
      &&Number.isFinite(bearStartTs)&&Number.isFinite(bearEndTs)
      &&Math.abs(bearStartTs-(anchorSec+bearCdHours*3600))<=1
      &&Math.abs(bearEndTs-(anchorSec+bearMaxHours*3600))<=1;
    if(bearClaimed&&!bearWindowValid){
      // Never substitute generic 84/48 defaults for an unverified Bear anchor.
      // This avoids presenting a plausible-looking but potentially wrong CD.
      const invalidReason=killMs>now?'击杀锚点位于未来':!bearResourceFresh?'Bear S 怪时间词库已过期':'逐怪 CD 时间窗 / 维护标记 / 来源可信级别未通过校验';
      if(text)text.textContent=`${match.dataCenter||dataCenterForWorld(server)||'未知大区'} · ${server} · ${name}：Bear 数据未核验（${invalidReason}）。为避免错误信息，暂不显示进闸 / 强制时间。`;
      if(phase)phase.textContent='⚠ CD 未核验 · 暂停计算';
      if(times)times.textContent='预计进闸：未核验 · 强制时间：未核验';
      if(progress)progress.style.width='0%';
      if(button)button.disabled=true;
      box.dataset.timeMs='';box.dataset.cdHours='';box.dataset.lifeHours='';
      return;
    }
    // The calculator summary and embedded monitor use the exact per-hunt Bear
    // resource window. Generic defaults are only for purely local/manual rows.
    const cdHours=bearWindowValid?bearCdHours:calculatorCooldownHours();
    const lifeHours=bearWindowValid?bearWindowHours:calculatorLifeHours();
    const cdMs=cdHours*3600000,lifeMs=lifeHours*3600000,gateMs=killMs+cdMs,forceMs=killMs+(bearWindowValid?bearMaxHours:cdHours+lifeHours)*3600000;
    const dt=new Date(killMs),gate=new Date(gateMs),force=new Date(forceMs);
    const source=bearWindowValid?'Bear Tracker 公开同步（逐怪 CD 窗口）':match.row.syncSource==='bear-tracker-anonymous'?'Bear Tracker 同步锚点（CD 参数待核验）':'本地记录';
    const dataCenter=match.dataCenter||dataCenterForWorld(server)||'未知大区';
    if(text)text.textContent=`${dataCenter} · ${server} · ${name}：${source}击杀锚点 ${dt.toLocaleString()}。只使用该大区独立缓存，不读取其他大区的 CD 锚点。`;
    if(now<killMs){
      if(phase)phase.textContent='击杀时间异常：时间位于未来，请先核对数据';
      if(times)times.textContent=`记录击杀：${dt.toLocaleString()} · 预计进闸：${gate.toLocaleString()} · 预计强制：${force.toLocaleString()}`;
      if(progress)progress.style.width='0%';
    }else if(now<gateMs){
      const pct=Math.min(100,Math.max(0,(now-killMs)/cdMs*100));
      if(phase)phase.textContent=`🔴 CD 冷却中 · 进闸剩余 ${formatDuration(gateMs-now)} · 已完成 ${pct.toFixed(1)}%`;
      if(times)times.textContent=`预计进闸：${gate.toLocaleString()} · 预计强制：${force.toLocaleString()} · CD ${cdHours}h`;
      if(progress)progress.style.width=`${pct}%`;
    }else if(now<forceMs){
      const pct=Math.min(100,Math.max(0,(now-gateMs)/lifeMs*100));
      if(phase)phase.textContent=`🟢 已进闸 · 存活窗口剩余 ${formatDuration(forceMs-now)} · 已用 ${pct.toFixed(1)}%`;
      if(times)times.textContent=`进闸时间：${gate.toLocaleString()} · 强制消失：${force.toLocaleString()} · 存活窗 ${lifeHours}h`;
      if(progress)progress.style.width=`${pct}%`;
    }else{
      if(phase)phase.textContent=`⚫ 已超过预计强制消失时间 ${formatDuration(now-forceMs)}`;
      if(times)times.textContent=`进闸时间：${gate.toLocaleString()} · 强制消失：${force.toLocaleString()}`;
      if(progress)progress.style.width='100%';
    }
    if(button)button.disabled=false;box.dataset.timeMs=String(killMs);
    box.dataset.cdHours=String(cdHours);box.dataset.lifeHours=String(lifeHours);
  }
  function mountCalculatorSnapshot(){
    const result=document.getElementById('manualResultBox');if(!result||document.getElementById('ff14BearCalculatorSnapshot'))return;
    calculatorCard=document.createElement('section');calculatorCard.id='ff14BearCalculatorSnapshot';calculatorCard.style.cssText='margin:12px 0;padding:10px 12px;border:1px solid rgba(46,160,112,.34);border-radius:12px;background:linear-gradient(120deg,rgba(35,160,110,.08),rgba(40,120,190,.06));font-size:12px;line-height:1.55;';
    calculatorCard.innerHTML='<div style="font-weight:800;margin-bottom:5px">同步数据 · 当前 S 怪 CD 状态</div><div data-role="calculator-sync-text" style="color:var(--text-muted);margin-bottom:8px">选择服务器和 S 怪后显示对应同步数据。</div><div data-role="calculator-cd-phase" aria-live="polite" style="font-weight:850;font-size:13px;margin:4px 0">等待击杀数据</div><div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden;margin:6px 0"><div data-role="calculator-cd-progress" style="height:100%;width:0%;background:linear-gradient(90deg,#d48b36,#2eb889);transition:width .25s"></div></div><div data-role="calculator-cd-times" style="color:var(--text-muted);font-size:10px;margin-bottom:8px">进闸时间：— · 强制时间：—</div><button type="button" data-action="use-sync-time" disabled style="border:1px solid rgba(46,160,112,.42);border-radius:8px;padding:6px 10px;background:rgba(35,160,110,.13);color:inherit;font-weight:750;cursor:pointer">将同步击杀时间填入计算器</button><div style="font-size:10px;color:var(--text-muted);margin-top:6px">状态每秒刷新；本地同步缓存每 30 秒更新。仅显示估算，不会覆盖正在编辑的输入；天气前置及监控室手动校准仍以原工具逻辑为准。</div>';
    result.insertAdjacentElement('afterend',calculatorCard);
    calculatorCard.querySelector('[data-action="use-sync-time"]').addEventListener('click',()=>{
      const ms=Number(calculatorCard.dataset.timeMs);if(!Number.isFinite(ms)||ms<=0)return;
      const radio=document.querySelector('input[name="mStatus"][value="red"]');if(radio){radio.checked=true;radio.dispatchEvent(new Event('change',{bubbles:true}));}
      const absolute=document.getElementById('mAbsoluteDateTime');
      if(absolute){const d=new Date(ms),pad=n=>String(n).padStart(2,'0');absolute.value=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;absolute.dispatchEvent(new Event('input',{bubbles:true}));absolute.dispatchEvent(new Event('change',{bubbles:true}));}
      const hour=document.getElementById('mHour'),minute=document.getElementById('mMin'),second=document.getElementById('mSec');
      const elapsed=Math.max(0,Math.floor((Date.now()-ms)/1000));if(hour)hour.value=String(Math.floor(elapsed/3600));if(minute)minute.value=String(Math.floor(elapsed%3600/60));if(second)second.value=String(elapsed%60);
      try{window.calcManual?.();}catch(_){}
      setMessage('已将同步击杀锚点填入计算器。请核对目标、CD 和天气前置后再保存。','success');
    });
    ['mServer','mMonster','mMonsterInput'].forEach(id=>{const el=document.getElementById(id);el?.addEventListener('change',refreshCalculatorSnapshot);el?.addEventListener('input',refreshCalculatorSnapshot);});
    document.getElementById('serverDropdownList')?.addEventListener('click',()=>setTimeout(refreshCalculatorSnapshot,80));
    document.getElementById('monsterDropdownList')?.addEventListener('click',()=>setTimeout(refreshCalculatorSnapshot,80));
    refreshCalculatorSnapshot();
    if(!window.__FF14BearCalculatorTicker)window.__FF14BearCalculatorTicker=setInterval(()=>{
      if(document.visibilityState==='hidden')return;
      const target=document.getElementById('ff14BearCalculatorSnapshot');
      if(target?.getClientRects().length)refreshCalculatorSnapshot();
    },1000);
  }

  function getLocalMonsters(){
    const source = window.FF14_OCR_DICTIONARY?.monsters;
    if (!Array.isArray(source)) return [];
    return source.map(monster => ({
      name: monster.name, area: monster.area || '', version: monster.version || '',
      aliases: monster.alias || monster.aliases || []
    })).filter(monster => monster.name);
  }

  function populateDataCenterOptions(){
    if(!dcOptions)return;
    dcOptions.replaceChildren();
    const current=new Set(Array.isArray(state.dataCenters)?state.dataCenters:[]);
    for(const name of KNOWN_DATA_CENTERS){
      const button=document.createElement('button');button.type='button';button.className='ff14-bear-dc-chip';button.dataset.dcOption=name;
      button.textContent=name;button.setAttribute('aria-pressed',String(current.has(name)));
      button.addEventListener('click',()=>{
        const selected=new Set(selectedDataCenters());
        if(selected.has(name)){
          if(selected.size===1){setMessage('至少保留一个数据中心。','warn');return;}
          selected.delete(name);
        }else{
          selected.add(name);
          // Newly selected DCs automatically select every supported world.
          state.worldSelections={...(state.worldSelections||{}),[name]:Object.keys(WORLD_TO_DC).filter(world=>WORLD_TO_DC[world]===name)};
        }
        if(!selected.has(name)){const next={...(state.worldSelections||{})};delete next[name];state.worldSelections=next;}
        setSelectedDataCenters([...selected]);
      });
      dcOptions.appendChild(button);
    }
  }

  async function loadMappingData(){
    if (mappingLoaded) return;
    try {
      // Fetch local settings independently from Bear resources. This lets players
      // preselect and save a DC immediately on first launch, even while remote
      // dictionary initialization is still in progress.
      const [health, settings] = await Promise.all([request('/health'), request('/settings')]);
        state.dataCenters = Array.isArray(settings.dataCenters) ? settings.dataCenters.slice() : (state.dataCenters || []);
      if (!state.dataCenters.length && settings.selectionConfirmed !== true) state.dataCenters = ['陆行鸟'];
      ensureWorldSelections(state.dataCenters, settings.worldSelections || {});
      cachedAliases = settings.aliases || {};
      localMonsterList = getLocalMonsters();
      updateDcButtons();
      if (!health.resourcesReady) {
        setMessage('Bear Tracker 公开词库仍在初始化。现在可以先选择并保存数据中心；词库就绪后会自动继续加载名称映射。', 'info');
        updatePanelStatus();
        return;
      }
      const resources = await request('/resources');
      const db = resources.DatabaseHunt || {};
      cachedRemoteHunts = Object.entries(db)
        .filter(([, definition]) => Number(definition?.Rank) === 5)
        .map(([name, definition]) => ({ name, region: definition.Region || '', patch: definition.Patch || '' }))
        .sort((a,b) => a.name.localeCompare(b.name));
      updateDcButtons();
      renderMappings();
      mappingLoaded = true;
      updatePanelStatus();
    } catch (error) {
      setMessage(`读取 S 怪词库失败：${error.message}`, 'error');
    }
  }

  function renderMappings(){
    if (!mapList) return;
    mapList.replaceChildren();
    const query = String(mapSearch?.value || '').trim().toLocaleLowerCase();
    const filtered = localMonsterList.filter(monster => !query || `${monster.name} ${monster.area} ${monster.version}`.toLocaleLowerCase().includes(query));
    if (!filtered.length) {
      const empty = document.createElement('p'); empty.className = 'ff14-bear-empty';
      empty.textContent = '没有找到工具箱正式 S 怪词条。'; mapList.appendChild(empty); return;
    }
    const fragment = document.createDocumentFragment();
    for (const monster of filtered) {
      const row = document.createElement('div'); row.className = 'ff14-bear-map-row';
      const label = document.createElement('label'); label.className = 'ff14-bear-map-label';
      const name = document.createElement('strong'); name.textContent = monster.name;
      const meta = document.createElement('small'); meta.textContent = `${monster.area || '地区未知'} · ${monster.version || '版本未知'}`;
      label.append(name, meta);
      const select = document.createElement('select'); select.dataset.localName = monster.name;
      const blank = document.createElement('option'); blank.value = ''; blank.textContent = '选择 Bear Tracker S 怪'; select.appendChild(blank);
      for (const remote of cachedRemoteHunts) {
        const option = document.createElement('option'); option.value = remote.name;
        option.textContent = `${remote.name} · ${remote.region || '地区未知'}`; select.appendChild(option);
      }
      let chosen = cachedAliases[monster.name] || '';
      if (!chosen) {
        const aliases = [monster.name, ...monster.aliases];
        const exact = cachedRemoteHunts.find(remote => aliases.some(alias => String(alias).toLowerCase() === remote.name.toLowerCase()));
        if (exact) chosen = exact.name;
      }
      if (chosen) select.value = chosen;
      row.append(label, select); fragment.appendChild(row);
    }
    mapList.appendChild(fragment);
  }

  async function saveMappings(){
    const aliases = {};
    const visibleNames = new Set();
    for (const select of mapList?.querySelectorAll('select[data-local-name]') || []) {
      visibleNames.add(select.dataset.localName);
      if (select.value) aliases[select.dataset.localName] = select.value;
    }
    for (const [name, value] of Object.entries(cachedAliases)) if (!visibleNames.has(name)) aliases[name] = value;
    const result = await request('/settings/aliases', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ aliases })
    });
    cachedAliases = aliases; state.aliasCount = Number(result.count) || Object.keys(aliases).length;
    setMessage(`S 怪名称映射已保存：${state.aliasCount} 条。现在启动一次后台同步。`, 'success');
    await startManualSync();
  }

  async function saveDataCenters(){
    const selected=selectedDataCenters();
    if(!selected.length)throw new Error('至少选择一个数据中心。');
    ensureWorldSelections(selected,state.worldSelections);
    const result=await request('/settings/data-centers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataCenters:selected,worldSelections:state.worldSelections})});
    state.dataCenters=result.dataCenters||selected;state.worldSelections=result.worldSelections||state.worldSelections;updateDcButtons();
    const worlds=Object.values(state.worldSelections).reduce((n,list)=>n+(Array.isArray(list)?list.length:0),0);
    setMessage(`已保存：${state.dataCenters.join('、')} · ${worlds} 个服务器。正在同步所选服务器。`,'info');
    await waitForSync();
  }
  async function waitForSync(){
    const token=++syncWaitToken,deadline=Date.now()+30*60*1000;
    while(token===syncWaitToken&&Date.now()<deadline){
      await delay(CONFIG.syncPollMs);const health=await refreshHealth({applySnapshot:false});if(!health)return;
      if(!health.resourcesReady&&health.sync?.status!=='error'){setMessage('正在初始化公开 S 怪词库…');continue;}
      if(!health.sync?.running&&['completed','partial','empty','error'].includes(String(health.sync?.status))){await refreshHealth({applySnapshot:true,forceSnapshot:true});const sync=health.sync||{};const valid=Number(sync.validatedRecords)||0;const written=Number(sync.recordsFound)||0;const summary=sync.status==='error'?`同步校验失败：${sync.lastError||'没有可信记录写入，旧缓存已保留。'}`:sync.status==='empty'||valid===0?`未取得有效数据：本轮 0 条可用 CD 记录，缓存未变。已处理 ${sync.completed||0}/${sync.totalTargets||0} 台服务器请求；空数据 ${sync.noRecord||0}，错误 ${sync.errors||0}。请查看逐服务器 HTTP 与响应结构诊断。${sync.lastError||''}`:sync.status==='partial'?`同步部分完成：有效 ${valid} 条，新增/更新 ${written} 条；拒绝 ${sync.rejectedRecords||0}，隔离 ${sync.quarantinedRecords||0}，错误 ${sync.errors||0}。请检查服务器明细。`:`同步数据已核验：有效 ${valid} 条，本次实际新增/更新 ${written} 条，完全一致未变化 ${Number(sync.unchangedRecords)||0} 条，旧锚点拒绝 ${Number(sync.staleRecords)||0} 条。${written===0?'数据与本地一致，没有产生新的 CD 变更。':''}`;setMessage(summary,sync.status==='completed'?'success':'warn');return;}
      const sync=health.sync||{};setMessage(sync.phase==='request'?'正在等待当前大区的公开接口响应；进度条不会虚增。':`${sync.phaseLabel||'同步中'}：${sync.completed||0}/${sync.totalTargets||0} 项`,'info');
    }
    if(token===syncWaitToken)setMessage('同步仍在后台执行；关闭面板不会停止同步，稍后打开即可查看最新状态。','warn');
  }
  async function startManualSync(){
    if(state.syncRunning){setMessage('同步正在后台执行，可使用暂停 / 恢复控制。','info');return;}
    const selected=selectedDataCenters();if(!selected.length)throw new Error('请至少选择一个数据中心。');
    try{
      ensureWorldSelections(selected,state.worldSelections);
      const saved=await request('/settings/data-centers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataCenters:selected,worldSelections:state.worldSelections})});
      state.dataCenters=saved.dataCenters||selected;state.worldSelections=saved.worldSelections||state.worldSelections;updateDcButtons();
      setMessage(`已启动：${selected.join('、')} · ${Object.values(state.worldSelections).reduce((n,list)=>n+(list?.length||0),0)} 个服务器。`, 'info');
      await waitForSync();
    }catch(error){setMessage(`启动同步失败：${error.message}`,'error');}
  }
  async function pauseSync(){try{const result=await request('/sync/pause',{method:'POST'});setMessage(result.note||'已请求暂停。当前整区请求会先结束。','warn');await refreshHealth({applySnapshot:false});}catch(error){setMessage(`暂停失败：${error.message}`,'error');}}
  async function resumeSync(){try{await request('/sync/resume',{method:'POST'});setMessage('同步已恢复。','success');await refreshHealth({applySnapshot:false});}catch(error){setMessage(`恢复失败：${error.message}`,'error');}}

  function setMessage(message, kind = 'info'){
    const node = panel?.querySelector('[data-role="message"]');
    if (node) { node.textContent = message; node.dataset.kind = kind; }
  }

  function createPanel(){
    if(!document.body||document.getElementById('ff14BearBridgeStatus'))return;
    const style=document.createElement('style');style.id='ff14-bear-bridge-ui-style-v421';
    style.textContent=`
      #ff14BearBridgeStatus{font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#eef4ff;width:100%}
      #ff14BearBridgeStatus [hidden]{display:none!important}
      #ff14BearBridgeStatus .ff14-bear-pill{display:none!important}
      #ff14BearBridgeStatus .ff14-bear-panel{position:static;width:100%;max-height:min(72vh,720px);display:flex;flex-direction:column;overflow:hidden;border:1px solid rgba(148,163,184,.45);border-radius:16px;background:rgba(14,23,38,.97);box-shadow:0 12px 34px #0004}
      #ff14BearBridgeStatus .ff14-bear-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #ffffff1c;font-size:16px;font-weight:800}
      #ff14BearBridgeStatus .ff14-bear-head button{border:0;background:transparent;color:#d7e3f5;font-size:20px;cursor:pointer}
      #ff14BearBridgeStatus .ff14-bear-body{padding:12px 14px 15px;overflow:auto;overscroll-behavior:contain}
      #ff14BearBridgeStatus .ff14-bear-note{margin:0 0 10px;color:#b8c8dc;font-size:12px}
      #ff14BearBridgeStatus .ff14-bear-status{white-space:pre-line;border:1px solid #ffffff20;background:#ffffff09;border-radius:10px;padding:9px 11px;color:#dce8f7;font-size:12px;margin-bottom:10px}
      #ff14BearBridgeStatus button.ff14-bear-action{border:1px solid #71839b80;border-radius:9px;background:#26364c;color:#f1f5fb;padding:8px 11px;cursor:pointer;font:inherit;font-weight:650}
      #ff14BearBridgeStatus button.ff14-bear-primary{background:#176b53;border-color:#3eae88}#ff14BearBridgeStatus button:disabled{opacity:.45;cursor:not-allowed}
      #ff14BearBridgeStatus .ff14-bear-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:9px}
      #ff14BearBridgeStatus .ff14-bear-message{margin:10px 0;color:#b7c8dd;font-size:12px;white-space:pre-wrap}#ff14BearBridgeStatus .ff14-bear-message[data-kind="error"]{color:#ff9b9b}#ff14BearBridgeStatus .ff14-bear-message[data-kind="success"]{color:#76ddb4}#ff14BearBridgeStatus .ff14-bear-message[data-kind="warn"]{color:#ffd27b}
      #ff14BearBridgeStatus .ff14-bear-section{margin-top:13px;padding-top:12px;border-top:1px solid #ffffff1c}
      #ff14BearBridgeStatus .ff14-bear-section-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;font-weight:700}
      #ff14BearBridgeStatus .ff14-bear-muted{color:#9fb0c7;font-size:11px;font-weight:400}
      #ff14BearBridgeStatus .ff14-bear-progress-head{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;margin:10px 0 6px}
      #ff14BearBridgeStatus .ff14-bear-progress-track{height:10px;border-radius:999px;overflow:hidden;background:#081321;border:1px solid #ffffff20}
      #ff14BearBridgeStatus .ff14-bear-progress-fill{height:100%;width:0%;background:linear-gradient(90deg,#2eb889,#58a6ff);transition:width .18s ease}
      #ff14BearBridgeStatus .ff14-bear-progress-hint{font-size:10px;color:#92a7c1;margin-top:5px}
      #ff14BearBridgeStatus .ff14-bear-dc-options{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}
      #ff14BearBridgeStatus .ff14-bear-dc-chip{border:1px solid #ffffff2d;background:#101e31;color:#dbe8f8;border-radius:9px;padding:8px 5px;font:inherit;font-size:12px;font-weight:750;cursor:pointer}
      #ff14BearBridgeStatus .ff14-bear-dc-chip[aria-pressed="true"]{border-color:#34c99a;background:rgba(33,154,117,.24);color:#9ff3d3}
      #ff14BearBridgeStatus .ff14-bear-world-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:9px}
      #ff14BearBridgeStatus .ff14-bear-world-choice-group{border:1px solid #ffffff22;border-radius:10px;padding:8px;background:#ffffff06}
      #ff14BearBridgeStatus .ff14-bear-world-choice-head{display:flex;justify-content:space-between;gap:6px;align-items:center;margin-bottom:7px}
      #ff14BearBridgeStatus .ff14-bear-world-choice-head strong{font-size:12px}
      #ff14BearBridgeStatus .ff14-bear-world-choice-head small{font-size:10px;color:#a9bad0}
      #ff14BearBridgeStatus .ff14-bear-world-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px}
      #ff14BearBridgeStatus .ff14-bear-world-choice{display:flex;align-items:center;gap:5px;padding:5px 6px;border-radius:7px;background:#ffffff08;font-size:11px;cursor:pointer}
      #ff14BearBridgeStatus .ff14-bear-world-choice input{width:auto;accent-color:#34c99a}
      #ff14BearBridgeStatus .ff14-bear-worlds{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;max-height:260px;overflow:auto}
      #ff14BearBridgeStatus .ff14-bear-world-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:6px;padding:7px 8px;border:1px solid #ffffff17;border-radius:9px;background:#ffffff07;min-width:0}
      #ff14BearBridgeStatus .ff14-bear-world-name{display:flex;flex-direction:column;min-width:0}#ff14BearBridgeStatus .ff14-bear-world-name strong{font-size:11px;overflow-wrap:anywhere}#ff14BearBridgeStatus .ff14-bear-world-name small{font-size:9px;color:#9fb0c7}
      #ff14BearBridgeStatus .ff14-bear-world-state{font-size:10px;padding:3px 6px;border-radius:99px;background:#ffffff10;white-space:nowrap}
      #ff14BearBridgeStatus .ff14-bear-world-state[data-state="saved"]{color:#76ddb4;background:#1a6c4c35}#ff14BearBridgeStatus .ff14-bear-world-state[data-state="error"]{color:#ff9b9b;background:#8d292935}#ff14BearBridgeStatus .ff14-bear-world-state[data-state="requesting"],#ff14BearBridgeStatus .ff14-bear-world-state[data-state="validating"],#ff14BearBridgeStatus .ff14-bear-world-state[data-state="saving"]{color:#ffd27b}
      #ff14BearBridgeStatus .ff14-bear-world-error{grid-column:1/-1;color:#ff9b9b;font-size:10px;overflow-wrap:anywhere}
      #ff14BearBridgeStatus .ff14-bear-map-list{display:flex;flex-direction:column;gap:6px;max-height:230px;overflow:auto;margin-top:8px;padding-right:3px}
      #ff14BearBridgeStatus .ff14-bear-map-row{display:grid;grid-template-columns:minmax(110px,.8fr) minmax(150px,1.2fr);align-items:center;gap:8px;padding:6px 8px;border:1px solid #ffffff17;border-radius:9px;background:#ffffff07}
      #ff14BearBridgeStatus .ff14-bear-map-label{display:flex;flex-direction:column;gap:2px;min-width:0}#ff14BearBridgeStatus .ff14-bear-map-label strong{font-size:12px;overflow-wrap:anywhere}#ff14BearBridgeStatus .ff14-bear-map-label small{font-size:10px;color:#a9bad0}
      #ff14BearBridgeStatus input,#ff14BearBridgeStatus select{box-sizing:border-box;width:100%;min-width:0;border:1px solid #64748b80;border-radius:9px;background:#111d30;color:#f1f5fb;padding:8px;font:inherit}
      #ff14BearBridgeStatus .ff14-bear-map-list select{font-size:11px;padding:7px}#ff14BearBridgeStatus .ff14-bear-empty{color:#a9bad0;font-size:12px}
      #ff14BearBridgeStatus a{color:#8fc5ff;text-decoration:underline;text-underline-offset:2px}
      @media(max-width:520px){#ff14BearBridgeStatus .ff14-bear-dc-options{grid-template-columns:repeat(2,minmax(0,1fr))}#ff14BearBridgeStatus .ff14-bear-world-options{grid-template-columns:1fr}#ff14BearBridgeStatus .ff14-bear-worlds{grid-template-columns:1fr}#ff14BearBridgeStatus .ff14-bear-map-row{grid-template-columns:1fr}}
    `;
    document.head.appendChild(style);
    panel=document.createElement('div');panel.id='ff14BearBridgeStatus';
    panel.innerHTML=`
      <section class="ff14-bear-panel" aria-label="同步数据控制中心">
        <header class="ff14-bear-head"><span>同步数据</span><button type="button" data-action="close" aria-label="收起同步数据面板" title="收起">⌄</button></header>
        <div class="ff14-bear-body">
          <p class="ff14-bear-note">读取 Bear Tracker 公开 S 怪数据（Rank=5），不需要登录，不向上游写入。选择需要同步的大区后，首次同步会建立本地缓存；后续每 30 秒把本地缓存变化投影到监控室与计算器，远端请求仍按服务器 CD 窗口调度，不会每 30 秒重复爬站。</p>
          <div class="ff14-bear-status" data-role="connection">正在检查本机同步服务…</div>
          <section class="ff14-bear-section" style="margin-top:0;padding-top:0;border:0">
            <div class="ff14-bear-section-title"><span>选择数据中心</span><span class="ff14-bear-muted">可多选 · 默认陆行鸟</span></div>
            <div class="ff14-bear-dc-options" data-role="dc-options"></div>
            <div class="ff14-bear-world-options" data-role="world-options" aria-label="所选大区服务器"></div>
            <div class="ff14-bear-actions"><button type="button" class="ff14-bear-action" data-action="save-dcs">保存大区与服务器</button></div>
          </section>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>同步进度</span><span data-role="percent">0.0%</span></div>
            <div class="ff14-bear-progress-head"><strong data-role="phase">等待同步</strong><span data-role="queue">等待队列 0 个服务器</span></div>
            <div class="ff14-bear-progress-track" role="progressbar" aria-label="同步真实进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ff14-bear-progress-fill" data-role="progress"></div></div>
            <div class="ff14-bear-progress-hint" data-role="progress-hint">进度按已处理服务器请求计算；空结果不会冒充数据同步成功。</div>
            <div class="ff14-bear-actions">
              <button type="button" class="ff14-bear-action ff14-bear-primary" data-action="sync">立即同步所选大区</button>
              <button type="button" class="ff14-bear-action" data-action="pause">暂停同步</button>
              <button type="button" class="ff14-bear-action" data-action="resume">恢复同步</button>
            </div>
          </section>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>服务器同步明细</span><span class="ff14-bear-muted">按大区 / 世界展示</span></div>
            <div class="ff14-bear-worlds" data-role="world-list"><div class="ff14-bear-empty">保存大区后显示服务器状态。</div></div>
          </section>
          <p class="ff14-bear-message" data-role="message">首次使用建议：先选择大区（默认陆行鸟），系统会自动勾选该大区服务器；可取消单个服务器，再点击“保存大区与服务器”。也可打开 <a href="https://tracker.beartoolkit.com/timer" target="_blank" rel="noreferrer">Bear Tracker 公开计时页面</a> 对照服务器和击杀时间；此页面可公开访问，本工具不会要求填写 Bear 账号密码。</p>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>中文 S 怪名称映射</span><span class="ff14-bear-muted">首次核对一次</span></div>
            <p class="ff14-bear-note" data-role="mapping-count">等待读取 Rank=5 S 怪词库。</p>
            <input type="search" data-role="map-search" placeholder="搜索中文 S 怪名称 / 地区">
            <div class="ff14-bear-map-list" data-role="map-list"><p class="ff14-bear-empty">打开面板后载入 S 怪映射。</p></div>
            <div class="ff14-bear-actions"><button type="button" class="ff14-bear-action ff14-bear-primary" data-action="save-maps">保存名称映射并同步</button></div>
          </section>
          <p class="ff14-bear-note" style="margin-top:12px">同步方向：Bear Tracker → 工具箱。不会上传击杀或任何工具箱数据。只替换同一世界 / 同一 S 怪的旧 Bear 同步锚点；手动记录、天气前置、监控室手动 CD 校准均保留。</p>
        </div>
      </section>`;
    document.body.appendChild(panel);
    panelDetail=panel.querySelector('.ff14-bear-panel');dcOptions=panel.querySelector('[data-role="dc-options"]');worldOptions=panel.querySelector('[data-role="world-options"]');worldList=panel.querySelector('[data-role="world-list"]');
    populateDataCenterOptions();mapList=panel.querySelector('[data-role="map-list"]');mapSearch=panel.querySelector('[data-role="map-search"]');
    panel.querySelector('[data-action="close"]').addEventListener('click',()=>{window.FF14UnifiedUtilityDock?.close?.();});
    panel.querySelector('[data-action="sync"]').addEventListener('click',()=>startManualSync().catch(error=>setMessage(error.message,'error')));
    panel.querySelector('[data-action="pause"]').addEventListener('click',pauseSync);
    panel.querySelector('[data-action="resume"]').addEventListener('click',resumeSync);
    panel.querySelector('[data-action="save-dcs"]').addEventListener('click',()=>saveDataCenters().catch(error=>setMessage(error.message,'error')));
    panel.querySelector('[data-action="save-maps"]').addEventListener('click',()=>saveMappings().catch(error=>setMessage(error.message,'error')));
    mapSearch.addEventListener('input',renderMappings);
    updatePanelStatus();
  }

  function startStatusTimer(){
    stopStatusTimer();
    statusTimer = setInterval(() => {
      if (document.visibilityState === 'hidden' || panelDetail?.hidden) return;
      refreshHealth().then(() => { if (state.resourcesReady && !mappingLoaded && !panelDetail?.hidden) loadMappingData(); }).catch(() => {});
    }, 2500);
  }
  function stopStatusTimer(){ if (statusTimer) clearInterval(statusTimer); statusTimer = null; }

  async function start(){
    restoreState();
    // Load the toolbox's canonical S-rank dictionary before any automatic snapshot import.
    // If the dictionary is unavailable, reject unknown Bear names instead of importing English
    // HuntName values into the Chinese toolbox history.
    localMonsterList = getLocalMonsters();
    rebuildLatestRecordsIndex();
    mountCalculatorSnapshot();
    await refreshHealth({applySnapshot:true,forceSnapshot:true});
    // The Node service starts its remote scan after the local HTTP server is already available.
    // Keep a small async waiter during first initialization so a closed panel still imports the
    // first completed snapshot automatically; no remote request is made from the browser.
    if (state.serviceReady && (state.syncRunning || (!state.resourcesReady && state.syncStatus !== 'error'))) waitForSync();
    // Lightweight health polling catches later 15-minute background refreshes without SSE or
    // per-monster browser work. It never runs while this tab is hidden.
    setInterval(() => {
      if (document.visibilityState === 'hidden' || healthBusy || pullBusy) return;
      refreshHealth({applySnapshot:true,forceSnapshot:false}).catch(() => {});
    }, CONFIG.localRefreshMs);
  }
  window.addEventListener('ff14:kill-records-changed',()=>{rebuildLatestRecordsIndex();refreshCalculatorSnapshot();});

  function refreshLocalRecords(){
    rebuildLatestRecordsIndex();
    refreshCalculatorSnapshot();
    return latestRecordsIndex.size;
  }
  window.FF14BearBridge = Object.freeze({
    status: () => ({ ...state }),
    syncNow: startManualSync,
    refresh: refreshHealth,
    pull: pullSnapshot,
    refreshCalculator: refreshCalculatorSnapshot,
    refreshLocalRecords,
    latestRecordFor
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { createPanel(); start().catch(error => warn(error.message)); }, { once: true });
  } else {
    createPanel(); start().catch(error => warn(error.message));
  }
})();
