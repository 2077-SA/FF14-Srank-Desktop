'use strict';

const DATA_CENTERS = Object.freeze(['陆行鸟', '莫古力', '猫小胖', '豆豆柴']);

function normalizeSelectedDataCenters(values, { allowEmpty = false } = {}) {
  const selected = [...new Set((Array.isArray(values) ? values : [])
    .map(value => String(value || '').trim()).filter(value => DATA_CENTERS.includes(value)))];
  if (!allowEmpty && !selected.length) throw new Error('至少选择一个大区。');
  return selected;
}

function filterServersByDataCenters(serverNames, selectedDataCenters, worldGroups) {
  const selected = new Set(normalizeSelectedDataCenters(selectedDataCenters, { allowEmpty: true }));
  if (!selected.size) return [];
  const allowed = new Set();
  for (const dc of selected) {
    for (const world of Array.isArray(worldGroups?.[dc]) ? worldGroups[dc] : []) {
      allowed.add(String(world));
    }
  }
  return (Array.isArray(serverNames) ? serverNames : []).filter(name => allowed.has(String(name)));
}

function filterServerPreferenceMap(preferences, allowedServers) {
  const allowed = new Set(Array.isArray(allowedServers) ? allowedServers.map(String) : []);
  const source = preferences && typeof preferences === 'object' && !Array.isArray(preferences) ? preferences : {};
  const next = {};
  for (const [profile, names] of Object.entries(source)) {
    if (!Array.isArray(names)) continue;
    next[profile] = names.filter(name => allowed.has(String(name)));
  }
  return next;
}

function toggleDataCenter({ selectedDataCenters, dataCenter, checked, serverNames, worldGroups, visibleServers, limit }) {
  if (!DATA_CENTERS.includes(dataCenter)) throw new Error(`未知大区：${dataCenter}`);
  const before = normalizeSelectedDataCenters(selectedDataCenters, { allowEmpty: true });
  const set = new Set(before);
  if (checked) set.add(dataCenter);
  else set.delete(dataCenter);
  const nextDcs = DATA_CENTERS.filter(dc => set.has(dc));
  const allowedServers = filterServersByDataCenters(serverNames, nextDcs, worldGroups);
  const previous = Array.isArray(visibleServers) ? visibleServers : [];
  const addedWorlds = checked && !before.includes(dataCenter)
    ? (Array.isArray(worldGroups?.[dataCenter]) ? worldGroups[dataCenter] : []) : [];
  const preferred = [...addedWorlds, ...previous];
  const valid = allowedServers.filter(name => preferred.includes(name));
  const max = Math.max(1, Number(limit) || 8);
  const nextVisible = (valid.length ? valid : allowedServers).slice(0, max);
  return { changed: true, selectedDataCenters: nextDcs, allowedServers, visibleServers: nextVisible,
    removedServers: previous.filter(name => !allowedServers.includes(name)),
    truncated: allowedServers.length > nextVisible.length };
}

const api = { DATA_CENTERS, normalizeSelectedDataCenters, filterServersByDataCenters, filterServerPreferenceMap, toggleDataCenter };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.FF14MatrixDcSelection = api;
