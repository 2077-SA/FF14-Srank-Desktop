# v4.2.5 Bear 批量同步解析回归报告

## 根因对应

参考 `Laficia/MagicBucket` 仓库 `src/SrankFlag/SrankFlag/BearBulkClient.cs` 中 `Parse` 方法：批量计时字段读取 `huntName`、`worldName`、`lastDeathTime`，只在 `isMaint` 字段为 JSON `true` 时设为维护；字段缺省则按正常模式。v4.2.4 解析器在该字段缺省时返回 null 并拒绝每条记录。

## 新行为

- 缺省 `isMaint` -> `false` -> 使用目标 S 怪 `RespawnTimer`。
- 显式 `isMaint: true` -> 使用 `MaintTimer`。
- 显式 `false` -> 正常 `RespawnTimer`。
- 显式 null / unknown / 不支持值 -> 拒绝，不猜测。
- 原始响应有数据但解析通过数为 0 -> 大区状态 error，不当作成功；不清空已有缓存。
- 原始响应 `timers: []` -> 标记 empty / 接口无记录；不伪装成已取得 CD。

## 每世界统计

rawRecords：Bear 返回的原始条数；parsedRecords：字段、Rank、世界和时间校验通过数；distinctRecords：去重后的不同目标数；records：可信接受数；rejectedRecords：格式 / 词库 / 时间校验拒绝数；duplicateRecords：重复计时条目数；isolatedRecords：多路线冲突隔离数。

## 自动化测试

- 桌面端：26/26。
- 桥接端：36/36。
- 新增回归：缺省维护位正常解析；显式 null/unknown 拒绝；原始有值但解析全空必须报错；真空数组标记 empty；逐世界统计 raw / parsed / distinct / accepted / rejected / duplicate / isolated。

## 边界

使用公开 MagicBucket 源代码中的批量解析规则作为接口兼容依据和本地模拟响应进行验证；并未取得用户当前 Bear API 的实时原始响应，也未完成用户 Windows 端在线验证。首次 v4.2.5 在线运行的 raw/parsed 数量将用于确认此兼容修复是否完整覆盖实际响应。
