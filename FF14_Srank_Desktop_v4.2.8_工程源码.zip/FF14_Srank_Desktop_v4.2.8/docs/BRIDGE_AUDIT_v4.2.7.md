# v4.2.7 桥接与 CD 逻辑审计

## 1. UI 选择到扫描计划

同步数据面板的四大区按钮与服务器复选框由同一世界归属表驱动：勾选大区初始化该区全部世界，取消某世界只保留该区剩余选择；取消大区删除该区世界选择。服务端 `/settings/data-centers` 再运行 `validateDataCenters()` 与 `normalizeWorldSelections()`，拒绝未知大区、跨区世界和空服务器组。

`buildSyncPlan()` 统一生成分组。进度分母为所选世界数：豆豆柴全选是 5、莫古力全选是 8，而不是世界数 × Rank=5 S 怪定义数量。每个大区的主批量查询仍按接口一次请求该区全部选中世界。

监控室服务器总览使用相同 4 大区映射。设备显示上限（desktop 8 / tablet 4 / mobile 2）只影响可见列；取消大区会清理所有设备配置中的失效世界。全部大区关闭后不自动回到陆行鸟。

## 2. Bear 读取路径

### 匿名会话

- GET Bear Tracker 根页面建立匿名会话并取得临时 CSRF。
- CSRF / Cookie 仅在内存保存，桌面退出后丢弃。
- POST 时携带 CSRF、`/srank` Referer 和 JSON。

### 正式 S 怪批量接口

- Endpoint：`/api/lastDeathTimers`
- Body：`{ QueryDeathTimers: [world names], RankType: 'sRank' }`
- 只筛 `DatabaseHunt.Rank === 5`。
- 解析原始 `timers`，再按 hunt、world、lastDeathTime、maintenance 状态、资源时间窗与大区归属验证。

### 豆豆柴

- 首选公开 Live 快照，逐世界解析 S 怪数组数据。
- Live 无有效记录 / 结构错误时用 Bear 批量接口备用读取。
- 记录 Live 与批量各自 HTTP / payload / raw / parsed 诊断。

### 其他大区及单服备用

- 每个选中大区先进行一批世界请求。
- 缺失世界只按世界维度触发受限备用，不按 S 怪定义逐只扩大请求。
- 备用并发限速；429 触发全局冷却，停止继续请求。

## 3. 数据校验与 CD 窗口

- 只接受 Rank=5 S 怪；名称需映射到 S 词库。
- 世界只能归属于唯一一个大区；跨区写入拒绝。
- 击杀时间须为合理 Unix 秒 / ISO 时间，未来时间拒绝。
- 维护状态按 Bear 字段显式解析；正常模式使用 `RespawnTimer`，维护模式使用 `MaintTimer`。
- 词库时间窗过期、维护状态未知、时间窗非法或多路线冲突时不显示 CD、不回填计算器。
- 进闸 = killAnchor + minHours；强制 = killAnchor + maxHours。

## 4. 持久化与监控室

- 每个大区有独立状态 / 缓存 / 元数据 / 冲突隔离。
- `Store.applyTimers()` 仅在实质时间锚点、维护标志、窗口、资源版本、来源 / 可信级别改变时写入。
- 空响应、原始记录全部拒绝、HTTP 错误不会清空旧缓存，也不刷新最近成功时间。
- 成功同步快照会推送至本机 `/hunts?rank=s`，renderer 适配器以“大区 | 服务器 | 规范化 S 怪名”索引并更新共享记录；旧 / 新监控室和计算器读取同一可信窗口。

## 5. 状态数字语义

- completed / totalTargets：处理完的世界请求数 / 选中世界请求数。
- raw：接口原始行数。
- parsed：格式、世界、Rank 与时间字段解析通过数。
- accepted：冲突和 CD 验证后的可信记录数。
- inserted / updated：本次实际写入变化数。
- unchanged：与缓存实质字段一致的记录数。
- rejected / isolated：格式校验拒绝 / 多路线冲突隔离数。

100% 只代表所有请求目标已处理；0 条有效数据必须显示 empty / error / partial，不可以显示成同步成功。

## 6. 自动测试与限制

- Desktop：39/39。
- Bridge：56/56。
- 当前环境无法直连 Bear Tracker 实时 API，因此线上状态、实际响应 body 和当前每大区实时行数仍需在用户 Windows 环境验证。
- 测试使用可控模拟 HTTP 响应；通过不代表线上服务器一定返回非空数据。
