'use strict';

const SUPPORTED_DATA_CENTERS = Object.freeze(['豆豆柴', '陆行鸟', '莫古力', '猫小胖']);

function validateDataCenters(dataCenters, remoteDataCenters = null) {
  const next = [...new Set((Array.isArray(dataCenters) ? dataCenters : [])
    .map(value => String(value || '').trim()).filter(Boolean))];
  if (!next.length) throw Object.assign(new Error('至少选择一个数据中心。'), { status: 400 });
  const remoteNames = Object.keys(remoteDataCenters || {});
  const available = new Set(remoteNames.length ? remoteNames : SUPPORTED_DATA_CENTERS);
  const invalid = next.filter(value => !available.has(value));
  if (invalid.length) throw Object.assign(new Error(`未知数据中心：${invalid.join('、')}`), { status: 400 });
  return next;
}

module.exports = { SUPPORTED_DATA_CENTERS, validateDataCenters };
