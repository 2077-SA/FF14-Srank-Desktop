'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('unconfirmed default data-center selection is preserved without enabling automatic sync', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff14-config-test-'));
  const configPath = path.join(dir, 'bridge-config.json');
  fs.writeFileSync(configPath, JSON.stringify({
    watch: { dataCenters: ['陆行鸟'] },
    paths: { dataDir: path.join(dir, 'data') }
  }));
  const previous = process.env.BRIDGE_CONFIG;
  process.env.BRIDGE_CONFIG = configPath;
  const modulePath = require.resolve('../src/config');
  delete require.cache[modulePath];
  try {
    const config = require('../src/config');
    const loaded = config.load();
    assert.deepEqual(loaded.watch.dataCenters, ['陆行鸟']);
    assert.equal(loaded.watch.selectionConfirmed, false);
    assert.deepEqual(loaded.watch.worlds, []);
  } finally {
    delete require.cache[modulePath];
    if (previous === undefined) delete process.env.BRIDGE_CONFIG;
    else process.env.BRIDGE_CONFIG = previous;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});


test('data-center validation works before remote resources are ready and tightens after load', () => {
  const { validateDataCenters } = require('../src/data-centers');
  assert.deepEqual(validateDataCenters(['陆行鸟'], null), ['陆行鸟']);
  assert.deepEqual(validateDataCenters(['莫古力', '陆行鸟', '陆行鸟'], null), ['莫古力', '陆行鸟']);
  assert.throws(() => validateDataCenters(['不存在的大区'], null), error => error.status === 400);
  const remote = { '陆行鸟': { Names: ['红玉海'] } };
  assert.deepEqual(validateDataCenters(['陆行鸟'], remote), ['陆行鸟']);
  assert.throws(() => validateDataCenters(['莫古力'], remote), error => error.status === 400);
});
