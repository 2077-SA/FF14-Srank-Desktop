'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('embedded monitor payload remains valid JSON and contains the monitor document', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const match = source.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(match, 'embedded monitor payload script must exist');
  const payload = JSON.parse(match[1]);
  assert.equal(payload.version, '3.3.7');
  assert.ok(typeof payload.html === 'string' && payload.html.startsWith('<!DOCTYPE html>'));
  assert.ok(payload.html.includes('ff14-v330-command-center'), 'monitor enhancement CSS/JS must be retained');
  assert.ok(!payload.html.includes('FF14DesktopV412ReleaseNotice'), 'desktop update notice must not be injected into monitor payload');
});

test('desktop release notice is outside the embedded JSON payload', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const payloadClose = source.indexOf('</script>', source.indexOf('<script id="ff14TriggerMonitorEmbeddedPayload"'));
  const notice = source.indexOf('<script id="ff14-desktop-v412-release-notice">');
  assert.ok(payloadClose >= 0 && notice > payloadClose, 'release notice must be a separate host-page script');
});
