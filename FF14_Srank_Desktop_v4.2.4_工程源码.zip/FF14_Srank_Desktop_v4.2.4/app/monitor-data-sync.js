'use strict';

const normalizeName = value => String(value == null ? '' : value)
  .normalize('NFKC')
  .toLocaleLowerCase()
  .replace(/[\s\p{P}\p{S}]/gu, '');

function canonicalVersionKey(value, fallback = '版本6.0') {
  const raw = String(value == null ? '' : value).trim().replace(/^版本\s*/, '');
  return raw ? `版本${raw}` : fallback;
}

function manualOverrideWins(localOverride, incomingReceivedAt) {
  if (!localOverride || localOverride.found !== true) return false;
  const manualUpdatedAt = Number(localOverride.updatedAt) || 0;
  const syncReceivedAt = Number(incomingReceivedAt) || 0;
  // Legacy numeric overrides have no edit timestamp. A newly received upstream
  // anchor is allowed to replace them; explicit edits made after that sync remain.
  if (!syncReceivedAt) return true;
  return manualUpdatedAt >= syncReceivedAt && manualUpdatedAt > 0;
}

function mergeDuplicateMonsterRows(rows) {
  const byName = new Map();
  const stateScore = row => {
    let score = 0;
    if (Number(row?.killTs) > 0) score += 16;
    if (Number(row?.triggerTs) > 0) score += 8;
    if (Number(row?.forceTs) > 0) score += 4;
    if (Number(row?.homeLatestKillTs) > 0) score += 2;
    if (row?.homeSyncSource && row.homeSyncSource !== '监控室预设') score += 1;
    return score;
  };
  for (const row of Array.isArray(rows) ? rows : []) {
    if (!row || !row.name) continue;
    const key = normalizeName(row.name);
    if (!key) continue;
    const existing = byName.get(key);
    if (!existing) {
      byName.set(key, row);
      continue;
    }
    const oldKill = Number(existing.killTs) || 0;
    const nextKill = Number(row.killTs) || 0;
    const latest = nextKill > oldKill || (nextKill === oldKill && stateScore(row) > stateScore(existing)) ? row : existing;
    const secondary = latest === row ? existing : row;
    const merged = { ...secondary, ...latest };
    // Keep the newest known kill anchor and retain useful fields from the
    // duplicate row if the winning row is only partially populated.
    for (const field of ['killTs', 'triggerTs', 'forceTs', 'homeSyncSource', 'minH', 'maxH']) {
      if (merged[field] == null && secondary[field] != null) merged[field] = secondary[field];
    }
    const existingHomeKill = Number(existing.homeLatestKillTs) || 0;
    const nextHomeKill = Number(row.homeLatestKillTs) || 0;
    const homeSource = nextHomeKill > existingHomeKill ? row : existing;
    if (Math.max(existingHomeKill, nextHomeKill) > 0) {
      merged.homeLatestKillTs = Math.max(existingHomeKill, nextHomeKill);
      merged.homeLatestKillSource = homeSource.homeLatestKillSource || '';
      merged.homeLatestKillReceivedAt = Number(homeSource.homeLatestKillReceivedAt) || 0;
    }
    if (!merged.area && (existing.area || row.area)) merged.area = existing.area || row.area;
    if (!merged.aliases && (existing.aliases || row.aliases)) merged.aliases = existing.aliases || row.aliases;
    byName.set(key, merged);
  }
  return [...byName.values()];
}

const api = Object.freeze({ normalizeName, canonicalVersionKey, manualOverrideWins, mergeDuplicateMonsterRows });
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.FF14MonitorDataSync = api;
