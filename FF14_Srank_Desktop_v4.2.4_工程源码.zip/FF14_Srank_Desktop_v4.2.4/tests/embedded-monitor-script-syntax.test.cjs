'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

test('every embedded monitor inline script parses before it is sent to Chromium', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const match = source.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(match, 'embedded monitor JSON payload must exist');
  const payload = JSON.parse(match[1]);
  const scriptPattern = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
  let inlineCount = 0;
  let scriptMatch;
  while ((scriptMatch = scriptPattern.exec(payload.html))) {
    if (/\bsrc\s*=/.test(scriptMatch[1])) continue;
    inlineCount++;
    assert.doesNotThrow(() => new vm.Script(scriptMatch[2], { filename: `embedded-monitor-inline-${inlineCount}.js` }), `inline script ${inlineCount} must parse`);
  }
  assert.ok(inlineCount >= 30, `expected full embedded monitor document, parsed ${inlineCount} scripts`);
});
