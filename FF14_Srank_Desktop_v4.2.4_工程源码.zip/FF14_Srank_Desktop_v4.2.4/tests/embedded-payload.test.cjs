'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('embedded monitor payload remains valid JSON and contains the monitor document', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const match = source.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(match, 'embedded monitor payload script must exist');
  const payload = JSON.parse(match[1]);
  assert.equal(payload.version, '3.3.10');
  assert.ok(typeof payload.html === 'string' && payload.html.startsWith('<!DOCTYPE html>'));
  assert.ok(payload.html.includes('ff14-v330-command-center'), 'monitor enhancement CSS/JS must be retained');
  assert.ok(payload.html.includes('ff14-v423-monitor-data-sync'), 'monitor sync merge repair must be embedded');
  const helper = fs.readFileSync(path.join(__dirname, '..', 'app', 'monitor-data-sync.js'), 'utf8').trim();
  const embeddedHelper = payload.html.match(/<script id="ff14-v423-monitor-data-sync">([\s\S]*?)<\/script>/);
  assert.ok(embeddedHelper && embeddedHelper[1].trim() === helper, 'embedded monitor helper must match the tested source helper');
  assert.match(payload.html,/if\(topologyChanged\|\|monitorDataChanged\)\s*\{[\s\S]*?persistMonitorKillTimes\(\)/,'monitor timing changes must persist, not only topology changes');
  assert.ok(!payload.html.includes('FF14DesktopV420ReleaseNotice'), 'desktop update notice must not be injected into monitor payload');
});

test('desktop release notice is outside the embedded JSON payload', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const payloadClose = source.indexOf('</script>', source.indexOf('<script id="ff14TriggerMonitorEmbeddedPayload"'));
  const notice = source.indexOf('<script id="ff14-desktop-v421-release-notice">');
  assert.ok(payloadClose >= 0 && notice > payloadClose, 'release notice must be a separate host-page script');
});


test('desktop data center dictionary contains all four regions and every child world', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  const match = source.match(/const SERVER_GROUPS = (\{[\s\S]*?\n        \});/);
  assert.ok(match, 'four-region server dictionary must exist');
  const groups = JSON.parse(match[1]);
  assert.deepEqual(Object.keys(groups), ['豆豆柴', '陆行鸟', '莫古力', '猫小胖']);
  assert.equal(groups['豆豆柴'].length, 5);
  assert.equal(groups['陆行鸟'].length, 8);
  assert.equal(groups['莫古力'].length, 8);
  assert.equal(groups['猫小胖'].length, 7);
});

test('v4.2 sync UI defaults to 8788, updates local snapshot every 30 seconds and labels the dock simply', () => {
  const adapter = fs.readFileSync(path.join(__dirname, '..', 'bridge', 'toolbox-adapter.js'), 'utf8');
  const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'index.html'), 'utf8');
  assert.match(adapter, /baseUrl: 'http:\/\/127\.0\.0\.1:8788'/);
  assert.match(adapter, /localRefreshMs: 30000/);
  assert.match(adapter, /refreshLocalRecords/);
  assert.match(html, /setInterval\(\(\)=>\{if\(dirty\)saveNow\(false,false\);\},15000\)/);
  assert.match(html, />同步数据<\/button>/);
  assert.match(html, /data-v3-subnav-toggle aria-expanded="false"/);
});
