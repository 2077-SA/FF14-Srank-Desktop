'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const sync=require('../app/monitor-data-sync.js');

test('monster names normalize whitespace, punctuation and full-width variants',()=>{
 assert.equal(sync.normalizeName('先驱勇士 阿提卡斯'),sync.normalizeName('先驱勇士阿提卡斯'));
 assert.equal(sync.normalizeName(' 先驱勇士　阿提卡斯！ '),sync.normalizeName('先驱勇士阿提卡斯'));
});

test('legacy and canonical expansion buckets use one version key',()=>{
 assert.equal(sync.canonicalVersionKey('版本 7.0'),'版本7.0');
 assert.equal(sync.canonicalVersionKey('7.0'),'版本7.0');
});

test('new sync data supersedes an old timestamp-less override but later manual edits win',()=>{
 assert.equal(sync.manualOverrideWins({found:true,value:123,updatedAt:0},Date.now()),false);
 const received=Date.now();
 assert.equal(sync.manualOverrideWins({found:true,value:123,updatedAt:received+5},received),true);
 assert.equal(sync.manualOverrideWins({found:true,value:123,updatedAt:received-5},received),false);
});

test('duplicate rows merge within a server/version bucket and preserve the row with a real kill anchor',()=>{
 const merged=sync.mergeDuplicateMonsterRows([
  {name:'先驱勇士 阿提卡斯',killTs:null,triggerTs:null,forceTs:null,homeSyncSource:'监控室预设',minH:84,maxH:132},
  {name:'先驱勇士阿提卡斯',killTs:1763000000,triggerTs:1763302400,forceTs:1763475200,homeSyncSource:'Bear Tracker 同步数据',minH:84,maxH:132}
 ]);
 assert.equal(merged.length,1);
 assert.equal(merged[0].killTs,1763000000);
 assert.equal(merged[0].homeSyncSource,'Bear Tracker 同步数据');
});
