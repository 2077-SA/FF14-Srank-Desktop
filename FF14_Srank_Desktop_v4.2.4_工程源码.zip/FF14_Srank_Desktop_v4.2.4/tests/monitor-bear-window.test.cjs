'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');

test('Bear timer metadata is passed end-to-end from the bridge adapter into monitor bindings', () => {
  const adapter = fs.readFileSync(path.join(root, 'app', 'bear-sync-adapter.js'), 'utf8');
  const host = fs.readFileSync(path.join(root, 'app', 'index.html'), 'utf8');
  assert.match(adapter, /function readBearTimerWindow\(record,\s*killTs\)/);
  for (const key of ['bearCdHours','bearWindowHours','bearMaxHours','bearMaint','bearWindowStartTs','bearWindowEndTs','bearTimerSource','bearTrustLevel']) {
    assert.ok(adapter.includes(`${key}:`), `adapter must carry ${key}`);
    assert.ok(host.includes(`${key}:`), `host payload must carry ${key}`);
  }
  const match = host.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  const html = JSON.parse(match[1]).html;
  assert.match(html, /bearTimerWins/);
  assert.match(html, /setMonitorTimesFromKill\(monster,homeKill\.timeMs,effectiveCdHours,effectiveLtHours,homeKill\.source,bearTimerWins\?homeKill:null\)/);
  assert.match(html, /Math\.abs\(startTs-\(anchorSec\+bearCdHours\*3600\)\)<=1/);
  assert.match(html, /Math\.abs\(endTs-\(anchorSec\+bearMaxHours\*3600\)\)<=1/);
});


test('calculator snapshot uses the same validated Bear per-hunt CD window as the monitor room', () => {
  const adapter = fs.readFileSync(path.join(root, 'app', 'bear-sync-adapter.js'), 'utf8');
  assert.ok(adapter.includes("const bearClaimed=(syncedRow.syncSource==='bear-tracker-anonymous'||!!syncedRow.bearTimerSource)"));
  assert.match(adapter, /const cdHours=bearWindowValid\?bearCdHours:calculatorCooldownHours\(\)/);
  assert.match(adapter, /const lifeHours=bearWindowValid\?bearWindowHours:calculatorLifeHours\(\)/);
  assert.match(adapter, /Math\.abs\(bearStartTs-\(anchorSec\+bearCdHours\*3600\)\)<=1/);
  assert.match(adapter, /Math\.abs\(bearEndTs-\(anchorSec\+bearMaxHours\*3600\)\)<=1/);
  const calculator = adapter.slice(adapter.indexOf('function refreshCalculatorSnapshot'), adapter.indexOf('function mountCalculatorSnapshot'));
  assert.match(calculator, /预计进闸：\$\{gate\.toLocaleString\(\)\} · 预计强制：\$\{force\.toLocaleString\(\)\} · CD \$\{cdHours\}h/);
});


test('same kill anchor still applies a changed Bear maintenance/normal CD window without duplicating history', () => {
  const adapter = fs.readFileSync(path.join(root, 'app', 'bear-sync-adapter.js'), 'utf8');
  assert.match(adapter, /if \(latestKillMs === killMs\)/);
  assert.match(adapter, /const metadataChanged = Number\(existing\.bearCdHours\)/);
  assert.match(adapter, /existing\.bearMaint = bearWindow\.maint/);
  assert.match(adapter, /existing\.bearSyncedAt = Date\.now\(\)/);
  assert.match(adapter, /exactLocalUpdates/);
  const host = fs.readFileSync(path.join(root, 'app', 'index.html'), 'utf8');
  assert.match(host, /bearSyncedAt:Number\(r\.bearSyncedAt\)\|\|0/);
  const match = host.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  const html = JSON.parse(match[1]).html;
  assert.match(html, /row\.bearTimerSource==='bear-resource-definition'/);
});


test('unverified Bear CD metadata is rejected instead of falling back to generic defaults', () => {
  const adapter = fs.readFileSync(path.join(root, 'app', 'bear-sync-adapter.js'), 'utf8');
  assert.match(adapter, /const bearClaimed=\(syncedRow\.syncSource==='bear-tracker-anonymous'\|\|!!syncedRow\.bearTimerSource\)/);
  assert.match(adapter, /if\(bearClaimed&&!bearWindowValid\)/);
  assert.match(adapter, /CD 未核验 · 暂停计算/);
  assert.match(adapter, /if\(button\)button\.disabled=true/);
  assert.match(adapter, /box\.dataset\.timeMs=''/);
  assert.match(adapter, /acceptedTrustLevels=new Set\(\['corroborated','validated-single-source','supplemental-single-source'\]\)/);
  assert.match(adapter, /typeof record\.maint!=='boolean'/, 'monitor adapter must reject a missing maintenance state');
  assert.match(adapter, /MAX_BEAR_TIMER_RESOURCE_AGE_MS/, 'timer resource definitions must have a bounded freshness window');
  assert.match(adapter, /typeof syncedRow\.bearMaint==='boolean'/, 'calculator must reject a record without explicit maintenance state');
  const host = fs.readFileSync(path.join(root, 'app', 'index.html'), 'utf8');
  const match = host.match(/<script id="ff14TriggerMonitorEmbeddedPayload" type="application\/json">([\s\S]*?)<\/script>/);
  const html = JSON.parse(match[1]).html;
  assert.match(html, /\['corroborated','validated-single-source','supplemental-single-source'\]\.includes\(trustLevel\)/);
  assert.match(html, /resourceFresh&&row\.bearMaintKnown===true&&typeof row\.bearMaint==='boolean'/);
  assert.match(html, /homeCdUnverified=true/);
  assert.match(html, /CD 未核验/);
  assert.match(html, /bearMaxHours<=500/);
  assert.match(adapter, /killMs<=now/);
  assert.ok(host.includes('bearTimerResourcesFetchedAt:String(r.bearTimerResourcesFetchedAt||'));
});
