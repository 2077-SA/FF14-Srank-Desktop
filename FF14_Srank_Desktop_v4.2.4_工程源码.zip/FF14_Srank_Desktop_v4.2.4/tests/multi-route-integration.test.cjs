'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');

test('bridge uses bounded multi-DC workers and targeted Bear verification', () => {
  const source = fs.readFileSync(path.join(root, 'bridge/src/index.js'), 'utf8');
  assert.match(source, /const DC_CONCURRENCY = 2/);
  assert.match(source, /rest\.lastDeathTimers\(group\.worlds, 'sRank'\)/);
  assert.match(source, /rest\.huntInfo\(row\.huntName, row\.worldName\)/);
  assert.match(source, /TARGET_VERIFY_LIMIT_PER_DC = 5/);
  assert.match(source, /appendQuarantine\(dataCenter/);
});

test('sync control center exposes parallel DC and route trust counters', () => {
  const adapter = fs.readFileSync(path.join(root, 'app/bear-sync-adapter.js'), 'utf8');
  assert.match(adapter, /当前并行读取/);
  assert.match(adapter, /交叉确认/);
  assert.match(adapter, /单源校验/);
  assert.match(adapter, /冲突隔离/);
});
