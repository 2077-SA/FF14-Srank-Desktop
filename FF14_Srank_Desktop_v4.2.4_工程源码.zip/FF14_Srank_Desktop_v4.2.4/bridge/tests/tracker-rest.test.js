'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { TrackerRest } = require('../src/tracker-rest');

function makeRest() {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff14-rest-test-'));
  const rest = new TrackerRest({
    tracker: { restBase: 'https://tracker.example.test', origin: 'https://tracker.example.test' },
    auth: { csrfToken: 'test-csrf', cookie: 'sessionid=test-session' },
    dataDir
  }, () => {});
  return { rest, cleanup: () => fs.rmSync(dataDir, { recursive: true, force: true }) };
}

const jsonResponse = (status, value = {}) => new Response(JSON.stringify(value), {
  status, headers: { 'content-type': 'application/json' }
});

test('safe Bear read retries a transient network failure and then succeeds', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; if (calls === 1) throw new TypeError('temporary network error'); return jsonResponse(200, { ok: true }); };
  try {
    const result = await rest.post('/api/lastDeathTimers', {});
    assert.equal(result.status, 200);
    assert.equal(calls, 2);
  } finally { global.fetch = original; cleanup(); }
});

test('safe Bear read retries 503 but does not retry 429', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; return calls === 1 ? jsonResponse(503, {}) : jsonResponse(200, { ok: true }); };
  try {
    const recovered = await rest.post('/api/huntInfo', {});
    assert.equal(recovered.status, 200);
    assert.equal(calls, 2);
    calls = 0;
    global.fetch = async () => { calls++; return jsonResponse(429, { retryAfter: 60 }); };
    const limited = await rest.post('/api/lastDeathTimers', {});
    assert.equal(limited.status, 429);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});

test('write-like Bear endpoints are never retried after network failure', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; throw new TypeError('temporary network error'); };
  try {
    await assert.rejects(rest.post('/api/deathReport', {}), /temporary network error/);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});


test('write-like Bear endpoints do not resend after 403/419 CSRF responses', async () => {
  const { rest, cleanup } = makeRest();
  const original = global.fetch;
  let calls = 0;
  global.fetch = async () => { calls++; return jsonResponse(403, { error: 'forbidden' }); };
  try {
    const result = await rest.post('/api/deathReport', {});
    assert.equal(result.status, 403);
    assert.equal(calls, 1);
  } finally { global.fetch = original; cleanup(); }
});
