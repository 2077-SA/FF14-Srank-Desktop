'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { normalizeEvent, normalizeTimer, normalizeBulkTimer, normalizeMainSiteLive, computeRecordWindow } = require('../src/normalize');
const { Store } = require('../src/store');
const { LocalServer } = require('../src/server');

const resources = {
  DatabaseHunt: {
    'S Test Hunt': { Rank: 5, Region: 'Central Shroud', Patch: 'ARR', RespawnTimer: [84, 132], MaintTimer: [50, 80] },
    'A Test Hunt': { Rank: 1, Region: 'La Noscea', Patch: 'ARR', RespawnTimer: [4, 6], MaintTimer: [4, 8] }
  },
  DataCenters: { '陆行鸟': { Names: ['红玉海', '神意之地'] } }
};


test('computeRecordWindow never infers normal mode from a missing maintenance flag', () => {
  const definition = resources.DatabaseHunt['S Test Hunt'];
  const base = 1700000000;
  assert.equal(computeRecordWindow({ lastDeathTime: base }, definition), null);
  assert.equal(computeRecordWindow({ lastDeathTime: base, maint: null }, definition), null);
  const normal = computeRecordWindow({ lastDeathTime: base, maint: false }, definition);
  assert.equal(normal.minHours, 84);
  assert.equal(normal.maxHours, 132);
  const maintenance = computeRecordWindow({ lastDeathTime: base, maint: true }, definition);
  assert.equal(maintenance.minHours, 50);
  assert.equal(maintenance.maxHours, 80);
  const corruptedDefinition = { RespawnTimer: [84, 9999], MaintTimer: [50, 80] };
  assert.equal(computeRecordWindow({ lastDeathTime: base, maint: false }, corruptedDefinition), null, 'implausibly large resource windows must fail closed');
});

test('normalizeEvent maps Rank=5 to S and normalizes unix seconds', () => {
  const event = normalizeEvent('DeathReport', {
    Hunt: 'S Test Hunt', World: '红玉海', Time: 1700000000,
    LastMarkTime: 1700000000, MaintState: false
  }, resources);
  assert.equal(event.type, 'death');
  assert.equal(event.rank, 's');
  assert.equal(event.time, 1700000000);
  assert.equal(event.window.minHours, 84);
  assert.equal(event.window.maxHours, 132);
  const unknownMaintEvent = normalizeEvent('DeathReport', {
    Hunt: 'S Test Hunt', World: '红玉海', Time: 1700000000, LastMarkTime: 1700000000
  }, resources);
  assert.equal(unknownMaintEvent.maint, null);
  assert.equal(unknownMaintEvent.window, null, 'missing maintenance flag must not assume the normal window');
});

test('normalizeTimer derives window using MaintTimer when maintenance is active', () => {
  const timer = normalizeTimer({
    huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000,
    lastMarkTime: 1700000000, isMaint: true
  }, resources);
  assert.equal(timer.rank, 's');
  assert.equal(timer.window.minHours, 50);
  assert.equal(timer.window.maxHours, 80);
  const unknownMaintTimer = normalizeTimer({
    huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000, lastMarkTime: 1700000000
  }, resources);
  assert.equal(unknownMaintTimer.maint, null);
  assert.equal(unknownMaintTimer.window, null, 'missing maintenance flag must not assume normal timing');
});

test('normalizeBulkTimer accepts only valid Rank=5 timers for selected worlds', () => {
  const allowed = new Set(['红玉海']);
  const good = normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000, isMaint: true }, resources, allowed);
  assert.equal(good.rank, 's');
  assert.equal(good.lastDeathTime, 1700000000);
  assert.equal(good.maint, true);
  assert.equal(good.window.minHours, 50);
  assert.equal(normalizeBulkTimer({ huntName: 'A Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000 }, resources, allowed), null);
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '神意之地', lastDeathTime: 1700000000 }, resources, allowed), null);
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 0 }, resources, allowed), null);
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: Math.floor(Date.now()/1000)+30*86400 }, resources, allowed), null);
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: Math.floor(Date.now()/1000)+10*60, isMaint: false }, resources, allowed), null);
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000 }, resources, allowed), null, 'missing maintenance state must not default to normal CD');
  assert.equal(normalizeBulkTimer({ huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000, isMaint: 'unknown' }, resources, allowed), null, 'unrecognized maintenance state must be rejected');
});

test('normalizeMainSiteLive parses 豆豆柴 tuples and rejects non-S or unselected worlds', () => {
  const rows = normalizeMainSiteLive({ live: {
    '红玉海': { 'S Test Hunt': [['public line', 1700000000, true]], 'A Test Hunt': [['line', 1700000001, false]] },
    '神意之地': { 'S Test Hunt': [['line', 1700000002, false]] },
    '未知服务器': { 'S Test Hunt': [['line', 1700000003, false]] }
  } }, resources, new Set(['红玉海']));
  assert.equal(rows.length, 1);
  assert.equal(rows[0].lastDeathTime, 1700000000);
  assert.equal(rows[0].maint, true);
  const unknownMaint = normalizeMainSiteLive({ live: { '红玉海': { 'S Test Hunt': [['line', 1700000000]] } } }, resources, new Set(['红玉海']));
  assert.equal(unknownMaint.length, 0, 'missing maintenance bit must not be treated as normal CD');
  const conflictingMaint = normalizeMainSiteLive({ live: { '红玉海': { 'S Test Hunt': [['line A', 1700000000, true], ['line B', 1700000000, false]] } } }, resources, new Set(['红玉海']));
  assert.equal(conflictingMaint.length, 0, 'same timestamp with conflicting maintenance flags is ambiguous');
});

test('Store does not let an older timer overwrite newer state', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-test-'));
  const store = new Store({ dataDir: dir });
  const keyOf = (world, hunt) => `${world}|${hunt}`;
  store.applyTimers([{ worldName: '红玉海', huntName: 'S Test Hunt', lastDeathTime: 200, rank: 's' }], keyOf);
  store.applyTimers([{ worldName: '红玉海', huntName: 'S Test Hunt', lastDeathTime: 100, rank: 's' }], keyOf);
  assert.equal(store.loadDataCenterState('陆行鸟').hunts['红玉海|S Test Hunt'].lastDeathTime, 200);
  assert.equal(store.loadState().hunts['陆行鸟|红玉海|S Test Hunt'].lastDeathTime, 200);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('Local API maps configured hunt aliases and rejects unmapped Chinese names', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-http-'));
  const calls = [];
  const cfg = {
    dataDir: dir,
    aliases: { '伊休妲': 'S Test Hunt' },
    sync: { allowUpstreamReports: true, queueTransientFailures: true, maxOutboxAttempts: 3 },
    local: { host: '127.0.0.1', port: 0, allowedOrigins: ['null'], webhookUrl: '' }
  };
  const store = new Store(cfg);
  const socket = { connected: false, rooms: ['陆行鸟'], setRooms() {} };
  const rest = { async reportDeath(payload) { calls.push(payload); return { status: 200, json: { ok: true } }; } };
  const server = new LocalServer({ cfg, rest, store, socket, log() {}, getStatus: () => ({ authenticated: true }) }).start();
  t.after(() => { server.stop(); fs.rmSync(dir, { recursive: true, force: true }); });
  await new Promise(resolve => server.server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.server.address().port}`;
  const health = await fetch(`${base}/health`).then(r => r.json());
  assert.equal(health.ok, true);
  assert.equal(health.authenticated, true);

  const good = await fetch(`${base}/report/death`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ huntName: '伊休妲', worldName: '红玉海', reportTime: 1700000000 })
  });
  assert.equal(good.status, 200);
  assert.equal(calls[0].huntName, 'S Test Hunt');

  const missing = await fetch(`${base}/report/death`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ huntName: '未配置的怪物', worldName: '红玉海', reportTime: 1700000000 })
  });
  assert.equal(missing.status, 400);
  assert.equal(calls.length, 1);
});


test('normalizeEvent uses explicit LastDeath for SRankFATEUpdate', () => {
  const event = normalizeEvent('SRankFATEUpdate', {
    Hunt: 'S Test Hunt', World: '红玉海', LastSeen: 1700000100, LastDeath: 1700000000
  }, resources);
  assert.equal(event.type, 'srank_fate');
  assert.equal(event.rank, 's');
  assert.equal(event.lastDeath, 1700000000);
  assert.equal(event.time, 1700000000);
});

test('toolbox local login endpoint forwards credentials only to the in-memory handler', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-login-'));
  let received = null;
  const cfg = {
    dataDir: dir, aliases: {}, sync: { allowUpstreamReports: true, queueTransientFailures: true, maxOutboxAttempts: 3 },
    local: { host: '127.0.0.1', port: 0, allowedOrigins: ['null'], webhookUrl: '' }
  };
  const store = new Store(cfg);
  const socket = { connected: false, rooms: [], setRooms() {} };
  const rest = {};
  const server = new LocalServer({
    cfg, rest, store, socket, log() {},
    authenticate: async credentials => {
      received = credentials;
      return { username: credentials.username, authenticated: true, permissions: ['hunt-report'] };
    },
    getStatus: () => ({ authenticated: !!received, username: received?.username || null })
  }).start();
  t.after(() => { server.stop(); fs.rmSync(dir, { recursive: true, force: true }); });
  await new Promise(resolve => server.server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.server.address().port}`;
  const response = await fetch(`${base}/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'demo-user', password: 'demo-password' })
  });
  assert.equal(response.status, 200);
  assert.equal(received.username, 'demo-user');
  assert.equal(received.password, 'demo-password');
  const body = await response.json();
  assert.equal(body.authenticated, true);
  assert.deepEqual(body.permissions, ['hunt-report']);
});

test('normalizeHuntInfo reads an anonymous previousDeath timestamp for Rank=5 S monsters', () => {
  const { normalizeHuntInfo } = require('../src/normalize');
  const normalized = normalizeHuntInfo('S Test Hunt', '红玉海', {
    previousDeath: { ReportTime: 1700000000000, Missing: 0 },
    previousState: 'dead',
    count: 12
  }, resources.DatabaseHunt['S Test Hunt'], { maint: false });
  assert.equal(normalized.rank, 's');
  assert.equal(normalized.lastDeathTime, 1700000000);
  assert.equal(normalized.count, 12);
});

test('normalizeHuntInfo rejects unknown maintenance state instead of assuming normal CD', () => {
  const { normalizeHuntInfo } = require('../src/normalize');
  const response = { previousDeath: { ReportTime: 1700000000000 }, previousState: 'dead', count: 12 };
  assert.equal(normalizeHuntInfo('S Test Hunt', '红玉海', response, resources.DatabaseHunt['S Test Hunt']), null);
  assert.equal(normalizeHuntInfo('S Test Hunt', '红玉海', response, resources.DatabaseHunt['S Test Hunt'], { maint: 'not-known' }), null);
  const validated = normalizeHuntInfo('S Test Hunt', '红玉海', response, resources.DatabaseHunt['S Test Hunt'], { maint: true });
  assert.equal(validated.window.minHours, 50);
  assert.equal(validated.window.maxHours, 80);
  const rootMaint = normalizeHuntInfo('S Test Hunt', '红玉海', { ...response, isMaint: false }, resources.DatabaseHunt['S Test Hunt']);
  assert.equal(rootMaint.window.minHours, 84);
  assert.equal(rootMaint.window.maxHours, 132);
});

test('normalizeHuntInfo does not mistake previousState or count for a kill timestamp', () => {
  const { normalizeHuntInfo } = require('../src/normalize');
  const normalized = normalizeHuntInfo('S Test Hunt', '红玉海', {
    previousDeath: null,
    previousState: { state: 'alive', id: 1700000000 },
    count: 1700000000
  }, resources.DatabaseHunt['S Test Hunt']);
  assert.equal(normalized, null);
});

test('normalizeHuntInfo rejects A-rank rows even if they contain a timestamp', () => {
  const { normalizeHuntInfo } = require('../src/normalize');
  const normalized = normalizeHuntInfo('A Test Hunt', '红玉海', {
    previousDeath: 1700000000, previousState: 'dead', count: 3
  }, resources.DatabaseHunt['A Test Hunt']);
  assert.equal(normalized, null);
});

test('anonymous S-only bridge exposes only Rank=s cache and rejects upstream write routes', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-anon-'));
  const cfg = {
    dataDir: dir,
    aliases: {},
    sync: { allowUpstreamReports: false, queueTransientFailures: false, maxOutboxAttempts: 0 },
    local: { host: '127.0.0.1', port: 0, allowedOrigins: ['null'], webhookUrl: '' }
  };
  const store = new Store(cfg);
  store.applyTimers([
    { huntName: 'S Test Hunt', worldName: '红玉海', rank: 's', lastDeathTime: 1700000000 },
    { huntName: 'A Test Hunt', worldName: '红玉海', rank: 'a', lastDeathTime: 1700000100 }
  ], (world, hunt) => `${world}|${hunt}`);
  const server = new LocalServer({
    cfg, rest: {}, store, socket: null, log() {},
    getStatus: () => ({ mode: 'anonymous-srank', authenticated: false, resourcesReady: true, sync: { status: 'completed' } })
  }).start();
  t.after(() => { server.stop(); fs.rmSync(dir, { recursive: true, force: true }); });
  await new Promise(resolve => server.server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.server.address().port}`;
  const onlyS = await fetch(`${base}/hunts?rank=s`).then(response => response.json());
  assert.equal(onlyS.count, 1);
  assert.equal(onlyS.hunts[0].rank, 's');

  let manualSyncRaised = false;
  server.once('manualSync', () => { manualSyncRaised = true; });
  const syncResponse = await fetch(`${base}/sync/now`, { method: 'POST' });
  assert.equal(syncResponse.status, 202);
  assert.equal(manualSyncRaised, true);

  const writeResponse = await fetch(`${base}/report/death`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ huntName: 'S Test Hunt', worldName: '红玉海' })
  });
  assert.equal(writeResponse.status, 401);
});

test('resource filter discards A/B/B+ and FATE; only Rank=5 S definitions remain and restores missing DC metadata', () => {
  const { filterSRankResources } = require('../src/resources');
  const filtered = filterSRankResources({
    DatabaseHunt: {
      'S Test Hunt': { Rank: 5 },
      'A Test Hunt': { Rank: 1 },
      'B Test Hunt': { Rank: 2 },
      'B+ Test Hunt': { Rank: 3 }
    },
    DatabaseFate: { 'FATE Test': {} },
    SpawnPoint: { 'S Test Hunt': {} },
    DataCenters: { '陆行鸟': { Names: ['红玉海'] } }
  });
  assert.deepEqual(Object.keys(filtered.DatabaseHunt), ['S Test Hunt']);
  assert.deepEqual(Object.keys(filtered), ['DatabaseHunt', 'DataCenters']);
  assert.deepEqual(filtered.DataCenters['猫小胖'].Names, ['紫水栈桥', '延夏', '静语庄园', '摩杜纳', '海猫茶屋', '柔风海湾', '琥珀原']);
  assert.equal(filtered.DataCenters['陆行鸟'].Names.length, 8, 'partial upstream list is supplemented by built-in worlds');
  const expanded = filterSRankResources({ DatabaseHunt: { 'S Test Hunt': { Rank: 5 } }, DataCenters: { '豆豆柴': { Names: ['水晶塔', '新开放世界'] } } });
  assert.equal(expanded.DataCenters['豆豆柴'].Names.at(-1), '新开放世界', 'unknown new upstream worlds are retained');
});


test('Store caches the parsed state in memory and refreshes the cache after writes', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-state-cache-'));
  const store = new Store({ dataDir: dir });
  const first = store.loadDataCenterState('陆行鸟');
  const second = store.loadDataCenterState('陆行鸟');
  assert.strictEqual(first, second, 'repeated reads of the same DC should reuse one parsed snapshot');
  store.applyTimers([{ huntName: 'S Test Hunt', worldName: '红玉海', rank: 's', lastDeathTime: 1700000000 }], (world, hunt) => `${world}|${hunt}`);
  assert.strictEqual(store.loadDataCenterState('陆行鸟'), first, 'writes should update the existing partition cache');
  assert.equal(store.loadDataCenterState('陆行鸟').hunts['红玉海|S Test Hunt'].lastDeathTime, 1700000000);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('four data-center partitions are isolated and reject cross-DC writes', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-dc-isolation-'));
  const store = new Store({ dataDir: dir });
  const keyOf = (world, hunt) => `${world}|${hunt}`;
  store.applyTimers([{ worldName: '红玉海', huntName: 'S Test Hunt', lastDeathTime: 1700000100, rank: 's' }], keyOf, '陆行鸟');
  store.applyTimers([{ worldName: '白银乡', huntName: 'S Test Hunt', lastDeathTime: 1700000200, rank: 's' }], keyOf, '莫古力');
  const rejected = store.applyTimers([{ worldName: '红玉海', huntName: 'S Test Hunt', lastDeathTime: 1700000300, rank: 's' }], keyOf, '莫古力');
  assert.equal(rejected.rejected, 1, 'a Chocobo world must never be written into the Mogul namespace');
  assert.equal(store.loadDataCenterState('陆行鸟').hunts['红玉海|S Test Hunt'].lastDeathTime, 1700000100);
  assert.equal(store.loadDataCenterState('莫古力').hunts['白银乡|S Test Hunt'].lastDeathTime, 1700000200);
  assert.equal(Object.keys(store.loadDataCenterState('莫古力').hunts).some(key => key.includes('红玉海')), false);
  const aggregate = store.loadState();
  assert.equal(aggregate.hunts['陆行鸟|红玉海|S Test Hunt'].dataCenter, '陆行鸟');
  assert.equal(aggregate.hunts['莫古力|白银乡|S Test Hunt'].dataCenter, '莫古力');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('legacy shared state is migrated into four DC partitions and unknown worlds are quarantined', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-dc-migration-'));
  fs.writeFileSync(path.join(dir, 'state.json'), JSON.stringify({ updatedAt: '2026-11-01T00:00:00.000Z', hunts: {
    '红玉海|S Test Hunt': { worldName: '红玉海', huntName: 'S Test Hunt', lastDeathTime: 1700000100, rank: 's' },
    '白银乡|S Test Hunt': { worldName: '白银乡', huntName: 'S Test Hunt', lastDeathTime: 1700000200, rank: 's' },
    '未知服务器|S Test Hunt': { worldName: '未知服务器', huntName: 'S Test Hunt', lastDeathTime: 1700000300, rank: 's' }
  } }));
  const store = new Store({ dataDir: dir });
  const result = store.ensurePartitionMigration({ DataCenters: {} });
  assert.equal(result.migrated, 2);
  assert.equal(result.unassigned, 1);
  assert.equal(store.loadDataCenterState('陆行鸟').hunts['红玉海|S Test Hunt'].dataCenter, '陆行鸟');
  assert.equal(store.loadDataCenterState('莫古力').hunts['白银乡|S Test Hunt'].dataCenter, '莫古力');
  const quarantine = JSON.parse(fs.readFileSync(path.join(dir, 'state-unassigned-v2.json'), 'utf8'));
  assert.equal(Object.keys(quarantine.hunts).length, 1);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('Local API filters cached S-rank rows by isolated data-center namespace', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-dc-api-'));
  const cfg = { dataDir: dir, aliases: {}, sync: { allowUpstreamReports: false }, local: { host: '127.0.0.1', port: 0, allowedOrigins: ['null'], webhookUrl: '' } };
  const store = new Store(cfg);
  const keyOf = (world, hunt) => `${world}|${hunt}`;
  store.applyTimers([
    { worldName: '红玉海', huntName: 'S Test Hunt', rank: 's', lastDeathTime: 1700000100 },
    { worldName: '白银乡', huntName: 'S Test Hunt', rank: 's', lastDeathTime: 1700000200 }
  ], keyOf);
  const server = new LocalServer({ cfg, rest: {}, store, socket: null, log() {}, getStatus: () => ({}) }).start();
  t.after(() => { server.stop(); fs.rmSync(dir, { recursive: true, force: true }); });
  await new Promise(resolve => server.server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.server.address().port}`;
  const chocobo = await fetch(`${base}/hunts?rank=s&dataCenter=${encodeURIComponent('陆行鸟')}`).then(r => r.json());
  const mog = await fetch(`${base}/hunts?rank=s&dataCenter=${encodeURIComponent('莫古力')}`).then(r => r.json());
  assert.equal(chocobo.count, 1);
  assert.equal(chocobo.hunts[0].worldName, '红玉海');
  assert.equal(chocobo.hunts[0].dataCenter, '陆行鸟');
  assert.equal(mog.count, 1);
  assert.equal(mog.hunts[0].worldName, '白银乡');
  const crossed = await fetch(`${base}/hunts/${encodeURIComponent('白银乡')}/${encodeURIComponent('S Test Hunt')}?dataCenter=${encodeURIComponent('陆行鸟')}`);
  assert.equal(crossed.status, 400, 'direct lookup must reject a world/DC mismatch');
});

test('Local API pause and resume routes invoke the sync controller', async t => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-pause-'));
  const cfg = { dataDir: dir, aliases: {}, sync: { allowUpstreamReports: false }, local: { host: '127.0.0.1', port: 0, allowedOrigins: ['null'], webhookUrl: '' } };
  const store = new Store(cfg);
  let paused = 0, resumed = 0;
  const server = new LocalServer({
    cfg, rest: {}, store, socket: null, log: () => {},
    pauseSync: () => { paused++; return { paused: true, note: '当前请求结束后暂停' }; },
    resumeSync: () => { resumed++; return { resumed: true }; },
    getStatus: state => ({ cacheUpdatedAt: state?.updatedAt || null })
  }).start();
  t.after(() => { server.stop(); fs.rmSync(dir, { recursive: true, force: true }); });
  await new Promise(resolve => server.server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.server.address().port}`;
  const pause = await fetch(`${base}/sync/pause`, { method: 'POST' });
  assert.equal(pause.status, 200);
  assert.equal((await pause.json()).paused, true);
  const resume = await fetch(`${base}/sync/resume`, { method: 'POST' });
  assert.equal(resume.status, 200);
  assert.equal((await resume.json()).resumed, true);
  assert.equal(paused, 1);
  assert.equal(resumed, 1);
  const health = await fetch(`${base}/health`).then(response => response.json());
  assert.equal(health.ok, true);
  assert.equal(health.hunts, 0);
});

test('per-data-center sync metadata is persisted separately', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-dc-meta-'));
  const store = new Store({ dataDir: dir });
  store.saveDataCenterMeta('陆行鸟', { status: 'completed', lastSuccessAt: '2026-11-20T12:00:00.000Z', lastError: null });
  store.saveDataCenterMeta('莫古力', { status: 'error', lastSuccessAt: null, lastError: 'test failure' });
  assert.equal(store.loadDataCenterMeta('陆行鸟').status, 'completed');
  assert.equal(store.loadDataCenterMeta('莫古力').status, 'error');
  assert.equal(store.loadDataCenterMeta('陆行鸟').lastError, null);
  assert.equal(store.loadDataCenterMeta('莫古力').lastError, 'test failure');
  fs.rmSync(dir, { recursive: true, force: true });
});


test('multi-route conflicts are stored in the matching data-center quarantine file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bear-bridge-quarantine-'));
  const store = new Store({ dataDir: dir });
  const file = store.appendQuarantine('陆行鸟', { reason: 'timestamp conflict', row: { worldName: '红玉海', huntName: 'S Test' } });
  const content = fs.readFileSync(file, 'utf8');
  assert.match(file, /dc-[0-9a-f]+\.quarantine\.jsonl$/);
  assert.match(content, /timestamp conflict/);
  assert.match(content, /红玉海/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('Bear maintenance flags are parsed as explicit booleans and carry the authoritative timer window', () => {
  const normal = normalizeBulkTimer({
    huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000, isMaint: 'false'
  }, resources, new Set(['红玉海']));
  assert.equal(normal.maint, false);
  assert.equal(normal.window.minHours, 84);
  assert.equal(normal.window.maxHours, 132);
  assert.equal(normal.timerWindowSource, 'bear-resource-definition');

  const maintenance = normalizeBulkTimer({
    huntName: 'S Test Hunt', worldName: '红玉海', lastDeathTime: 1700000000, isMaint: 'true'
  }, resources, new Set(['红玉海']));
  assert.equal(maintenance.maint, true);
  assert.equal(maintenance.window.minHours, 50);
  assert.equal(maintenance.window.maxHours, 80);
});

test('anonymous huntInfo verification receives the same Bear timer window and maintenance state', () => {
  const { normalizeHuntInfo } = require('../src/normalize');
  const result = normalizeHuntInfo('S Test Hunt', '红玉海', {
    previousDeath: { timestamp: 1700000000 }, previousState: 'Dead'
  }, resources.DatabaseHunt['S Test Hunt'], { maint: true });
  assert.equal(result.maint, true);
  assert.equal(result.window.minHours, 50);
  assert.equal(result.window.maxHours, 80);
  assert.equal(result.timerWindowSource, 'bear-resource-definition');
});
