'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { runWithConcurrency, compareTimestampEvidence } = require('../src/multi-route');

test('multi-route worker never exceeds configured concurrency', async () => {
  let active = 0; let peak = 0;
  await runWithConcurrency([1,2,3,4,5,6], 2, async () => {
    active++; peak = Math.max(peak, active);
    await new Promise(resolve => setTimeout(resolve, 5));
    active--;
  });
  assert.equal(peak, 2);
});

test('timestamp evidence corroborates only within tolerance', () => {
  assert.equal(compareTimestampEvidence(1000, 1090, 120).matches, true);
  assert.equal(compareTimestampEvidence(1000, 1300, 120).matches, false);
  assert.equal(compareTimestampEvidence(0, 1300, 120).reason, 'missing-timestamp');
});
