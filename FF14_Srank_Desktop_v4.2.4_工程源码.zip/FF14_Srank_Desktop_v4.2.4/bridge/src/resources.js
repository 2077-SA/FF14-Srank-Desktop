'use strict';

const { SUPPORTED_WORLD_GROUPS } = require('./data-centers');

/**
 * Keep only the data needed by anonymous S-rank syncing.
 * The complete syncSession response may contain A/B/B+/FATE and spawn-point datasets;
 * none of those are retained in this S-only bridge.
 */
function filterSRankResources(resources) {
  if (!resources || typeof resources !== 'object' || !resources.DatabaseHunt) {
    throw new Error('syncSession 缺少 DatabaseHunt。');
  }
  const DatabaseHunt = Object.fromEntries(
    Object.entries(resources.DatabaseHunt).filter(([, definition]) => Number(definition?.Rank) === 5)
  );
  if (!Object.keys(DatabaseHunt).length) throw new Error('syncSession 中没有 Rank=5 的 S 怪词条。');
  const DataCenters = resources.DataCenters && typeof resources.DataCenters === 'object' ? { ...resources.DataCenters } : {};
  for (const [name, worlds] of Object.entries(SUPPORTED_WORLD_GROUPS)) {
    const current = DataCenters[name] || {};
    const knownNames = current.Names || current.Worlds || current.worlds;
    const mergedNames = [...new Set([
      ...worlds,
      ...(Array.isArray(knownNames) ? knownNames : [])
    ].map(value => String(value || '').trim()).filter(Boolean))];
    DataCenters[name] = { ...current, Names: mergedNames };
  }
  return { DatabaseHunt, DataCenters };
}

module.exports = { filterSRankResources };
