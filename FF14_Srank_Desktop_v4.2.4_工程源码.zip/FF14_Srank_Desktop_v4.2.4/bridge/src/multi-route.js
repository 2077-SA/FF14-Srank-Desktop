'use strict';

/** Run independent work with a strict concurrency ceiling. */
async function runWithConcurrency(items, limit, worker) {
  const list = Array.from(items || []);
  const cap = Math.max(1, Math.min(list.length || 1, Math.floor(Number(limit) || 1)));
  let cursor = 0;
  const runners = Array.from({ length: cap }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= list.length) return;
      await worker(list[index], index);
    }
  });
  const settled = await Promise.allSettled(runners);
  const failed = settled.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
}

function compareTimestampEvidence(primary, secondary, toleranceSeconds = 120) {
  const a = Number(primary) || 0;
  const b = Number(secondary) || 0;
  if (!a || !b) return { matches: false, deltaSeconds: null, reason: 'missing-timestamp' };
  const deltaSeconds = Math.abs(a - b);
  return { matches: deltaSeconds <= Math.max(0, Number(toleranceSeconds) || 0), deltaSeconds, reason: deltaSeconds <= toleranceSeconds ? 'corroborated' : 'conflict' };
}

module.exports = { runWithConcurrency, compareTimestampEvidence };
