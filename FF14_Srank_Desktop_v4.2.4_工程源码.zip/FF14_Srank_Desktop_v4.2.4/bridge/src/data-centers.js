'use strict';

const SUPPORTED_WORLD_GROUPS = Object.freeze({
  '豆豆柴': Object.freeze(['水晶塔', '银泪湖', '太阳海岸', '伊修加德', '红茶川']),
  '陆行鸟': Object.freeze(['红玉海', '神意之地', '拉诺西亚', '幻影群岛', '萌芽池', '宇宙和音', '沃仙曦染', '晨曦王座']),
  '莫古力': Object.freeze(['白银乡', '白金幻象', '神拳痕', '潮风亭', '旅人栈桥', '拂晓之间', '龙巢神殿', '梦羽宝境']),
  '猫小胖': Object.freeze(['紫水栈桥', '延夏', '静语庄园', '摩杜纳', '海猫茶屋', '柔风海湾', '琥珀原'])
});
const SUPPORTED_DATA_CENTERS = Object.freeze(Object.keys(SUPPORTED_WORLD_GROUPS));

function validateDataCenters(dataCenters) {
  const next = [...new Set((Array.isArray(dataCenters) ? dataCenters : [])
    .map(value => String(value || '').trim()).filter(Boolean))];
  if (!next.length) throw Object.assign(new Error('至少选择一个数据中心。'), { status: 400 });
  const available = new Set(SUPPORTED_DATA_CENTERS);
  const invalid = next.filter(value => !available.has(value));
  if (invalid.length) throw Object.assign(new Error(`未知数据中心：${invalid.join('、')}`), { status: 400 });
  return next;
}

function worldsForDataCenter(dataCenter, resources = null) {
  const builtIn = SUPPORTED_WORLD_GROUPS[dataCenter] || [];
  const entry = resources?.DataCenters?.[dataCenter];
  const remote = entry?.Names || entry?.Worlds || entry?.worlds;
  const dynamicNames = Array.isArray(remote) ? remote : [];
  return [...new Set([...builtIn, ...dynamicNames]
    .map(value => String(value || '').trim()).filter(Boolean))];
}

/**
 * Resolve one world to exactly one data center. Ambiguous or unknown worlds are
 * intentionally rejected instead of falling back to a shared/global namespace.
 */
function dataCenterForWorld(worldName, resources = null) {
  const world = String(worldName || '').trim();
  if (!world) return null;
  const matches = SUPPORTED_DATA_CENTERS.filter(dc => worldsForDataCenter(dc, resources).includes(world));
  return matches.length === 1 ? matches[0] : null;
}

module.exports = {
  SUPPORTED_DATA_CENTERS,
  SUPPORTED_WORLD_GROUPS,
  validateDataCenters,
  worldsForDataCenter,
  dataCenterForWorld
};
