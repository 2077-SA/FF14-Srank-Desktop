# FF14 Srank Desktop v4.1.1

## GitHub 自动更新
- Windows 安装版启动后延迟检查 GitHub Releases，不阻塞主界面和同步后台。
- 「帮助 → 检查更新」支持手动检查。
- 下载使用 electron-updater，并通过 GitHub Release 的 latest.yml / SHA-512 元数据验证安装包。
- 下载完成后询问是否立即重启安装；不强制退出。
- Portable 版提供版本检查和 Releases 下载入口，不尝试覆盖正在运行的 EXE。
- 本地 userData 数据目录独立于安装目录，升级不清理用户数据。

## 兼容与保留
- 保留 v4.1.0 原有工具箱、Bear S 怪同步桥接、按需大区、本地缓存和数据迁移功能。
- 本次未修改原始工具箱 HTML 的业务功能。

## 验证
- `node --check main.js`：通过。
- `node --check preload.js`：通过。
- `npm test`：19 项测试通过。
- Windows 安装包构建及真实在线更新尚需 GitHub Actions / Windows 环境验证。
