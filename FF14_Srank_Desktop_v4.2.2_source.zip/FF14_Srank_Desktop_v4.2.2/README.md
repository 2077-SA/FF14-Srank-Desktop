# FF14 Srank Desktop

当前工程版本：**v4.2.2**（多路线读取与数据一致性优化；Windows 构建待验证）。

## v4.2.2 多路线读取

- 四大区最多 2 个大区并行同步，四套缓存与状态继续严格隔离。
- 主线路：Bear `/api/lastDeathTimers` 批量读取。
- 定向复核线路：对本地锚点冲突或临近进闸窗口的少量目标，调用 Bear `/api/huntInfo` 交叉核对；每区最多 5 个，逐条限速。
- 两路时间相差不超过 120 秒才标记交叉确认；发生冲突的记录写入大区独立隔离日志，不参与 CD 计算。
- 未完成第二路核对的数据明确标记为单源校验。豆豆柴仍使用公开 Live 数据源，不能宣称已有独立 Bear 双路验证。
- 所有并行任务共享 429 冷却控制，避免限流后继续加压。
- 控制中心显示并行大区、交叉确认、单源校验和冲突隔离统计。

## 下载与发布

Windows 安装版和 Portable 版需由 GitHub Actions 构建后发布至 [GitHub Releases](https://github.com/2077-SA/FF14-Srank-Desktop/releases)。当前源码测试通过不代表 EXE 已构建或线上 Bear 已实测。

发布步骤：将 `FF14_Srank_Desktop_v4.2.2_工程源码.zip` 上传到仓库根目录，打开 GitHub Actions，运行 **Build and publish FF14 Srank Desktop release**。

## 数据安全

四大区各自独立缓存、状态、重试与冲突隔离文件。无法确认的旧数据不会参与 CD 计算；Bear 远端失败不会清空本地缓存。
