'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('unconfirmed default data-center selection is preserved without enabling automatic sync', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff14-config-test-'));
  const configPath = path.join(dir, 'bridge-config.json');
  fs.writeFileSync(configPath, JSON.stringify({
    watch: { dataCenters: ['陆行鸟'] },
    paths: { dataDir: path.join(dir, 'data') }
  }));
  const previous = process.env.BRIDGE_CONFIG;
  process.env.BRIDGE_CONFIG = configPath;
  const modulePath = require.resolve('../src/config');
  delete require.cache[modulePath];
  try {
    const config = require('../src/config');
    const loaded = config.load();
    assert.deepEqual(loaded.watch.dataCenters, ['陆行鸟']);
    assert.equal(loaded.watch.selectionConfirmed, false);
    assert.deepEqual(loaded.watch.worlds, []);
  } finally {
    delete require.cache[modulePath];
    if (previous === undefined) delete process.env.BRIDGE_CONFIG;
    else process.env.BRIDGE_CONFIG = previous;
    fs.rmSync(dir, { recursive: true, force: true });
  }
});


test('all four built-in data centers remain selectable even when remote metadata is partial', () => {
  const { validateDataCenters } = require('../src/data-centers');
  assert.deepEqual(validateDataCenters(['陆行鸟'], null), ['陆行鸟']);
  assert.deepEqual(validateDataCenters(['莫古力', '陆行鸟', '陆行鸟'], null), ['莫古力', '陆行鸟']);
  assert.throws(() => validateDataCenters(['不存在的大区'], null), error => error.status === 400);
  const partialRemote = { '陆行鸟': { Names: ['红玉海'] } };
  assert.deepEqual(validateDataCenters(['陆行鸟'], partialRemote), ['陆行鸟']);
  assert.deepEqual(validateDataCenters(['豆豆柴', '莫古力', '猫小胖'], partialRemote), ['豆豆柴', '莫古力', '猫小胖']);
  assert.throws(() => validateDataCenters(['不存在的大区'], partialRemote), error => error.status === 400);
  const { worldsForDataCenter } = require('../src/data-centers');
  assert.deepEqual(worldsForDataCenter('豆豆柴'), ['水晶塔', '银泪湖', '太阳海岸', '伊修加德', '红茶川']);
  assert.equal(worldsForDataCenter('陆行鸟').length, 8);
  assert.equal(worldsForDataCenter('莫古力').length, 8);
  assert.equal(worldsForDataCenter('猫小胖').length, 7);
  const extended = worldsForDataCenter('陆行鸟', { DataCenters: { '陆行鸟': { Names: ['红玉海', '新开放世界'] } } });
  assert.equal(extended.length, 9, 'append newly published worlds while retaining built-in known worlds');
  assert.equal(extended.at(-1), '新开放世界');
});
