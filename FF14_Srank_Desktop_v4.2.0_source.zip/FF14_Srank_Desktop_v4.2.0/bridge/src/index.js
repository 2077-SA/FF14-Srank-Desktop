#!/usr/bin/env node
'use strict';
/**
 * Anonymous S-rank-only Bear Tracker bridge.
 * - No Bear account, password, API token, Socket.IO, or upstream writes are used.
 * - Prefers the public /api/lastDeathTimers bulk endpoint for Rank=5 S monsters only.
 * - Persists validated results in batches and keeps the local HTTP server responsive.
 */
const path = require('node:path');
const config = require('./config');
const { TrackerRest } = require('./tracker-rest');
const { Store } = require('./store');
const { LocalServer, keyOf } = require('./server');
const { normalizeBulkTimer, normalizeMainSiteLive, normalizeHuntInfo, computeWindow } = require('./normalize');
const { filterSRankResources } = require('./resources');
const { validateDataCenters, worldsForDataCenter } = require('./data-centers');

const cfg = config.load();
// Force the anonymous, read-only mode even when upgrading from an older login-capable config.
cfg.auth = { username: '', password: '', cookie: '', csrfToken: '', apiToken: '' };
cfg.sync = { ...(cfg.sync || {}), allowUpstreamReports: false, queueTransientFailures: false, maxOutboxAttempts: 0 };
const stamp = () => new Date().toLocaleTimeString('zh-CN', { hour12: false });
const log = message => console.log(`${stamp()} ${message}`);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function worldsFor(resources) {
  if (Array.isArray(cfg.watch.worlds) && cfg.watch.worlds.length) return [...new Set(cfg.watch.worlds)];
  const worlds = [];
  for (const dc of cfg.watch.dataCenters || []) {
    worlds.push(...worldsForDataCenter(dc, resources));
  }
  return [...new Set(worlds)];
}

function mapToLocalName(name) {
  for (const [localName, trackerName] of Object.entries(cfg.aliases || {})) {
    if (trackerName === name) return localName;
  }
  return name;
}

async function getResources(rest, store) {
  const response = await rest.syncSession();
  const resources = response.json?.resources;
  if (response.status >= 400) {
    throw new Error(`匿名 syncSession 失败（HTTP ${response.status}）：${String(response.text || '').slice(0, 160)}`);
  }
  // Hard-filter the cache itself: this bridge intentionally discards every non-S dataset.
  const sOnlyResources = filterSRankResources(resources);
  store.saveResources(sOnlyResources);
  const sCount = Object.keys(sOnlyResources.DatabaseHunt).length;
  log(`[resources] 匿名 S 怪词库已就绪：仅保留 S 怪 ${sCount} 只；数据中心 ${Object.keys(sOnlyResources.DataCenters).length} 个`);
  return sOnlyResources;
}

function publicSyncState() {
  return {
    mode: 'anonymous-srank',
    status: 'starting',
    running: false,
    dataCenters: cfg.watch.dataCenters || [],
    rank: 's',
    totalTargets: 0,
    completed: 0,
    recordsFound: 0,
    noRecord: 0,
    errors: 0,
    lastSyncAt: null,
    startedAt: null,
    finishedAt: null,
    durationMs: 0,
    lastError: null,
    resourcesReady: false,
    progressPercent: 0, phase: 'idle', phaseLabel: '等待同步', requestQueue: 0,
    validatedTargets: 0, persistedTargets: 0, worldResults: [], paused: false, pauseRequested: false,
    lastSuccessAt: null, currentDataCenter: null
  };
}

async function runServe() {
  // Discard any stale authenticated session from an earlier bridge release. A fresh anonymous
  // session is created by GET /index and saved locally by TrackerRest.
  try { require('node:fs').rmSync(path.join(cfg.dataDir, 'auth-session.json'), { force: true }); } catch {}
  try { require('node:fs').rmSync(path.join(cfg.dataDir, 'cookies.json'), { force: true }); } catch {}
  const rest = new TrackerRest(cfg, log);
  const store = new Store(cfg);
  let resources = null;
  let resourcesFetchedAt = null;
  // If upgrading from an older all-rank bridge, sanitize its resource cache immediately.
  try {
    const cached = store.loadResources();
    if (cached) { resources = filterSRankResources(cached); resourcesFetchedAt = cached.fetchedAt || null; store.saveResources({ ...resources, fetchedAt: resourcesFetchedAt }); }
  } catch (error) { log(`[resources] 已忽略旧版非 S 资源缓存：${error.message}`); }
  const syncState = publicSyncState();
  let syncPromise = null;
  let resourcesPromise = null;
  let remoteReady = false;
  let syncPauseRequested = false;
  let syncPaused = false;
  const dcNextPollAt = new Map();

  function pauseSync() {
    syncPauseRequested = true;
    syncState.pauseRequested = true;
    if (!syncState.running) { syncPaused = true; syncState.paused = true; syncState.phase = 'paused'; syncState.phaseLabel = '已暂停'; }
    return { paused: syncPaused, pauseRequested: syncPauseRequested, note: syncState.running ? '当前网络请求结束后暂停' : '同步已暂停' };
  }
  function resumeSync() {
    syncPauseRequested = false; syncPaused = false;
    syncState.paused = false; syncState.pauseRequested = false;
    if (syncState.running && syncState.phase === 'paused') { syncState.phase = 'resuming'; syncState.phaseLabel = '正在恢复'; }
    return { paused: false, resumed: true };
  }
  async function waitIfSyncPaused() {
    if (!syncPauseRequested && !syncPaused) return;
    syncPaused = true; syncState.paused = true; syncState.phase = 'paused'; syncState.phaseLabel = '已暂停；等待恢复';
    while (syncPauseRequested) await sleep(250);
    syncPaused = false; syncState.paused = false; syncState.pauseRequested = false;
    syncState.phase = 'resuming'; syncState.phaseLabel = '已恢复，继续同步';
  }
  function recalcSyncProgress() {
    const total = Math.max(1, Number(syncState.totalTargets) || 1);
    const validated = Math.max(0, Number(syncState.validatedTargets) || 0);
    const persisted = Math.max(0, Number(syncState.persistedTargets) || 0);
    const validationPart = Math.min(70, validated / total * 70);
    const persistPart = Math.min(30, persisted / total * 30);
    syncState.progressPercent = Math.max(0, Math.min(100, Math.round((validationPart + persistPart) * 10) / 10));
  }
  function updateWorldState(dc, world, status, extra = {}) {
    const rows = Array.isArray(syncState.worldResults) ? syncState.worldResults : [];
    const row = rows.find(item => item.dataCenter === dc && item.world === world);
    if (row) Object.assign(row, { status, updatedAt: new Date().toISOString(), ...extra });
  }

  async function ensureResources() {
    if (remoteReady && resources) return resources;
    if (resourcesPromise) return resourcesPromise;
    resourcesPromise = (async () => {
      const bootstrap = await rest.bootstrap();
      log(`[rest] 匿名会话已建立：csrf=${bootstrap.csrf ? 'ok' : 'missing'}，session=${bootstrap.hasSession ? 'ok' : 'missing'}`);
      const cacheAge = resourcesFetchedAt ? Date.now() - Date.parse(resourcesFetchedAt) : Infinity;
      const maxAge = Math.max(1, Number(cfg.watch.cacheMaxAgeHours) || 24) * 3600000;
      if (!resources || !Number.isFinite(cacheAge) || cacheAge > maxAge) {
        resources = await getResources(rest, store);
        resourcesFetchedAt = new Date().toISOString();
      } else {
        log(`[resources] 使用本地 S 怪词库缓存，年龄 ${(cacheAge / 3600000).toFixed(1)} 小时；跳过重复 syncSession`);
      }
      remoteReady = true;
      syncState.resourcesReady = true;
      syncState.status = 'ready';
      return resources;
    })().catch(error => {
      syncState.status = 'error';
      syncState.running = false;
      syncState.lastError = error.message;
      log(`[init] Bear Tracker 匿名资源初始化失败：${error.message}`);
      throw error;
    }).finally(() => { resourcesPromise = null; });
    return resourcesPromise;
  }

  const sRankDefinitions = () => Object.entries(resources?.DatabaseHunt || {})
    .filter(([, definition]) => Number(definition?.Rank) === 5)
    .map(([name, definition]) => ({ name, definition }));

  function scheduleNextDataCenterPoll(dc, worlds, definitions) {
    const state = store.loadState();
    const nowSec = Math.floor(Date.now() / 1000);
    let nextSec = nowSec + 6 * 3600;
    let hasUnknown = false;
    for (const worldName of worlds) {
      for (const item of definitions) {
        const localName = mapToLocalName(item.name);
        const row = state.hunts?.[keyOf(worldName, localName)];
        const death = Number(row?.lastDeathTime) || 0;
        if (!death) { hasUnknown = true; continue; }
        const window = computeWindow(death, item.definition, !!row?.maint);
        if (!window) { hasUnknown = true; continue; }
        let candidate;
        if (nowSec < window.startTs - 900) candidate = window.startTs - 900;
        else if (nowSec <= window.endTs) candidate = nowSec + 5 * 60;
        else candidate = nowSec + 15 * 60;
        nextSec = Math.min(nextSec, candidate);
      }
    }
    if (hasUnknown) nextSec = Math.min(nextSec, nowSec + 15 * 60);
    const delayMs = Math.max(5 * 60 * 1000, Math.min(6 * 3600 * 1000, (nextSec - nowSec) * 1000));
    dcNextPollAt.set(dc, Date.now() + delayMs);
    log(`[schedule] ${dc} 下次批量核对约 ${Math.round(delayMs/60000)} 分钟后`);
  }

  async function runAnonymousSRankSync(reason = 'manual', dataCenterOverride = null) {
    if (syncPromise) return syncPromise;
    syncPromise = (async () => {
      if (!remoteReady || !resources) await ensureResources();
      const definitions = sRankDefinitions();
      const selectedDcs = validateDataCenters(dataCenterOverride || cfg.watch.dataCenters || []);
      if (!selectedDcs.length) throw new Error('尚未选择监控大区。请先在监控室选择需要读取的大区。');
      const dcWorlds = selectedDcs.map(dc => ({ dc, worlds: worldsForDataCenter(dc, resources) }));
      const invalid = dcWorlds.filter(x => !x.worlds.length).map(x => x.dc);
      if (invalid.length) throw new Error(`以下大区没有解析到服务器列表：${invalid.join('、')}`);
      if (!definitions.length) throw new Error('本地 S 怪词库中没有找到 Rank=5 定义。');

      const totalTargets = dcWorlds.reduce((sum, item) => sum + item.worlds.length * definitions.length, 0);
      const started = Date.now();
      Object.assign(syncState, {
        mode: 'anonymous-srank', status: 'running', running: true,
        dataCenters: selectedDcs, rank: 's', totalTargets, completed: 0,
        recordsFound: 0, noRecord: 0, errors: 0,
        startedAt: new Date(started).toISOString(), finishedAt: null,
        durationMs: 0, lastError: null, resourcesReady: true, reason,
        strategy: 'bulk-per-data-center', currentDataCenter: null,
        phase: 'preparing', phaseLabel: '准备同步任务', progressPercent: 0,
        validatedTargets: 0, persistedTargets: 0, paused: false, pauseRequested: false,
        lastSuccessAt: syncState.lastSuccessAt || null,
        requestQueue: dcWorlds.reduce((sum, group) => sum + group.worlds.length, 0),
        worldResults: dcWorlds.flatMap(group => group.worlds.map(world => ({ dataCenter: group.dc, world, status: 'queued', records: 0, error: null })))
      });
      recalcSyncProgress();
      log(`[sync] 批量读取启动：${selectedDcs.join('、')}；${dcWorlds.length} 个大区请求批次，理论目标 ${totalTargets} 项`);

      const flushRows = rows => {
        if (!rows.length) return;
        const previous = store.loadState();
        const events = [];
        for (const row of rows) {
          const key = keyOf(row.worldName, row.huntName);
          const old = previous.hunts?.[key];
          const oldTs = Number(old?.lastDeathTime) || 0;
          if (Number(row.lastDeathTime) > oldTs) {
            events.push({
              source: row.source, event: 'bulk-timer', type: 'death', rank: 's',
              huntName: row.huntName, worldName: row.worldName,
              time: row.lastDeathTime, lastDeathTime: row.lastDeathTime,
              at: row.lastDeathAt, region: row.region, patch: row.patch,
              maint: row.maint, receivedAt: new Date().toISOString()
            });
          }
        }
        store.applyTimers(rows, keyOf);
        for (const event of events) store.appendEvent(event);
      };

      for (let groupIndex = 0; groupIndex < dcWorlds.length; groupIndex++) {
        const group = dcWorlds[groupIndex];
        await waitIfSyncPaused();
        syncState.requestQueue = dcWorlds.slice(groupIndex).reduce((sum, item) => sum + item.worlds.length, 0);
        syncState.currentDataCenter = group.dc;
        syncState.phase = 'request'; syncState.phaseLabel = `正在读取 ${group.dc}：等待整区接口响应`;
        for (const world of group.worlds) updateWorldState(group.dc, world, 'requesting');
        log(`[sync] ${group.dc}: 批量查询 ${group.worlds.length} 个服务器`);
        try {
          let response;
          if (group.dc === '豆豆柴') {
            response = await rest.liveDataCenter(group.dc);
            await waitIfSyncPaused();
            syncState.phase = 'validation'; syncState.phaseLabel = `正在校验 ${group.dc} 快照`;
            for (const world of group.worlds) updateWorldState(group.dc, world, 'validating');
            const rows = normalizeMainSiteLive(response.json, resources, new Set(group.worlds))
              .map(row => ({ ...row, huntName: mapToLocalName(row.huntName) }));
            const byWorld = new Map(group.worlds.map(world => [world, rows.filter(row => row.worldName === world)]));
            for (const world of group.worlds) {
              const worldRows = byWorld.get(world) || [];
              updateWorldState(group.dc, world, 'validated', { records: worldRows.length });
              syncState.validatedTargets += definitions.length;
            }
            recalcSyncProgress();
            syncState.phase = 'persist'; syncState.phaseLabel = `正在保存 ${group.dc} 数据`;
            for (let offset = 0; offset < rows.length; offset += 25) {
              await waitIfSyncPaused();
              const chunk = rows.slice(offset, offset + 25); flushRows(chunk); syncState.recordsFound += chunk.length;
              await sleep(0);
            }
            for (const world of group.worlds) { updateWorldState(group.dc, world, 'saved', { records: (byWorld.get(world) || []).length }); syncState.persistedTargets += definitions.length; syncState.completed += definitions.length; await sleep(0); }
            recalcSyncProgress();
            const targets = group.worlds.length * definitions.length;
            syncState.noRecord += Math.max(0, targets - rows.length);
            log(`[sync] 豆豆柴：主站 live 快照校验通过 ${rows.length} 条；已逐批写入本地`);
            syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
            scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
            continue;
          }
          try {
            response = await rest.lastDeathTimers(group.worlds, 'sRank');
          } catch (error) {
            // Compatibility fallback only for an explicitly unsupported endpoint.
            // Never fan out into hundreds of requests after auth/rate-limit/server errors.
            if (![404, 405, 501].includes(Number(error.status))) throw error;
            log(`[sync] ${group.dc}: 批量接口不支持，使用受限逐只查询兼容模式`);
            const tasks = [];
            for (const worldName of group.worlds) for (const item of definitions) tasks.push({ ...item, worldName });
            const rows = [];
            const recordsByWorld = new Map(group.worlds.map(world => [world, 0]));
            const failedByWorld = new Map();
            const concurrency = 1;
            let cursor = 0;
            let nextFallbackAt = 0;
            async function fallbackWorker() {
              while (cursor < tasks.length) {
                const task = tasks[cursor++];
                const wait = Math.max(0, nextFallbackAt - Date.now());
                if (wait) await sleep(wait);
                nextFallbackAt = Date.now() + Math.max(500, Number(cfg.watch.sRankRequestDelayMs) || 600);
                await waitIfSyncPaused();
                syncState.phase = 'fallback'; syncState.phaseLabel = `兼容逐只查询：${task.worldName} / ${task.name}`;
                try {
                  const result = await rest.huntInfo(task.name, task.worldName);
                  const normalized = normalizeHuntInfo(task.name, task.worldName, result.json, task.definition);
                  if (normalized) {
                    normalized.huntName = mapToLocalName(normalized.huntName);
                    rows.push(normalized);
                    recordsByWorld.set(task.worldName, (recordsByWorld.get(task.worldName) || 0) + 1);
                  } else { syncState.noRecord++; }
                } catch (e) {
                  syncState.errors++;
                  failedByWorld.set(task.worldName, e.message);
                  if (!syncState.lastError) syncState.lastError = e.message;
                }
                syncState.completed++; syncState.validatedTargets++;
                // A completed fallback task is now resolved (success or an explicit per-hunt error).
                syncState.persistedTargets++; recalcSyncProgress();
                updateWorldState(group.dc, task.worldName, 'querying', { currentHunt: task.name, error: failedByWorld.get(task.worldName) || null });
                if (rows.length >= 20) { flushRows(rows.splice(0)); syncState.recordsFound += 20; }
                await sleep(0);
              }
            }
            await Promise.all(Array.from({length:concurrency},fallbackWorker));
            if (rows.length) { const n=rows.length; flushRows(rows); syncState.recordsFound += n; }
            for (const world of group.worlds) {
              const failure = failedByWorld.get(world);
              updateWorldState(group.dc, world, failure ? 'error' : 'saved', { records: recordsByWorld.get(world) || 0, error: failure || null });
            }
            syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
            scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
            continue;
          }
          await waitIfSyncPaused();
          const payload = response.json;
          if (!payload || !Array.isArray(payload.timers)) {
            throw new Error(`${group.dc} 批量接口响应结构无效：未找到 timers 数组，拒绝导入不确定数据。`);
          }
          syncState.phase = 'validation'; syncState.phaseLabel = `正在校验 ${group.dc} 返回记录`;
          for (const world of group.worlds) updateWorldState(group.dc, world, 'validating');
          const allowedWorlds = new Set(group.worlds);
          const deduped = new Map();
          const sourceTimers = payload.timers;
          for (let index = 0; index < sourceTimers.length; index++) {
            const timer = sourceTimers[index];
            const normalized = normalizeBulkTimer(timer, resources, allowedWorlds);
            if (normalized) {
              normalized.huntName = mapToLocalName(normalized.huntName);
              const key = keyOf(normalized.worldName, normalized.huntName);
              const previous = deduped.get(key);
              if (!previous || normalized.lastDeathTime > previous.lastDeathTime) deduped.set(key, normalized);
            }
            if ((index + 1) % 80 === 0) { syncState.validationRecords = index + 1; await sleep(0); }
          }
          const rows = [...deduped.values()];
          const byWorld = new Map(group.worlds.map(world => [world, rows.filter(row => row.worldName === world)]));
          for (const world of group.worlds) {
            const worldRows = byWorld.get(world) || [];
            updateWorldState(group.dc, world, 'validated', { records: worldRows.length });
            syncState.validatedTargets += definitions.length;
            recalcSyncProgress();
            await sleep(0);
          }
          syncState.phase = 'persist'; syncState.phaseLabel = `正在保存 ${group.dc} 的校验结果`;
          for (let offset = 0; offset < rows.length; offset += 25) {
            await waitIfSyncPaused();
            const chunk = rows.slice(offset, offset + 25);
            flushRows(chunk);
            syncState.recordsFound += chunk.length;
            const touchedWorlds = [...new Set(chunk.map(row => row.worldName))];
            for (const world of touchedWorlds) updateWorldState(group.dc, world, 'saving', { records: (byWorld.get(world) || []).length });
            await sleep(0);
          }
          for (const world of group.worlds) {
            updateWorldState(group.dc, world, 'saved', { records: (byWorld.get(world) || []).length });
            syncState.persistedTargets += definitions.length;
            syncState.completed += definitions.length;
            recalcSyncProgress();
            await sleep(0);
          }
          const targets = group.worlds.length * definitions.length;
          syncState.noRecord += Math.max(0, targets - rows.length);
          log(`[sync] ${group.dc}: 返回 ${payload.timers.length} 条，校验通过 ${rows.length} 条；已逐批写入本地`);
          syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
          scheduleNextDataCenterPoll(group.dc, group.worlds, definitions);
        } catch (error) {
          syncState.errors++;
          const status = Number(error.status) || 0;
          if (!syncState.lastError) syncState.lastError = status ? `HTTP ${status}：${error.message}` : error.message;
          log(`[sync] ${group.dc} 批量读取失败：${error.message}`);
          // Mark only this DC's targets as attempted. Existing cached data is never cleared.
          for (const world of group.worlds) updateWorldState(group.dc, world, 'error', { error: error.message });
          syncState.requestQueue = Math.max(0, syncState.requestQueue - group.worlds.length);
          const failedTargets = group.worlds.length * definitions.length;
          syncState.validatedTargets += failedTargets; syncState.persistedTargets += failedTargets; syncState.completed += failedTargets; recalcSyncProgress();
          dcNextPollAt.set(group.dc, Date.now() + Math.max(5 * 60 * 1000, Number(error.retryAfterMs) || 15 * 60 * 1000));
          if (status === 429) {
            const retry = Number(error.retryAfterMs) || 60000;
            log(`[rate-limit] Bear Tracker 限流，暂停后续大区请求 ${Math.ceil(retry/1000)} 秒`);
            await sleep(Math.min(15 * 60 * 1000, Math.max(60000, retry)));
          }
        }
      }

      const ended = Date.now();
      Object.assign(syncState, {
        status: syncState.errors && !syncState.recordsFound ? 'error' : 'completed',
        running: false, currentDataCenter: null, phase: 'completed', phaseLabel: syncState.errors ? '同步结束，部分服务器失败' : '同步完成',
        progressPercent: 100, requestQueue: 0, paused: false, pauseRequested: false,
        finishedAt: new Date(ended).toISOString(), lastSyncAt: new Date(ended).toISOString(),
        lastSuccessAt: syncState.recordsFound > 0 || !syncState.errors ? new Date(ended).toISOString() : (syncState.lastSuccessAt || null),
        durationMs: ended - started
      });
      log(`[sync] 批量同步结束：新增/更新候选 ${syncState.recordsFound} 条；无记录 ${syncState.noRecord} 项；失败大区/批次 ${syncState.errors}；耗时 ${(syncState.durationMs/1000).toFixed(1)} 秒`);
      return { ...syncState, records: syncState.recordsFound };
    })().catch(error => {
      syncState.status = 'error'; syncState.running = false; syncState.lastError = error.message;
      syncState.phase = 'error'; syncState.phaseLabel = '同步异常'; syncState.paused = false; syncState.pauseRequested = false;
      syncState.finishedAt = new Date().toISOString(); syncState.lastSyncAt = syncState.finishedAt;
      log(`[sync] S 怪同步失败：${error.message}`); throw error;
    }).finally(() => { syncPromise = null; });
    return syncPromise;
  }

  async function updateAliases(aliases) {
    const db = resources?.DatabaseHunt || {};
    const next = {};
    const used = new Set();
    for (const [localRaw, remoteRaw] of Object.entries(aliases || {})) {
      const localName = String(localRaw || '').trim();
      const trackerName = String(remoteRaw || '').trim();
      if (!localName || !trackerName) continue;
      if (!db[trackerName]) throw Object.assign(new Error(`Bear Tracker 词库中不存在：${trackerName}`), { status: 400 });
      if (Number(db[trackerName].Rank) !== 5) throw Object.assign(new Error(`${trackerName} 不是 Rank=5 的 S 怪，不能绑定。`), { status: 400 });
      if (used.has(trackerName)) throw Object.assign(new Error(`同一个 Bear S 怪不能重复绑定：${trackerName}`), { status: 400 });
      used.add(trackerName);
      next[localName] = trackerName;
    }
    cfg.aliases = next;
    config.save(cfg);
    return { count: Object.keys(next).length };
  }

  async function updateDataCenters(dataCenters) {
    // The settings UI remains usable before the Bear resource bundle is ready.
    // When remote resources exist, their exact data-center names take precedence.
    const next = validateDataCenters(dataCenters);
    cfg.watch.dataCenters = next;
    cfg.watch.worlds = [];
    cfg.watch.selectionConfirmed = true;
    config.save(cfg);
    setImmediate(async () => {
      try { if (syncPromise) await syncPromise; await runAnonymousSRankSync('data-center-change'); } catch {}
    });
    return { dataCenters: next };
  }

  const localServer = new LocalServer({
    cfg, rest, store, socket: null, log,
    updateAliases, updateDataCenters, pauseSync, resumeSync,
    getStatus: (stateSnapshot = store.loadState()) => ({
      mode: 'anonymous-srank', authenticated: false, username: null,
      socketConnected: false, timerCount: Object.values(stateSnapshot.hunts || {}).filter(row => row.rank === 's').length,
      cacheUpdatedAt: stateSnapshot.updatedAt || null,
      aliasCount: Object.keys(cfg.aliases || {}).length,
      sRankDefinitionCount: sRankDefinitions().length,
      dataCenters: cfg.watch.dataCenters || [],
      sync: { ...syncState },
      resourcesReady: remoteReady
    })
  }).start();

  localServer.on('manualSync', dataCenters => {
    runAnonymousSRankSync('manual', Array.isArray(dataCenters) && dataCenters.length ? dataCenters : null).catch(() => {});
  });

  // Start the localhost server first. Network initialization and the full scan are background tasks.
  (async () => {
    try {
      await ensureResources();
      if (cfg.watch.selectionConfirmed === true && (cfg.watch.dataCenters || []).length) await runAnonymousSRankSync('startup');
      else { syncState.status = 'ready'; log('[startup] 尚未选择监控大区；仅准备本地词库，不启动全量扫描。'); }
    } catch (error) {
      syncState.status = 'error';
      syncState.running = false;
      syncState.lastError = error.message;
      log(`[init] Bear Tracker 匿名初始化失败：${error.message}；本地接口仍保持运行，可稍后点击“立即同步”。`);
    }
  })();

  // Lightweight scheduler tick; each data center has its own next-check time derived
  // from its S-rank respawn windows. Unknown anchors retain a conservative 15-minute check.
  const refreshTimer = setInterval(() => {
    if (!remoteReady || cfg.watch.selectionConfirmed !== true || !(cfg.watch.dataCenters || []).length || syncPromise) return;
    const now = Date.now();
    const due = (cfg.watch.dataCenters || []).filter(dc => !dcNextPollAt.has(dc) || dcNextPollAt.get(dc) <= now);
    if (due.length) runAnonymousSRankSync('cd-scheduled', due).catch(() => {});
  }, 60 * 1000);

  const shutdown = () => {
    log('[exit] 正在关闭本地 S 怪同步桥接');
    clearInterval(refreshTimer);
    localServer.stop();
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  log(`[ready] 免登录 S 怪桥接服务：http://${cfg.local.host}:${cfg.local.port}；数据中心=${(cfg.watch.dataCenters || []).join('、')}`);
}

async function main() {
  const mode = process.argv[2] || 'serve';
  if (mode === 'serve') return runServe();
  if (mode === 'sync') {
    const rest = new TrackerRest(cfg, log);
    const store = new Store(cfg);
    await rest.bootstrap();
    const resources = await getResources(rest, store);
    const worlds = worldsFor(resources);
    const targets = Object.entries(resources.DatabaseHunt).filter(([, row]) => Number(row?.Rank) === 5);
    console.log(JSON.stringify({ mode: 'anonymous-srank', sRankCount: targets.length, worlds, instruction: '启动服务请运行 node src/index.js' }, null, 2));
    return;
  }
  console.log('仅支持：node src/index.js（启动）或 node src/index.js sync（检查匿名资源）。');
}

main().catch(error => { console.error(`[FATAL] ${error.message}`); process.exitCode = 1; });
