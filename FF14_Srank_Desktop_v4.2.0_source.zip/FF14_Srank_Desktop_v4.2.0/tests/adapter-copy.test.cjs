const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');

test('renderer Bear adapter is byte-for-byte aligned with bridge adapter source',()=>{
 const root=path.resolve(__dirname,'..');
 const source=fs.readFileSync(path.join(root,'bridge','toolbox-adapter.js'),'utf8');
 const renderer=fs.readFileSync(path.join(root,'app','bear-sync-adapter.js'),'utf8');
 assert.equal(renderer,source);
});

test('Bear adapter replaces the shared in-memory host history after source-scoped merge',()=>{
 const root=path.resolve(__dirname,'..');
 const adapter=fs.readFileSync(path.join(root,'bridge','toolbox-adapter.js'),'utf8');
 const host=fs.readFileSync(path.join(root,'app','index.html'),'utf8');
 assert.match(adapter,/window\.__ff14ReplaceKillRecords\(bounded\)/);
 assert.match(host,/window\.__ff14ReplaceKillRecords = function replaceKillRecords\(records\)/);
 assert.match(host,/allKillRecords\.length = 0/);
});


test('calculator displays live CD phase, remaining time and gate/force window from current server-hunt anchor',()=>{
 const root=path.resolve(__dirname,'..');
 const adapter=fs.readFileSync(path.join(root,'bridge','toolbox-adapter.js'),'utf8');
 assert.match(adapter,/calculator-cd-phase/);
 assert.match(adapter,/calculator-cd-times/);
 assert.match(adapter,/CD 冷却中/);
 assert.match(adapter,/存活窗口剩余/);
 assert.match(adapter,/预计进闸/);
 assert.match(adapter,/预计强制/);
 assert.match(adapter,/__FF14BearCalculatorTicker/);
 assert.match(adapter,/\},1000\)/);
 assert.match(adapter,/data-action="use-sync-time"/);
});
