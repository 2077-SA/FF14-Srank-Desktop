/* FF14 Srank <-> Bear Tracker anonymous S-rank adapter.
 * This build is read-only against Bear Tracker and does not require an account.
 * It imports Rank=5 S-rank kill anchors only; no A/B/FATE data and no upstream writes.
 */
(function FF14BearAnonymousSRankAdapter(){
  'use strict';
  if (window.__FF14BearAnonymousAdapterInstalled) return;
  window.__FF14BearAnonymousAdapterInstalled = true;

  const CONFIG = Object.assign({
    baseUrl: 'http://127.0.0.1:8788',
    requestTimeoutMs: 2200,
    maxHistoryScan: 5000,
    pullChunkSize: 8,
    syncPollMs: 2500,
    localRefreshMs: 30000
  }, window.FF14BearBridgeConfig || {});
  const STORAGE = 'ff14_bear_anonymous_srank_state_v3';
  const KNOWN_DATA_CENTERS = Object.freeze(['豆豆柴', '陆行鸟', '莫古力', '猫小胖']);
  const state = {
    serviceReady: false,
    dataCenters: ['陆行鸟'],
    syncStatus: 'offline',
    syncRunning: false,
    totalTargets: 0,
    completed: 0,
    timerCount: 0,
    sRankCount: 0,
    aliasCount: 0,
    pulled: 0,
    skipped: 0,
    lastSyncAt: null,
    lastAppliedSyncAt: null,
    lastCacheUpdatedAt: null, lastAppliedCacheUpdatedAt: null,
    lastError: null,
    progressPercent: 0, phaseLabel: '等待本机同步服务', worldResults: [], paused: false, pauseRequested: false, lastSuccessAt: null
  };

  let panel = null;
  let pill = null;
  let panelDetail = null;
  let dcOptions = null;
  let worldList = null;
  let calculatorCard = null;
  let mapList = null;
  let mapSearch = null;
  let localMonsterList = [];
  let latestRecordsIndex = new Map();
  let cachedRemoteHunts = [];
  let cachedAliases = {};
  let mappingLoaded = false;
  let syncWaitToken = 0;
  let statusTimer = null;
  let healthBusy = false;
  let pullBusy = false;

  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  const url = path => CONFIG.baseUrl.replace(/\/$/, '') + path;
  const log = (...args) => console.info('[FF14 同步数据]', ...args);
  const warn = (...args) => console.warn('[FF14 同步数据]', ...args);
  const toSeconds = value => {
    if (value == null || value === '') return null;
    if (typeof value === 'string' && !/^\d+(?:\.\d+)?$/.test(value)) {
      const parsed = Date.parse(value);
      return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : null;
    }
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return null;
    return Math.floor(n > 1e12 ? n / 1000 : n);
  };
  const localDate = sec => {
    const date = new Date(sec * 1000);
    const pad = n => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  function persistState(){
    try {
      localStorage.setItem(STORAGE, JSON.stringify({
        pulled: state.pulled, skipped: state.skipped,
        lastSyncAt: state.lastSyncAt, lastAppliedSyncAt: state.lastAppliedSyncAt, lastCacheUpdatedAt: state.lastCacheUpdatedAt, lastAppliedCacheUpdatedAt: state.lastAppliedCacheUpdatedAt
      }));
    } catch {}
  }
  function restoreState(){
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE) || '{}');
      state.pulled = Number(value.pulled) || 0;
      state.skipped = Number(value.skipped) || 0;
      state.lastSyncAt = value.lastSyncAt || null;
      state.lastAppliedSyncAt = value.lastAppliedSyncAt || null;
      state.lastCacheUpdatedAt = value.lastCacheUpdatedAt || null;
      state.lastAppliedCacheUpdatedAt = value.lastAppliedCacheUpdatedAt || null;
    } catch {}
  }
  async function request(path, options = {}){
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(new Error('本机桥接请求超时')), CONFIG.requestTimeoutMs);
    try {
      const response = await fetch(url(path), Object.assign({
        cache: 'no-store', signal: controller.signal
      }, options));
      const text = await response.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; }
      catch { data = { raw: text.slice(0, 240) }; }
      if (!response.ok) {
        const error = new Error(data.error || `${response.status} ${response.statusText}`);
        error.status = response.status;
        throw error;
      }
      return data;
    } finally { clearTimeout(timeout); }
  }

  function readRecords(){
    try {
      const data = JSON.parse(localStorage.getItem('ff14_all_kill_records') || '[]');
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }
  function buildLatestIndex(records){
    const index = new Map();
    for (const item of records.slice(0, CONFIG.maxHistoryScan)) {
      if (!item?.server || !item?.name) continue;
      let ms = Number(item.killTimeMs || item.killTsMs || (Number(item.killTs) > 0 ? Number(item.killTs) * 1000 : 0));
      if (!Number.isFinite(ms) || ms <= 0) ms = item.time ? (Date.parse(String(item.time).replace(/-/g, '/')) || 0) : 0;
      const key = `${item.server}|${item.name}`;
      if (ms > (index.get(key) || 0)) index.set(key, ms);
    }
    return index;
  }
  function isKnownLocalSName(name){
    if (!name || !localMonsterList.length) return false;
    return localMonsterList.some(monster => monster.name === name);
  }

  function applyRecord(record, latestIndex, addedRecords){
    const server = String(record?.worldName || record?.server || '').trim();
    const name = String(record?.huntName || record?.sName || record?.name || '').trim();
    const killTs = toSeconds(record?.lastDeathTime ?? record?.killTs ?? record?.time ?? record?.lastDeathAt);
    if (!server || !name || !killTs || (record.rank !== 's' && Number(record.rankCode) !== 5)) {
      state.skipped++;
      return false;
    }
    if (!isKnownLocalSName(name)) {
      state.skipped++;
      return false;
    }
    const killMs = killTs * 1000;
    const key = `${server}|${name}`;
    if ((latestIndex.get(key) || 0) >= killMs) {
      state.skipped++;
      return false;
    }
    if (typeof window.addAllKillRecord !== 'function') return false;

    const row = window.addAllKillRecord(server, name, record.region || record.area || '', '同步数据', {
      triggerTimeMs: killMs, killTimeMs: killMs, syncSource: 'bear-tracker-anonymous'
    });
    if (!row || typeof row !== 'object') return false;
    row.killTimeMs = killMs;
    row.killTs = killTs;
    row.triggerTimeMs = killMs;
    row.time = localDate(killTs);
    row.syncSource = 'bear-tracker-anonymous';
    latestIndex.set(key, killMs);
    addedRecords.push(row);
    state.pulled++;
    return true;
  }

  function persistAddedBatch(addedRecords){
    if (!addedRecords.length) return;
    const current = readRecords();
    const replacedKeys = new Set(addedRecords.map(row => `${row.server}|${row.name}`));
    // Replace stale Bear-sourced anchors for these exact world/hunt pairs only.
    // Manual and other local records are never removed or rewritten.
    const retained = current.filter(row => row?.syncSource !== 'bear-tracker-anonymous' || !replacedKeys.has(`${row.server}|${row.name}`));
    // addAllKillRecord unshifts each record, so reverse the collected batch for newest-first order.
    const merged = [...addedRecords.slice().reverse(), ...retained];
    const max = Math.max(1000, Number(window.PredictorConfig?.MAX_RECORDS) || 5000);
    const bounded = merged.slice(0, max);
    try {
      if (typeof window.__ff14ReplaceKillRecords === 'function') {
        if (!window.__ff14ReplaceKillRecords(bounded)) throw new Error('宿主记录存储拒绝写入');
      } else {
        localStorage.setItem('ff14_all_kill_records', JSON.stringify(bounded));
      }
    } catch (error) { warn('保存同步记录失败：', error.message); }
  }

  async function pullSnapshot(syncAt){
    if (pullBusy) return { added: 0, busy: true };
    pullBusy = true;
    try {
      const data = await request('/hunts?rank=s');
      const rows = Array.isArray(data.hunts) ? data.hunts : [];
      const existing = readRecords();
      const latestIndex = buildLatestIndex(existing);
      let added = 0;
      for (let offset = 0; offset < rows.length; offset += CONFIG.pullChunkSize) {
        const chunk = rows.slice(offset, offset + CONFIG.pullChunkSize);
        const batch = [];
        const previousBulk = window.__ff14MonitorBulkSyncActive;
        const originalDirtyMarker = window.__ff14MonitorMarkKillRecordsDirty;
        const predictor = window.__predictor;
        const originalInvalidate = predictor && predictor.invalidate;
        try {
          // Keep the bulk flag only during this synchronous chunk; never leave it set across a yield.
          window.__ff14MonitorBulkSyncActive = true;
          if (typeof originalDirtyMarker === 'function') window.__ff14MonitorMarkKillRecordsDirty = () => {};
          if (predictor && typeof originalInvalidate === 'function') predictor.invalidate = () => {};
          for (const row of chunk) if (applyRecord(row, latestIndex, batch)) added++;
        } finally {
          window.__ff14MonitorBulkSyncActive = previousBulk;
          if (typeof originalDirtyMarker === 'function') window.__ff14MonitorMarkKillRecordsDirty = originalDirtyMarker;
          if (predictor && typeof originalInvalidate === 'function') predictor.invalidate = originalInvalidate;
        }
        // Persist once per small batch, then yield so input/render work can proceed.
        if (batch.length) persistAddedBatch(batch);
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      if (added) refreshUI();
      if (syncAt) state.lastAppliedSyncAt = syncAt;
      state.lastAppliedCacheUpdatedAt = data.updatedAt || state.lastCacheUpdatedAt || null;
      state.lastCacheUpdatedAt = data.updatedAt || state.lastCacheUpdatedAt || null;
      rebuildLatestRecordsIndex();
      persistState();
      updatePanelStatus();
      log(`S 怪 CD 快照应用完成：新增 ${added} 条，已存在/跳过 ${rows.length - added} 条`);
      return { added, count: rows.length };
    } finally { pullBusy = false; }
  }

  function refreshUI(){
    // Exactly one refresh pass after an imported batch, not once per monster.
    try { window.renderRecentList?.(); } catch {}
    try { window.renderAllKillRecordsList?.(); } catch {}
    try { window.calcManual?.(); } catch {}
    try { window.__predictor?.invalidate?.(); } catch {}
    try { window.FF14TriggerMonitorHostBindingRefresh?.(); } catch {}
    rebuildLatestRecordsIndex();
    try { window.dispatchEvent(new CustomEvent('ff14:kill-records-changed')); } catch {}
    refreshCalculatorSnapshot();
  }

  function formatStamp(value){
    if(!value)return '暂无';
    const date=new Date(value);
    return Number.isFinite(date.getTime())?date.toLocaleString():'暂无';
  }
  function updatePill(){
    if(!pill)return;
    const text=!state.serviceReady?'同步数据 · 服务未连接':state.syncRunning?`同步数据 · ${Math.round(state.progressPercent||0)}%`:state.syncStatus==='error'?'同步数据 · 检查异常':`同步数据 · ${state.timerCount} 条缓存`;
    pill.textContent=text;
    pill.dataset.state=!state.serviceReady?'off':state.syncRunning?'pending':state.syncStatus==='error'?'warn':'on';
  }
  function renderWorldResults(){
    if(!worldList)return;
    const rows=Array.isArray(state.worldResults)?state.worldResults:[];
    worldList.replaceChildren();
    if(!rows.length){const empty=document.createElement('div');empty.className='ff14-bear-empty';empty.textContent='尚无服务器同步记录。保存大区后会显示每个服务器的状态。';worldList.appendChild(empty);return;}
    const fragment=document.createDocumentFragment();
    for(const row of rows){
      const item=document.createElement('div');item.className='ff14-bear-world-row';
      const left=document.createElement('div');left.className='ff14-bear-world-name';
      const strong=document.createElement('strong');strong.textContent=row.world||'未知服务器';
      const small=document.createElement('small');small.textContent=`${row.dataCenter||''} · ${Number(row.records)||0} 条记录`;
      left.append(strong,small);
      const status=document.createElement('span');status.className='ff14-bear-world-state';
      const labels={queued:'排队中',requesting:'请求中',validating:'校验中',validated:'已校验',saving:'保存中',saved:'已完成',querying:'逐只查询',error:'失败'};
      status.textContent=labels[row.status]||row.status||'等待中';status.dataset.state=row.status||'queued';
      item.append(left,status);
      if(row.error){const error=document.createElement('small');error.className='ff14-bear-world-error';error.textContent=row.error;item.appendChild(error);}
      fragment.appendChild(item);
    }
    worldList.appendChild(fragment);
  }
  function updatePanelStatus(){
    const target=panel?.querySelector('[data-role="connection"]');
    if(target){
      if(!state.serviceReady)target.textContent='本机同步服务尚未连接。请检查桌面端桥接后台是否启动。';
      else target.textContent=`本机服务：已连接\n订阅大区：${(state.dataCenters||[]).join('、')||'尚未确认'}\nS 怪词库：${state.sRankCount} 只 · 本地缓存：${state.timerCount} 条\n最近完成：${formatStamp(state.lastSyncAt)} · 最近成功：${formatStamp(state.lastSuccessAt)}\n${state.lastError?`最近错误：${state.lastError}`:'当前无错误'}`;
    }
    const mapping=panel?.querySelector('[data-role="mapping-count"]');
    if(mapping)mapping.textContent=`Bear Tracker Rank=5：${state.sRankCount} 只；工具箱正式 S 怪：${localMonsterList.length} 只；已绑定：${Object.keys(cachedAliases).length} 条。`;
    const phase=panel?.querySelector('[data-role="phase"]');if(phase)phase.textContent=state.phaseLabel||'等待同步';
    const percent=Math.max(0,Math.min(100,Number(state.progressPercent)||0));
    const bar=panel?.querySelector('[data-role="progress"]');if(bar)bar.style.width=`${percent}%`;
    const track=panel?.querySelector('.ff14-bear-progress-track[role="progressbar"]');if(track)track.setAttribute('aria-valuenow',String(percent));
    renderProgressExplanation();
    const pct=panel?.querySelector('[data-role="percent"]');if(pct)pct.textContent=`${percent.toFixed(1)}%`;
    const queue=panel?.querySelector('[data-role="queue"]');if(queue){const queued=Number(state.requestQueue)||0;queue.textContent=`待请求 ${queued} 个服务器 · 已完成 ${state.completed}/${state.totalTargets} 项`+(state.syncRunning&&state.phase==='request'?' · 等待当前整区请求返回':'');}
    const sync=panel?.querySelector('[data-action="sync"]');if(sync){sync.disabled=!state.serviceReady||state.syncRunning;sync.textContent=state.syncRunning?'正在同步…':'立即同步所选大区';}
    const pause=panel?.querySelector('[data-action="pause"]');if(pause)pause.disabled=!state.serviceReady||!state.syncRunning||state.paused||state.pauseRequested;
    const resume=panel?.querySelector('[data-action="resume"]');if(resume)resume.disabled=!state.serviceReady||(!state.paused&&!state.pauseRequested);
    const mappingBtn=panel?.querySelector('[data-action="save-maps"]');if(mappingBtn)mappingBtn.disabled=!state.serviceReady||!mappingLoaded;
    renderWorldResults();updatePill();refreshCalculatorSnapshot();
  }
  function applyHealth(health){
    state.serviceReady=!!health?.ok;state.syncRunning=!!health?.sync?.running;
    state.syncStatus=health?.sync?.status||(state.serviceReady?'ready':'offline');
    state.totalTargets=Number(health?.sync?.totalTargets)||0;state.completed=Number(health?.sync?.completed)||0;
    state.progressPercent=Number(health?.sync?.progressPercent)||0;
    state.phase=health?.sync?.phase||'idle';
    state.phaseLabel=health?.sync?.phaseLabel|| (state.syncRunning?'同步进行中':'等待同步');
    state.requestQueue=Number(health?.sync?.requestQueue)||0;
    state.worldResults=Array.isArray(health?.sync?.worldResults)?health.sync.worldResults:[];
    state.paused=!!health?.sync?.paused;state.pauseRequested=!!health?.sync?.pauseRequested;
    state.timerCount=Number(health?.timerCount)||0;state.sRankCount=Number(health?.sRankDefinitionCount)||0;
    state.aliasCount=Number(health?.aliasCount)||0;
    const reported=health?.dataCenters||health?.sync?.dataCenters;if(Array.isArray(reported)&&reported.length)state.dataCenters=reported.slice();
    state.lastSyncAt=health?.sync?.lastSyncAt||null;state.lastSuccessAt=health?.sync?.lastSuccessAt||null;
    state.lastError=health?.sync?.lastError||null;state.resourcesReady=!!health?.resourcesReady;
    state.lastCacheUpdatedAt=health?.cacheUpdatedAt||null;
    updatePanelStatus();
  }
  async function refreshHealth({applySnapshot=true,forceSnapshot=false}={}){
    if(healthBusy)return null;healthBusy=true;
    try{
      const health=await request('/health');applyHealth(health);
      const cacheChanged=state.lastCacheUpdatedAt && state.lastCacheUpdatedAt!==state.lastAppliedCacheUpdatedAt;
      if(applySnapshot&&state.serviceReady&&!state.syncRunning&&(forceSnapshot||cacheChanged|| (state.lastSyncAt&&state.lastSyncAt!==state.lastAppliedSyncAt)))await pullSnapshot(state.lastSyncAt);
      return health;
    }catch(error){state.serviceReady=false;state.syncStatus='offline';state.lastError=error.message;updatePanelStatus();return null;}
    finally{healthBusy=false;}
  }
  function selectedDataCenters(){return Array.from(dcOptions?.querySelectorAll('[data-dc-option][aria-pressed="true"]')||[]).map(button=>button.dataset.dcOption);}
  function updateDcButtons(){
    if(!dcOptions)return;const selected=new Set(state.dataCenters?.length?state.dataCenters:['陆行鸟']);
    dcOptions.querySelectorAll('[data-dc-option]').forEach(button=>{const active=selected.has(button.dataset.dcOption);button.setAttribute('aria-pressed',String(active));});
  }
  function setSelectedDataCenters(names){state.dataCenters=[...new Set((names||[]).filter(name=>KNOWN_DATA_CENTERS.includes(name)))];updateDcButtons();}
  function renderProgressExplanation(){
    const hint=panel?.querySelector('[data-role="progress-hint"]');if(!hint)return;
    hint.textContent=state.syncRunning&&state.phase==='request'?'当前整区请求尚未返回，进度条保持真实已完成值；响应到达后再推进校验和保存进度。':'进度按已校验目标与已写入目标计算，不使用计时器模拟进度。';
  }
  function normalizeRecordName(value){
    return String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
  }
  function recordTimeMs(row){
    return Number(row?.killTimeMs||row?.killTsMs||0)||((Number(row?.killTs)||0)*1000)||(row?.time?Date.parse(String(row.time).replace(/-/g,'/')):0);
  }
  function rebuildLatestRecordsIndex(){
    const index=new Map();
    for(const row of readRecords().slice(0,CONFIG.maxHistoryScan)){
      const server=String(row?.server||'').trim(),name=normalizeRecordName(row?.name),ms=recordTimeMs(row);
      if(!server||!name||!Number.isFinite(ms)||ms<=0)continue;
      const key=`${server}|${name}`,prior=index.get(key);
      if(!prior||ms>prior.timeMs)index.set(key,{row,timeMs:ms});
    }
    latestRecordsIndex=index;
    return index;
  }
  function latestRecordFor(server,name){
    if(!server||!name)return null;
    const aliases=[name,...(localMonsterList.find(item=>item.name===name)?.aliases||[])];
    let best=null;
    for(const alias of aliases){
      const hit=latestRecordsIndex.get(`${server}|${normalizeRecordName(alias)}`);
      if(hit&&(!best||hit.timeMs>best.timeMs))best=hit;
    }
    return best;
  }
  function formatDuration(ms){
    const seconds=Math.max(0,Math.floor(ms/1000));
    const days=Math.floor(seconds/86400),hours=Math.floor(seconds%86400/3600),minutes=Math.floor(seconds%3600/60),secs=seconds%60;
    return `${days?`${days}天 `:''}${String(hours).padStart(2,'0')}:${String(minutes).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
  }
  function calculatorCooldownHours(){
    try { if(typeof CD_HOURS!=='undefined'&&Number(CD_HOURS)>0)return Number(CD_HOURS); } catch {}
    return 84;
  }
  function calculatorLifeHours(){
    try { if(typeof LT_HOURS!=='undefined'&&Number(LT_HOURS)>0)return Number(LT_HOURS); } catch {}
    return 48;
  }
  function refreshCalculatorSnapshot(){
    const box=document.getElementById('ff14BearCalculatorSnapshot');if(!box)return;
    const server=document.getElementById('mServer')?.value?.trim()||'';
    const name=String(document.getElementById('mMonster')?.value||'').split('|')[0].trim();
    const match=latestRecordFor(server,name);
    const text=box.querySelector('[data-role="calculator-sync-text"]');
    const phase=box.querySelector('[data-role="calculator-cd-phase"]');
    const times=box.querySelector('[data-role="calculator-cd-times"]');
    const progress=box.querySelector('[data-role="calculator-cd-progress"]');
    const button=box.querySelector('[data-action="use-sync-time"]');
    if(!match){
      if(text)text.textContent=server&&name?`当前目标 ${server} / ${name} 暂无可用击杀锚点。`:'选择服务器和 S 怪后显示对应同步数据。';
      if(phase)phase.textContent='等待击杀数据';if(times)times.textContent='进闸时间：— · 强制时间：—';
      if(progress)progress.style.width='0%';if(button)button.disabled=true;box.dataset.timeMs='';return;
    }
    const now=Date.now(),killMs=match.timeMs,cdHours=calculatorCooldownHours(),lifeHours=calculatorLifeHours();
    const cdMs=cdHours*3600000,lifeMs=lifeHours*3600000,gateMs=killMs+cdMs,forceMs=gateMs+lifeMs;
    const dt=new Date(killMs),gate=new Date(gateMs),force=new Date(forceMs);
    const source=match.row.syncSource==='bear-tracker-anonymous'?'Bear Tracker 公开同步':'本地记录';
    if(text)text.textContent=`${server} · ${name}：${source}击杀锚点 ${dt.toLocaleString()}。下方状态按当前全局 CD 参数实时计算，不会自动改写你正在编辑的输入。`;
    if(now<killMs){
      if(phase)phase.textContent='击杀时间异常：时间位于未来，请先核对数据';
      if(times)times.textContent=`记录击杀：${dt.toLocaleString()} · 预计进闸：${gate.toLocaleString()} · 预计强制：${force.toLocaleString()}`;
      if(progress)progress.style.width='0%';
    }else if(now<gateMs){
      const pct=Math.min(100,Math.max(0,(now-killMs)/cdMs*100));
      if(phase)phase.textContent=`🔴 CD 冷却中 · 进闸剩余 ${formatDuration(gateMs-now)} · 已完成 ${pct.toFixed(1)}%`;
      if(times)times.textContent=`预计进闸：${gate.toLocaleString()} · 预计强制：${force.toLocaleString()} · CD ${cdHours}h`;
      if(progress)progress.style.width=`${pct}%`;
    }else if(now<forceMs){
      const pct=Math.min(100,Math.max(0,(now-gateMs)/lifeMs*100));
      if(phase)phase.textContent=`🟢 已进闸 · 存活窗口剩余 ${formatDuration(forceMs-now)} · 已用 ${pct.toFixed(1)}%`;
      if(times)times.textContent=`进闸时间：${gate.toLocaleString()} · 强制消失：${force.toLocaleString()} · 存活窗 ${lifeHours}h`;
      if(progress)progress.style.width=`${pct}%`;
    }else{
      if(phase)phase.textContent=`⚫ 已超过预计强制消失时间 ${formatDuration(now-forceMs)}`;
      if(times)times.textContent=`进闸时间：${gate.toLocaleString()} · 强制消失：${force.toLocaleString()}`;
      if(progress)progress.style.width='100%';
    }
    if(button)button.disabled=false;box.dataset.timeMs=String(killMs);
    box.dataset.cdHours=String(cdHours);box.dataset.lifeHours=String(lifeHours);
  }
  function mountCalculatorSnapshot(){
    const result=document.getElementById('manualResultBox');if(!result||document.getElementById('ff14BearCalculatorSnapshot'))return;
    calculatorCard=document.createElement('section');calculatorCard.id='ff14BearCalculatorSnapshot';calculatorCard.style.cssText='margin:12px 0;padding:10px 12px;border:1px solid rgba(46,160,112,.34);border-radius:12px;background:linear-gradient(120deg,rgba(35,160,110,.08),rgba(40,120,190,.06));font-size:12px;line-height:1.55;';
    calculatorCard.innerHTML='<div style="font-weight:800;margin-bottom:5px">同步数据 · 当前 S 怪 CD 状态</div><div data-role="calculator-sync-text" style="color:var(--text-muted);margin-bottom:8px">选择服务器和 S 怪后显示对应同步数据。</div><div data-role="calculator-cd-phase" aria-live="polite" style="font-weight:850;font-size:13px;margin:4px 0">等待击杀数据</div><div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden;margin:6px 0"><div data-role="calculator-cd-progress" style="height:100%;width:0%;background:linear-gradient(90deg,#d48b36,#2eb889);transition:width .25s"></div></div><div data-role="calculator-cd-times" style="color:var(--text-muted);font-size:10px;margin-bottom:8px">进闸时间：— · 强制时间：—</div><button type="button" data-action="use-sync-time" disabled style="border:1px solid rgba(46,160,112,.42);border-radius:8px;padding:6px 10px;background:rgba(35,160,110,.13);color:inherit;font-weight:750;cursor:pointer">将同步击杀时间填入计算器</button><div style="font-size:10px;color:var(--text-muted);margin-top:6px">状态每秒刷新；本地同步缓存每 30 秒更新。仅显示估算，不会覆盖正在编辑的输入；天气前置及监控室手动校准仍以原工具逻辑为准。</div>';
    result.insertAdjacentElement('afterend',calculatorCard);
    calculatorCard.querySelector('[data-action="use-sync-time"]').addEventListener('click',()=>{
      const ms=Number(calculatorCard.dataset.timeMs);if(!Number.isFinite(ms)||ms<=0)return;
      const radio=document.querySelector('input[name="mStatus"][value="red"]');if(radio){radio.checked=true;radio.dispatchEvent(new Event('change',{bubbles:true}));}
      const absolute=document.getElementById('mAbsoluteDateTime');
      if(absolute){const d=new Date(ms),pad=n=>String(n).padStart(2,'0');absolute.value=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;absolute.dispatchEvent(new Event('input',{bubbles:true}));absolute.dispatchEvent(new Event('change',{bubbles:true}));}
      const hour=document.getElementById('mHour'),minute=document.getElementById('mMin'),second=document.getElementById('mSec');
      const elapsed=Math.max(0,Math.floor((Date.now()-ms)/1000));if(hour)hour.value=String(Math.floor(elapsed/3600));if(minute)minute.value=String(Math.floor(elapsed%3600/60));if(second)second.value=String(elapsed%60);
      try{window.calcManual?.();}catch(_){}
      setMessage('已将同步击杀锚点填入计算器。请核对目标、CD 和天气前置后再保存。','success');
    });
    ['mServer','mMonster','mMonsterInput'].forEach(id=>{const el=document.getElementById(id);el?.addEventListener('change',refreshCalculatorSnapshot);el?.addEventListener('input',refreshCalculatorSnapshot);});
    document.getElementById('serverDropdownList')?.addEventListener('click',()=>setTimeout(refreshCalculatorSnapshot,80));
    document.getElementById('monsterDropdownList')?.addEventListener('click',()=>setTimeout(refreshCalculatorSnapshot,80));
    refreshCalculatorSnapshot();
    if(!window.__FF14BearCalculatorTicker)window.__FF14BearCalculatorTicker=setInterval(()=>{
      if(document.visibilityState==='hidden')return;
      const target=document.getElementById('ff14BearCalculatorSnapshot');
      if(target?.getClientRects().length)refreshCalculatorSnapshot();
    },1000);
  }

  function getLocalMonsters(){
    const source = window.FF14_OCR_DICTIONARY?.monsters;
    if (!Array.isArray(source)) return [];
    return source.map(monster => ({
      name: monster.name, area: monster.area || '', version: monster.version || '',
      aliases: monster.alias || monster.aliases || []
    })).filter(monster => monster.name);
  }

  function populateDataCenterOptions(){
    if(!dcOptions)return;
    dcOptions.replaceChildren();
    const current=new Set(state.dataCenters?.length?state.dataCenters:['陆行鸟']);
    for(const name of KNOWN_DATA_CENTERS){
      const button=document.createElement('button');button.type='button';button.className='ff14-bear-dc-chip';button.dataset.dcOption=name;
      button.textContent=name;button.setAttribute('aria-pressed',String(current.has(name)));
      button.addEventListener('click',()=>{
        const selected=new Set(selectedDataCenters());
        if(selected.has(name)){if(selected.size===1){setMessage('至少保留一个数据中心。','warn');return;}selected.delete(name);}else selected.add(name);
        setSelectedDataCenters([...selected]);
      });
      dcOptions.appendChild(button);
    }
  }

  async function loadMappingData(){
    if (mappingLoaded) return;
    try {
      // Fetch local settings independently from Bear resources. This lets players
      // preselect and save a DC immediately on first launch, even while remote
      // dictionary initialization is still in progress.
      const [health, settings] = await Promise.all([request('/health'), request('/settings')]);
      state.dataCenters = Array.isArray(settings.dataCenters) ? settings.dataCenters.slice() : (state.dataCenters || []);
      if (!state.dataCenters.length && settings.selectionConfirmed !== true) state.dataCenters = ['陆行鸟'];
      cachedAliases = settings.aliases || {};
      localMonsterList = getLocalMonsters();
      updateDcButtons();
      if (!health.resourcesReady) {
        setMessage('Bear Tracker 公开词库仍在初始化。现在可以先选择并保存数据中心；词库就绪后会自动继续加载名称映射。', 'info');
        updatePanelStatus();
        return;
      }
      const resources = await request('/resources');
      const db = resources.DatabaseHunt || {};
      cachedRemoteHunts = Object.entries(db)
        .filter(([, definition]) => Number(definition?.Rank) === 5)
        .map(([name, definition]) => ({ name, region: definition.Region || '', patch: definition.Patch || '' }))
        .sort((a,b) => a.name.localeCompare(b.name));
      updateDcButtons();
      renderMappings();
      mappingLoaded = true;
      updatePanelStatus();
    } catch (error) {
      setMessage(`读取 S 怪词库失败：${error.message}`, 'error');
    }
  }

  function renderMappings(){
    if (!mapList) return;
    mapList.replaceChildren();
    const query = String(mapSearch?.value || '').trim().toLocaleLowerCase();
    const filtered = localMonsterList.filter(monster => !query || `${monster.name} ${monster.area} ${monster.version}`.toLocaleLowerCase().includes(query));
    if (!filtered.length) {
      const empty = document.createElement('p'); empty.className = 'ff14-bear-empty';
      empty.textContent = '没有找到工具箱正式 S 怪词条。'; mapList.appendChild(empty); return;
    }
    const fragment = document.createDocumentFragment();
    for (const monster of filtered) {
      const row = document.createElement('div'); row.className = 'ff14-bear-map-row';
      const label = document.createElement('label'); label.className = 'ff14-bear-map-label';
      const name = document.createElement('strong'); name.textContent = monster.name;
      const meta = document.createElement('small'); meta.textContent = `${monster.area || '地区未知'} · ${monster.version || '版本未知'}`;
      label.append(name, meta);
      const select = document.createElement('select'); select.dataset.localName = monster.name;
      const blank = document.createElement('option'); blank.value = ''; blank.textContent = '选择 Bear Tracker S 怪'; select.appendChild(blank);
      for (const remote of cachedRemoteHunts) {
        const option = document.createElement('option'); option.value = remote.name;
        option.textContent = `${remote.name} · ${remote.region || '地区未知'}`; select.appendChild(option);
      }
      let chosen = cachedAliases[monster.name] || '';
      if (!chosen) {
        const aliases = [monster.name, ...monster.aliases];
        const exact = cachedRemoteHunts.find(remote => aliases.some(alias => String(alias).toLowerCase() === remote.name.toLowerCase()));
        if (exact) chosen = exact.name;
      }
      if (chosen) select.value = chosen;
      row.append(label, select); fragment.appendChild(row);
    }
    mapList.appendChild(fragment);
  }

  async function saveMappings(){
    const aliases = {};
    const visibleNames = new Set();
    for (const select of mapList?.querySelectorAll('select[data-local-name]') || []) {
      visibleNames.add(select.dataset.localName);
      if (select.value) aliases[select.dataset.localName] = select.value;
    }
    for (const [name, value] of Object.entries(cachedAliases)) if (!visibleNames.has(name)) aliases[name] = value;
    const result = await request('/settings/aliases', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ aliases })
    });
    cachedAliases = aliases; state.aliasCount = Number(result.count) || Object.keys(aliases).length;
    setMessage(`S 怪名称映射已保存：${state.aliasCount} 条。现在启动一次后台同步。`, 'success');
    await startManualSync();
  }

  async function saveDataCenters(){
    const selected=selectedDataCenters();
    if(!selected.length)throw new Error('至少选择一个数据中心。');
    const result=await request('/settings/data-centers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataCenters:selected})});
    state.dataCenters=result.dataCenters||selected;updateDcButtons();
    setMessage(`已保存：${state.dataCenters.join('、')}。开始同步这些大区的 S 怪数据。`,'success');
    await waitForSync();
  }
  async function waitForSync(){
    const token=++syncWaitToken,deadline=Date.now()+30*60*1000;
    while(token===syncWaitToken&&Date.now()<deadline){
      await delay(CONFIG.syncPollMs);const health=await refreshHealth({applySnapshot:false});if(!health)return;
      if(!health.resourcesReady&&health.sync?.status!=='error'){setMessage('正在初始化公开 S 怪词库…');continue;}
      if(!health.sync?.running&&['completed','error'].includes(String(health.sync?.status))){await refreshHealth({applySnapshot:true,forceSnapshot:true});const sync=health.sync||{};setMessage(sync.status==='error'?`同步未完成：${sync.lastError||'请检查诊断信息。'}`:`同步完成：${sync.completed||0}/${sync.totalTargets||0} 项，发现 ${sync.recordsFound||0} 条记录，空记录 ${sync.noRecord||0} 项，错误 ${sync.errors||0} 项。`,sync.status==='error'||sync.errors?'warn':'success');return;}
      const sync=health.sync||{};setMessage(sync.phase==='request'?'正在等待当前大区的公开接口响应；进度条不会虚增。':`${sync.phaseLabel||'同步中'}：${sync.completed||0}/${sync.totalTargets||0} 项`,'info');
    }
    if(token===syncWaitToken)setMessage('同步仍在后台执行；关闭面板不会停止同步，稍后打开即可查看最新状态。','warn');
  }
  async function startManualSync(){
    if(state.syncRunning){setMessage('同步正在后台执行，可使用暂停 / 恢复控制。','info');return;}
    const selected=selectedDataCenters();if(!selected.length)throw new Error('请至少选择一个数据中心。');
    try{await request('/sync/now',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataCenters:selected})});setMessage(`已启动：${selected.join('、')}。读取在后台执行，页面仍可操作。`,'success');await waitForSync();}
    catch(error){setMessage(`启动同步失败：${error.message}`,'error');}
  }
  async function pauseSync(){try{const result=await request('/sync/pause',{method:'POST'});setMessage(result.note||'已请求暂停。当前整区请求会先结束。','warn');await refreshHealth({applySnapshot:false});}catch(error){setMessage(`暂停失败：${error.message}`,'error');}}
  async function resumeSync(){try{await request('/sync/resume',{method:'POST'});setMessage('同步已恢复。','success');await refreshHealth({applySnapshot:false});}catch(error){setMessage(`恢复失败：${error.message}`,'error');}}

  function setMessage(message, kind = 'info'){
    const node = panel?.querySelector('[data-role="message"]');
    if (node) { node.textContent = message; node.dataset.kind = kind; }
  }

  function createPanel(){
    if(!document.body||document.getElementById('ff14BearBridgeStatus'))return;
    const style=document.createElement('style');style.id='ff14-bear-bridge-ui-style-v420';
    style.textContent=`
      #ff14BearBridgeStatus{font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#eef4ff;width:100%}
      #ff14BearBridgeStatus [hidden]{display:none!important}
      #ff14BearBridgeStatus .ff14-bear-pill{display:none!important}
      #ff14BearBridgeStatus .ff14-bear-panel{position:static;width:100%;max-height:min(72vh,720px);display:flex;flex-direction:column;overflow:hidden;border:1px solid rgba(148,163,184,.45);border-radius:16px;background:rgba(14,23,38,.97);box-shadow:0 12px 34px #0004}
      #ff14BearBridgeStatus .ff14-bear-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #ffffff1c;font-size:16px;font-weight:800}
      #ff14BearBridgeStatus .ff14-bear-head button{border:0;background:transparent;color:#d7e3f5;font-size:20px;cursor:pointer}
      #ff14BearBridgeStatus .ff14-bear-body{padding:12px 14px 15px;overflow:auto;overscroll-behavior:contain}
      #ff14BearBridgeStatus .ff14-bear-note{margin:0 0 10px;color:#b8c8dc;font-size:12px}
      #ff14BearBridgeStatus .ff14-bear-status{white-space:pre-line;border:1px solid #ffffff20;background:#ffffff09;border-radius:10px;padding:9px 11px;color:#dce8f7;font-size:12px;margin-bottom:10px}
      #ff14BearBridgeStatus button.ff14-bear-action{border:1px solid #71839b80;border-radius:9px;background:#26364c;color:#f1f5fb;padding:8px 11px;cursor:pointer;font:inherit;font-weight:650}
      #ff14BearBridgeStatus button.ff14-bear-primary{background:#176b53;border-color:#3eae88}#ff14BearBridgeStatus button:disabled{opacity:.45;cursor:not-allowed}
      #ff14BearBridgeStatus .ff14-bear-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:9px}
      #ff14BearBridgeStatus .ff14-bear-message{margin:10px 0;color:#b7c8dd;font-size:12px;white-space:pre-wrap}#ff14BearBridgeStatus .ff14-bear-message[data-kind="error"]{color:#ff9b9b}#ff14BearBridgeStatus .ff14-bear-message[data-kind="success"]{color:#76ddb4}#ff14BearBridgeStatus .ff14-bear-message[data-kind="warn"]{color:#ffd27b}
      #ff14BearBridgeStatus .ff14-bear-section{margin-top:13px;padding-top:12px;border-top:1px solid #ffffff1c}
      #ff14BearBridgeStatus .ff14-bear-section-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;font-weight:700}
      #ff14BearBridgeStatus .ff14-bear-muted{color:#9fb0c7;font-size:11px;font-weight:400}
      #ff14BearBridgeStatus .ff14-bear-progress-head{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;margin:10px 0 6px}
      #ff14BearBridgeStatus .ff14-bear-progress-track{height:10px;border-radius:999px;overflow:hidden;background:#081321;border:1px solid #ffffff20}
      #ff14BearBridgeStatus .ff14-bear-progress-fill{height:100%;width:0%;background:linear-gradient(90deg,#2eb889,#58a6ff);transition:width .18s ease}
      #ff14BearBridgeStatus .ff14-bear-progress-hint{font-size:10px;color:#92a7c1;margin-top:5px}
      #ff14BearBridgeStatus .ff14-bear-dc-options{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}
      #ff14BearBridgeStatus .ff14-bear-dc-chip{border:1px solid #ffffff2d;background:#101e31;color:#dbe8f8;border-radius:9px;padding:8px 5px;font:inherit;font-size:12px;font-weight:750;cursor:pointer}
      #ff14BearBridgeStatus .ff14-bear-dc-chip[aria-pressed="true"]{border-color:#34c99a;background:rgba(33,154,117,.24);color:#9ff3d3}
      #ff14BearBridgeStatus .ff14-bear-worlds{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;max-height:260px;overflow:auto}
      #ff14BearBridgeStatus .ff14-bear-world-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:6px;padding:7px 8px;border:1px solid #ffffff17;border-radius:9px;background:#ffffff07;min-width:0}
      #ff14BearBridgeStatus .ff14-bear-world-name{display:flex;flex-direction:column;min-width:0}#ff14BearBridgeStatus .ff14-bear-world-name strong{font-size:11px;overflow-wrap:anywhere}#ff14BearBridgeStatus .ff14-bear-world-name small{font-size:9px;color:#9fb0c7}
      #ff14BearBridgeStatus .ff14-bear-world-state{font-size:10px;padding:3px 6px;border-radius:99px;background:#ffffff10;white-space:nowrap}
      #ff14BearBridgeStatus .ff14-bear-world-state[data-state="saved"]{color:#76ddb4;background:#1a6c4c35}#ff14BearBridgeStatus .ff14-bear-world-state[data-state="error"]{color:#ff9b9b;background:#8d292935}#ff14BearBridgeStatus .ff14-bear-world-state[data-state="requesting"],#ff14BearBridgeStatus .ff14-bear-world-state[data-state="validating"],#ff14BearBridgeStatus .ff14-bear-world-state[data-state="saving"]{color:#ffd27b}
      #ff14BearBridgeStatus .ff14-bear-world-error{grid-column:1/-1;color:#ff9b9b;font-size:10px;overflow-wrap:anywhere}
      #ff14BearBridgeStatus .ff14-bear-map-list{display:flex;flex-direction:column;gap:6px;max-height:230px;overflow:auto;margin-top:8px;padding-right:3px}
      #ff14BearBridgeStatus .ff14-bear-map-row{display:grid;grid-template-columns:minmax(110px,.8fr) minmax(150px,1.2fr);align-items:center;gap:8px;padding:6px 8px;border:1px solid #ffffff17;border-radius:9px;background:#ffffff07}
      #ff14BearBridgeStatus .ff14-bear-map-label{display:flex;flex-direction:column;gap:2px;min-width:0}#ff14BearBridgeStatus .ff14-bear-map-label strong{font-size:12px;overflow-wrap:anywhere}#ff14BearBridgeStatus .ff14-bear-map-label small{font-size:10px;color:#a9bad0}
      #ff14BearBridgeStatus input,#ff14BearBridgeStatus select{box-sizing:border-box;width:100%;min-width:0;border:1px solid #64748b80;border-radius:9px;background:#111d30;color:#f1f5fb;padding:8px;font:inherit}
      #ff14BearBridgeStatus .ff14-bear-map-list select{font-size:11px;padding:7px}#ff14BearBridgeStatus .ff14-bear-empty{color:#a9bad0;font-size:12px}
      #ff14BearBridgeStatus a{color:#8fc5ff;text-decoration:underline;text-underline-offset:2px}
      @media(max-width:520px){#ff14BearBridgeStatus .ff14-bear-dc-options{grid-template-columns:repeat(2,minmax(0,1fr))}#ff14BearBridgeStatus .ff14-bear-worlds{grid-template-columns:1fr}#ff14BearBridgeStatus .ff14-bear-map-row{grid-template-columns:1fr}}
    `;
    document.head.appendChild(style);
    panel=document.createElement('div');panel.id='ff14BearBridgeStatus';
    panel.innerHTML=`
      <section class="ff14-bear-panel" aria-label="同步数据控制中心">
        <header class="ff14-bear-head"><span>同步数据</span><button type="button" data-action="close" aria-label="收起同步数据面板" title="收起">⌄</button></header>
        <div class="ff14-bear-body">
          <p class="ff14-bear-note">读取 Bear Tracker 公开 S 怪数据（Rank=5），不需要登录，不向上游写入。选择需要同步的大区后，首次同步会建立本地缓存；后续每 30 秒把本地缓存变化投影到监控室与计算器，远端请求仍按服务器 CD 窗口调度，不会每 30 秒重复爬站。</p>
          <div class="ff14-bear-status" data-role="connection">正在检查本机同步服务…</div>
          <section class="ff14-bear-section" style="margin-top:0;padding-top:0;border:0">
            <div class="ff14-bear-section-title"><span>选择数据中心</span><span class="ff14-bear-muted">可多选 · 默认陆行鸟</span></div>
            <div class="ff14-bear-dc-options" data-role="dc-options"></div>
            <div class="ff14-bear-actions"><button type="button" class="ff14-bear-action" data-action="save-dcs">保存所选大区</button></div>
          </section>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>同步进度</span><span data-role="percent">0.0%</span></div>
            <div class="ff14-bear-progress-head"><strong data-role="phase">等待同步</strong><span data-role="queue">等待队列 0 个服务器</span></div>
            <div class="ff14-bear-progress-track" role="progressbar" aria-label="同步真实进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ff14-bear-progress-fill" data-role="progress"></div></div>
            <div class="ff14-bear-progress-hint" data-role="progress-hint">进度按已校验目标与已写入目标计算，不使用计时器模拟进度。</div>
            <div class="ff14-bear-actions">
              <button type="button" class="ff14-bear-action ff14-bear-primary" data-action="sync">立即同步所选大区</button>
              <button type="button" class="ff14-bear-action" data-action="pause">暂停同步</button>
              <button type="button" class="ff14-bear-action" data-action="resume">恢复同步</button>
            </div>
          </section>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>服务器同步明细</span><span class="ff14-bear-muted">按大区 / 世界展示</span></div>
            <div class="ff14-bear-worlds" data-role="world-list"><div class="ff14-bear-empty">保存大区后显示服务器状态。</div></div>
          </section>
          <p class="ff14-bear-message" data-role="message">首次使用建议：先选择常用大区（默认陆行鸟），点击“保存所选大区”，等待首次同步完成。也可打开 <a href="https://tracker.beartoolkit.com/timer" target="_blank" rel="noreferrer">Bear Tracker 公开计时页面</a> 对照服务器和击杀时间；此页面可公开访问，本工具不会要求填写 Bear 账号密码。</p>
          <section class="ff14-bear-section">
            <div class="ff14-bear-section-title"><span>中文 S 怪名称映射</span><span class="ff14-bear-muted">首次核对一次</span></div>
            <p class="ff14-bear-note" data-role="mapping-count">等待读取 Rank=5 S 怪词库。</p>
            <input type="search" data-role="map-search" placeholder="搜索中文 S 怪名称 / 地区">
            <div class="ff14-bear-map-list" data-role="map-list"><p class="ff14-bear-empty">打开面板后载入 S 怪映射。</p></div>
            <div class="ff14-bear-actions"><button type="button" class="ff14-bear-action ff14-bear-primary" data-action="save-maps">保存名称映射并同步</button></div>
          </section>
          <p class="ff14-bear-note" style="margin-top:12px">同步方向：Bear Tracker → 工具箱。不会上传击杀或任何工具箱数据。只替换同一世界 / 同一 S 怪的旧 Bear 同步锚点；手动记录、天气前置、监控室手动 CD 校准均保留。</p>
        </div>
      </section>`;
    document.body.appendChild(panel);
    panelDetail=panel.querySelector('.ff14-bear-panel');dcOptions=panel.querySelector('[data-role="dc-options"]');worldList=panel.querySelector('[data-role="world-list"]');
    populateDataCenterOptions();mapList=panel.querySelector('[data-role="map-list"]');mapSearch=panel.querySelector('[data-role="map-search"]');
    panel.querySelector('[data-action="close"]').addEventListener('click',()=>{window.FF14UnifiedUtilityDock?.close?.();});
    panel.querySelector('[data-action="sync"]').addEventListener('click',()=>startManualSync().catch(error=>setMessage(error.message,'error')));
    panel.querySelector('[data-action="pause"]').addEventListener('click',pauseSync);
    panel.querySelector('[data-action="resume"]').addEventListener('click',resumeSync);
    panel.querySelector('[data-action="save-dcs"]').addEventListener('click',()=>saveDataCenters().catch(error=>setMessage(error.message,'error')));
    panel.querySelector('[data-action="save-maps"]').addEventListener('click',()=>saveMappings().catch(error=>setMessage(error.message,'error')));
    mapSearch.addEventListener('input',renderMappings);
    updatePanelStatus();
  }

  function startStatusTimer(){
    stopStatusTimer();
    statusTimer = setInterval(() => {
      if (document.visibilityState === 'hidden' || panelDetail?.hidden) return;
      refreshHealth().then(() => { if (state.resourcesReady && !mappingLoaded && !panelDetail?.hidden) loadMappingData(); }).catch(() => {});
    }, 2500);
  }
  function stopStatusTimer(){ if (statusTimer) clearInterval(statusTimer); statusTimer = null; }

  async function start(){
    restoreState();
    // Load the toolbox's canonical S-rank dictionary before any automatic snapshot import.
    // If the dictionary is unavailable, reject unknown Bear names instead of importing English
    // HuntName values into the Chinese toolbox history.
    localMonsterList = getLocalMonsters();
    rebuildLatestRecordsIndex();
    mountCalculatorSnapshot();
    await refreshHealth({applySnapshot:true,forceSnapshot:true});
    // The Node service starts its remote scan after the local HTTP server is already available.
    // Keep a small async waiter during first initialization so a closed panel still imports the
    // first completed snapshot automatically; no remote request is made from the browser.
    if (state.serviceReady && (state.syncRunning || (!state.resourcesReady && state.syncStatus !== 'error'))) waitForSync();
    // Lightweight health polling catches later 15-minute background refreshes without SSE or
    // per-monster browser work. It never runs while this tab is hidden.
    setInterval(() => {
      if (document.visibilityState === 'hidden' || healthBusy || pullBusy) return;
      refreshHealth({applySnapshot:true,forceSnapshot:false}).catch(() => {});
    }, CONFIG.localRefreshMs);
  }
  window.addEventListener('ff14:kill-records-changed',()=>{rebuildLatestRecordsIndex();refreshCalculatorSnapshot();});

  function refreshLocalRecords(){
    rebuildLatestRecordsIndex();
    refreshCalculatorSnapshot();
    return latestRecordsIndex.size;
  }
  window.FF14BearBridge = Object.freeze({
    status: () => ({ ...state }),
    syncNow: startManualSync,
    refresh: refreshHealth,
    pull: pullSnapshot,
    refreshCalculator: refreshCalculatorSnapshot,
    refreshLocalRecords,
    latestRecordFor
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { createPanel(); start().catch(error => warn(error.message)); }, { once: true });
  } else {
    createPanel(); start().catch(error => warn(error.message));
  }
})();
