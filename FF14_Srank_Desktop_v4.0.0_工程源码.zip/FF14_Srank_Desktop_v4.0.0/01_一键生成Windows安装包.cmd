@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ================================================
echo   FF14 Srank Desktop v4.0.0 - Windows Builder
echo ================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 未检测到 Node.js。请先安装 Node.js 22.12 或更高版本。
  echo 官方下载：https://nodejs.org/
  pause
  exit /b 1
)
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=12)?0:1)"
if errorlevel 1 (
  echo [错误] Node.js 版本过低，需要 22.12 或更高版本。
  pause
  exit /b 1
)
echo [1/4] 安装 Electron 和打包依赖（首次需要网络）...
call npm install --no-audit --no-fund
if errorlevel 1 goto failed
echo.
echo [2/4] 检查源码语法...
call npm run check
if errorlevel 1 goto failed
echo.
echo [3/4] 运行自动化测试...
call npm test
if errorlevel 1 goto failed
echo.
echo [4/4] 生成 Windows 安装包和免安装 EXE...
call npm run dist:win
if errorlevel 1 goto failed
echo.
echo ================================================
echo 构建完成！文件位于 release 文件夹。
echo - NSIS 安装程序：可安装并创建桌面快捷方式
echo - Portable EXE：单文件免安装版本
echo ================================================
start "" "%~dp0release"
pause
exit /b 0
:failed
echo.
echo [失败] 构建未完成。请查看上方错误信息或 logs。
pause
exit /b 1
